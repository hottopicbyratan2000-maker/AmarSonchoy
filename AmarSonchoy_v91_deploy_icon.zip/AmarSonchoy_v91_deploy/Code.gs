/**
 * ============================================================================
 * AmarSonchoy (amarsonchoy.com) — Save Now, Buy Later micro-savings platform
 * Bochaganj (Setabganj), Dinajpur, Bangladesh
 * ============================================================================
 * Code.gs — Foundation + Upgrade 1 (Security) + Upgrade 2 (SMS/Confirmation)
 *           + Upgrade 3 (Refund/Pause) + Upgrade 4 (Flexi-Goal Converter)
 *           + Upgrade 5 (Savings Bonus) + Upgrade 6 (Missed Installment
 *           Follow-up) + Upgrade 7 (Manager Cash Settlement) + Upgrade 8
 *           (Rewards & Referrals) + Upgrade 9 (Committee Savings Groups)
 *           + Upgrade 10 (Printable Passbook)
 *           + Upgrade 11 (Manager Offline Support) + Upgrade 12 (Seasonal
 *           Goals & Campaigns) + Upgrade 13 (Reports, Backup & Manager
 *           Leaderboard) + Upgrade 14 (Bengali digits, Branch, Terms consent,
 *           Plan archiving) + Upgrade 15 (Online bKash/Nagad payment claims)
 *           + Upgrade 16 (No-code initial Admin setup) + Upgrade 17
 *           (Public landing-page stats) + Upgrade 18 (Navigation drawer)
 *           + Upgrade 19 (Charts & custom dashboards, Manager monthly targets)
 * All comments in English, all user-facing strings in Bengali.
 * ============================================================================
 */

// ---------------------------------------------------------------------------
// 1. CONFIG — edit these values freely, nothing else needs to change
// ---------------------------------------------------------------------------
const CONFIG = {
  SPREADSHEET_ID: '1EHm361mpa_QZV1sl39VIQ_GNm30ypUVRCiVwle9TT0c',
  APP_NAME: 'AmarSonchoy',
  APP_URL: 'https://amarsonchoy.com', // public address used in every share link (referral, receipt QR)
  TAGLINE: 'টাকা জমবে নিরাপদে, স্বপ্ন আসবে হাতের মুঠোয়',
  YOUTUBE_VIDEO_ID: 'dQw4w9WgXcQ', // replace with your real explainer video ID
  MANAGER_PHONE: '01832648929',   // mobile number shown on the landing page, footer and the call button
  WHATSAPP_NUMBER: '01832648929', // WhatsApp number (footer link opens wa.me/880...)
  // Default social links — used whenever the Admin has not saved a different link in সেটিংস.
  SOCIAL_DEFAULTS: {
    fbPage: 'https://www.facebook.com/amarsonchoy',
    fbGroup: 'https://www.facebook.com/groups/amarsonchoy',
    youtube: 'https://www.youtube.com/@AmarSonchoy',
    tiktok: 'https://www.tiktok.com/@amarsonchoy',
    instagram: 'https://www.instagram.com/amarsonchoy/'
  },
  TIMEZONE: 'Asia/Dhaka',
  SESSION_HOURS: 72,
  MAX_FAILED_LOGINS: 5,
  LOCKOUT_MINUTES: 15,
  STALE_CONFIRMATION_HOURS: 48,
  SAVINGS_BONUS_ANNUAL_PERCENT: 6, // DEFAULT yearly profit % (used until the Admin sets one in the app; a customer may also have a personal rate). Profit is accrued DAILY (v51).
  GEO_FAR_METERS: 300,             // v55: a collection logged further than this from the customer's saved spot is flagged 'Far'
  GEO_MAX_ACCURACY_M: 100,         // v55: only a reading at least this precise may set a customer's reference spot
  REFERRAL_BONUS_AMOUNT: 20,       // Upgrade 8: bonus (each side) when a referred customer deposits for the first time
  MISSED_AT_RISK_THRESHOLD: 3,     // Upgrade 6: missed intervals before a plan is flagged AtRisk
  MISSED_AUTO_PAUSE_THRESHOLD: 5,  // Upgrade 6: missed intervals before a plan is auto-paused

  // --- Upgrades 11–14 ---
  SCHEMA_VERSION: '29.0',              // bump this whenever SCHEMA changes; the app then repairs the sheets by itself on the next page load
  APP_VERSION: 'v91 (2026-10-30) brand-AmarSonchoy-all+transactions-page+no-customer-confirm+homescreen',     // shown in the Admin "সেটিংস" page so you can confirm which delivered zip is actually deployed
  OFFLINE_MAX_AGE_DAYS: 14,            // Upgrade 11: an offline-queued deposit older than this is booked at sync time instead
  INACTIVE_DAYS: 30,                   // Upgrade 12: no deposit for this many days = "inactive" customer
  SEASON_SAVE_BUFFER_DAYS: 3,          // Upgrade 12: suggested "save by" date is this many days before the festival
  DEFAULT_REMINDER_DAYS_BEFORE: 45,    // Upgrade 12: how many days before the season the automatic SMS goes out
  BACKUP_KEEP_COPIES: 30,              // Upgrade 13: how many daily backup copies to keep in Google Drive
  REPORT_EMAIL: '',                    // মাসিক রিপোর্ট যে ইমেইলে যাবে। ফাঁকা রাখলে স্ক্রিপ্টের মালিকের (যে অ্যাকাউন্টে অ্যাপ ডিপ্লয় করা) ইমেইলে যাবে
  BACKUP_FOLDER_NAME: 'AmarSonchoy_Backups',
  BACKUP_FILE_PREFIX: 'AmarSonchoy_Backup_',
  DEFAULT_BRANCH: 'মালদ গাঁও',            // Upgrade 14: branch given to everyone who does not choose one
  // v64: every village is a branch. Add new village names here when you expand.
  BRANCHES: ['মালদ গাঁও', 'নাপিতপাড়া', 'খনগাও', 'স্কুলপাড়া', 'সাহাপাড়া শ্রীমন্তপুর', 'বাসুদেবপুর',
             'জালিয়াপাড়া', 'বালিহাড়া', 'বৃষ্টপুর', 'জিনগাও', 'হাজিমোর', 'মুলদুয়ার'],
  LEGACY_BRANCHES: ['বোচাগঞ্জ', 'সেতাবগঞ্জ'], // v64: old branch names already saved in the sheets — treated as DEFAULT_BRANCH so old records keep working
  ARCHIVE_AFTER_DAYS: 90               // Upgrade 14: finished plans older than this can be archived
};

// ---------------------------------------------------------------------------
// 1b. STREAK MILESTONES — Upgrade 8. Add/edit rows to change the reward ladder.
// ---------------------------------------------------------------------------
const STREAK_MILESTONES = [
  { count: 10, bonus: 50, badge: 'ব্রোঞ্জ' },
  { count: 25, bonus: 75, badge: 'সিলভার' },
  { count: 50, bonus: 100, badge: 'গোল্ড' }
];

// ---------------------------------------------------------------------------
// 1c. SEASONAL GOAL TEMPLATES — Upgrade 12. Edit names/amounts freely.
//     Eid and Puja dates move every year, so the Admin sets them per campaign;
//     Pohela Boishakh (14 April) never moves, so it carries its own date.
// ---------------------------------------------------------------------------
const SEASONAL_TEMPLATES = [
  { key: 'eid',      label: 'ঈদ',            icon: 'moon',           goalName: 'ঈদের কেনাকাটা',           category: 'Clothing', suggestedAmount: 5000 },
  { key: 'puja',     label: 'পূজা',          icon: 'flower-2',       goalName: 'পূজার কেনাকাটা',          category: 'Clothing', suggestedAmount: 4000 },
  { key: 'boishakh', label: 'পহেলা বৈশাখ',   icon: 'sparkles',       goalName: 'পহেলা বৈশাখের কেনাকাটা',  category: 'Clothing', suggestedAmount: 2500, defaultMonthDay: { month: 4, day: 14 } },
  { key: 'school',   label: 'স্কুল ভর্তি',    icon: 'graduation-cap', goalName: 'স্কুল ভর্তির খরচ',         category: 'Custom',   suggestedAmount: 6000 }
];

// ---------------------------------------------------------------------------
// 2. SCHEMA — single source of truth for every sheet's column order
// ---------------------------------------------------------------------------
const SCHEMA = {
  Users: ['UserID', 'Name', 'Phone', 'PIN', 'Role', 'Status',
          'FailedLoginAttempts', 'LockedUntil', 'CreatedAt',
          'Badge', 'StreakCount', 'ReferralCode', 'ReferredByUserID', 'ReferralBonusAwarded',
          'Branch', 'TermsAcceptedAt', 'MonthlyTargetAmount', 'FamilyID', 'MustChangePIN', 'ProfitRatePercent'],
  Products: ['ProductID', 'Category', 'ItemName', 'EstPrice', 'Description', 'Status', 'ImageUrl'],
  Plans: ['PlanID', 'CustomerID', 'CategoryType', 'ProductID', 'ItemOrGoalName',
          'TargetAmount', 'SavingFrequency', 'InstallmentAmount', 'AccumulatedSavings',
          'Status', 'PreviousStatus', 'PendingAction', 'PendingActionReason',
          'StartDate', 'TargetEndDate', 'AccruedSavingsBonus', 'LastBonusAccrualDate',
          'LastDepositDate', 'MissedIntervalCount', 'GroupID', 'SeasonKey', 'ArchivedAt', 'ProfitAccrued',
          'MissedDays', 'MissedCheckedDay'],
  Transactions: ['TxnID', 'PlanID', 'CustomerID', 'Amount', 'PaymentMethod',
                 'TrxID_Receipt', 'VerifiedByManagerID', 'CustomerConfirmed',
                 'TxnType', 'Timestamp', 'SettledInSettlementID', 'ClientRefID', 'SyncedAt',
                 'ClaimStatus', 'ClaimedAt', 'VerificationNote', 'PaidToNumber', 'DecidedAt',
                 'GeoLat', 'GeoLng', 'GeoAccuracyM', 'GeoDistanceM', 'GeoFlag'],
  AuditLogs: ['LogID', 'UserID', 'Action', 'Details', 'Timestamp'],
  SMSLogs: ['LogID', 'CustomerPhone', 'MessageText', 'SentStatus', 'Timestamp'],
  ManagerCashSettlements: ['SettlementID', 'ManagerID', 'SettlementDate', 'DeclaredCashAmount',
                            'SystemLoggedCashAmount', 'Discrepancy', 'Status', 'AdminNote', 'Timestamp'],
  CommitteeGroups: ['GroupID', 'GroupCode', 'GroupName', 'TargetAmount', 'CreatedByUserID',
                     'Status', 'CreatedAt', 'TargetEndDate'],
  // Upgrade 12
  SeasonalCampaigns: ['CampaignID', 'TemplateKey', 'Title', 'SeasonDate', 'SuggestedAmount',
                      'ReminderDaysBefore', 'Status', 'LastReminderAt', 'ReminderCount',
                      'CreatedAt', 'CreatedByUserID'],
  CampaignReminders: ['ReminderID', 'CampaignID', 'CustomerID', 'SentAt'],
  // Upgrade 22
  Families: ['FamilyID', 'FamilyName', 'FamilyCode', 'CreatedByUserID', 'Status', 'CreatedAt'],
  // Upgrade 23: a customers-only mirror of Users, kept in sync automatically —
  // handy for a quick read-only list/export without wading through managers/admins.
  // Upgrade 27: customer-requested PARTIAL withdrawals, approved by the Admin. Money only moves
  // (Plans + Transactions) at approval time; this sheet is just the request/approval record.
  WithdrawalRequests: ['RequestID', 'PlanID', 'CustomerID', 'Amount', 'PaymentMethod', 'Reason',
                       'Status', 'RequestedAt', 'DecidedAt', 'DecidedByUserID', 'AdminNote', 'TxnID'],
  // Upgrade 28: one row per plan per month once that month's profit has been credited (also makes the credit run safe to repeat).
  // LEGACY (v50 monthly credits) — read only by migrateToDailyProfit(); nothing writes here any more.
  ProfitLogs: ['LogID', 'PlanID', 'CustomerID', 'Month', 'AvgBalance', 'RatePercent', 'Amount', 'CreditedAt'],
  Customers: ['UserID', 'Name', 'Phone', 'Branch', 'Status', 'JoinedAt', 'ReferralCode', 'ReferredByUserID', 'FamilyID', 'StreakCount', 'Badge'],
  // Upgrade 24: extended KYC-style profile — every field optional, saveable blank.
  CustomerProfiles: ['UserID', 'PhotoUrl', 'NID', 'NIDPhotoUrl', 'SpouseName', 'Address', 'ShopName', 'AltPhone',
                      'NomineeName', 'NomineeRelation', 'NomineePhone', 'NomineeNID', 'NomineeNIDPhotoUrl',
                      'NomineePhotoUrl', 'NomineeAddress', 'UpdatedAt', 'Area',
                      'HomeLat', 'HomeLng', 'HomeLocSetAt'],
  // v65: বাজেট প্ল্যানার (50/30/20)। প্রতিটি ব্যবহারকারীর (Admin / Manager / Customer) প্রতি মাসে একটি সংরক্ষিত বাজেট।
  // Month = 'yyyy-MM'। *Actual = ওই মাসের বাস্তব খরচ/সঞ্চয়; *Target = আয়ের ৫০% / ৩০% / ২০%। ItemsJson = খাতওয়ারি তালিকা।
  BudgetPlans: ['BudgetID', 'UserID', 'UserName', 'Role', 'Branch', 'Month', 'Title', 'Income',
                'NeedsActual', 'WantsActual', 'SavingsActual', 'NeedsTarget', 'WantsTarget', 'SavingsTarget',
                'NeedsPercent', 'WantsPercent', 'SavingsPercent', 'Note', 'ItemsJson', 'CreatedAt', 'UpdatedAt'],
  // v66: এক্সপেন্স ট্র্যাকার (বাজেট প্ল্যানারের নিচে) — Admin / Manager / Customer প্রত্যেকের ব্যক্তিগত খরচের হিসাব।
  // Expenses: প্রতিটি খরচ এক সারি। Date = yyyy-MM-dd, Month = yyyy-MM, Type = Essential (প্রয়োজনীয়) / NonEssential (অপ্রয়োজনীয়)।
  Expenses: ['ExpenseID', 'UserID', 'UserName', 'Role', 'Branch', 'Date', 'Month', 'Category', 'Type', 'Amount',
             'PaymentMethod', 'Note', 'CreatedAt', 'UpdatedAt'],
  // ExpenseBudgets: প্রতি ব্যবহারকারীর প্রতি মাসে একটি সারি — মাসিক আয়, খরচের সীমা, সঞ্চয় লক্ষ্য, খাতওয়ারি সীমা (JSON)।
  ExpenseBudgets: ['ExpBudgetID', 'UserID', 'UserName', 'Role', 'Month', 'Income', 'BudgetLimit', 'SavingsGoal',
                   'CategoryLimitsJson', 'UpdatedAt'],
  // ExpenseGoals: সঞ্চয় লক্ষ্য (যেমন "নতুন ফোন ১৫০০০") — কত জমেছে ও কবে নাগাদ চান।
  ExpenseGoals: ['GoalID', 'UserID', 'UserName', 'Role', 'Title', 'TargetAmount', 'SavedAmount', 'TargetDate',
                 'Status', 'Note', 'CreatedAt', 'UpdatedAt']
};

// v66: যেসব কলাম সবসময় সাধারণ লেখা (Plain text) থাকবে — নইলে Google Sheets "2026-10" বা "2026-10-11" কে তারিখে বদলে ফেলতে পারে।
var TEXT_COLUMNS = {
  Expenses: ['Date', 'Month', 'CreatedAt', 'UpdatedAt'],
  ExpenseBudgets: ['Month', 'UpdatedAt'],
  ExpenseGoals: ['TargetDate', 'CreatedAt', 'UpdatedAt']
};

const ROLES = { ADMIN: 'Admin', MANAGER: 'Manager', CUSTOMER: 'Customer' };
const PLAN_STATUS = {
  ACTIVE: 'Active',
  COMPLETED: 'Completed',
  PAUSED: 'Paused',
  REFUNDED: 'Refunded',
  REFUND_REQUESTED: 'RefundRequested',
  PAUSE_REQUESTED: 'PauseRequested',
  AT_RISK: 'AtRisk' // Upgrade 6: 3+ missed installments, still saving, needs follow-up
};

// ---------------------------------------------------------------------------
// 3. GENERIC HELPERS
// ---------------------------------------------------------------------------

function ok(data) {
  return { ok: true, data: data };
}

function fail(message) {
  return { ok: false, error: message };
}

var SS_MEMO = null; // the Spreadsheet handle is opened once per request (openById is slow)
function getSS() {
  if (!SS_MEMO) SS_MEMO = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
  return SS_MEMO;
}

function getSheet(name) {
  var ss = getSS();
  var sheet = ss.getSheetByName(name);
  if (!sheet) {
    throw new Error('Sheet not found: ' + name + '. Run setupDatabase() first.');
  }
  return sheet;
}

function generateId(prefix) {
  var stamp = new Date().getTime();
  var rand = Math.floor(1000 + Math.random() * 9000);
  return prefix + '-' + stamp + '-' + rand;
}

// ---------------------------------------------------------------------------
// SHEET READ LAYER (v54) — fewer, smaller reads, with no change in what any caller sees.
//  1. Per-execution memo: a sheet is read from Google Sheets at most once per request; every later
//     readSheet/findOne/findAll for it in the same request is served from memory. Callers still get
//     FRESH copies of each row object (several callers delete fields from them), so nothing leaks between calls.
//  2. The memo is thrown away whenever this code writes to that sheet, and completely whenever a script lock is
//     acquired (waitLockFresh) — so anything read after taking a lock is always current. Nothing is cached
//     BETWEEN requests: balances and PINs can never be stale.
//  3. findOneBy / findAllBy: for "row where column = value" lookups they read only that one column, then just
//     the matching rows, instead of the whole sheet (big win on Users / Transactions as they grow).
// ---------------------------------------------------------------------------
var SHEET_MEMO = {};
var FIND_BY_MAX_ROW_READS = 25; // more matches than this -> one full read is cheaper than many row reads

function invalidateSheetMemo(sheetName) {
  if (sheetName) delete SHEET_MEMO[sheetName]; else SHEET_MEMO = {};
  bumpSheetCacheGen_(sheetName); // v72: also throw away the cross-request copy of this sheet
}

// ---------------------------------------------------------------------------
// v72 CROSS-REQUEST SHEET CACHE — the biggest speed-up. Before, EVERY server call re-read whole sheets from Google
// Sheets (slow: ~1-3 s for a big Transactions sheet). Now a sheet read is kept (gzip+base64, in CacheService chunks)
// and shared by all requests until the sheet is written to.
//  * Safe against stale data: every cached copy is stored under a per-sheet "generation" id. Every write through
//    appendRow/appendRows/updateRow/invalidateSheetMemo replaces that id, so the old copy can never be read again.
//    A read that began before a write stores its (old) copy under the OLD id, which nobody looks up any more.
//  * Hand edits typed straight into the Google Sheet are not seen by the app, so a copy also expires by itself
//    after SHEET_CACHE_TTL seconds (5 minutes).
//  * Anything that fails (cache full, too big, unavailable) silently falls back to reading the sheet as before.
// ---------------------------------------------------------------------------
var SHEET_CACHE_TTL = 300;
var SHEET_CACHE_CHUNK = 90000;      // base64 characters per cache entry (limit is 100 KB)
var SHEET_CACHE_MAX_CHUNKS = 60;    // bigger than ~5 MB compressed -> not cached
var SHEET_GEN_MEMO = {};            // per-execution: generation ids already looked up

function newGenId_() { return String(new Date().getTime()) + '' + Math.floor(Math.random() * 1000000); }

function sheetGen_(cache, sheetName) {
  if (SHEET_GEN_MEMO[sheetName]) return SHEET_GEN_MEMO[sheetName];
  var got = cache.getAll(['SG_' + sheetName, 'SG__ALL']);
  var g = got['SG_' + sheetName];
  if (!g) { g = newGenId_(); cache.put('SG_' + sheetName, g, 21600); } // never reuse an id that may have been evicted
  var gen = g + '|' + (got['SG__ALL'] || '0');
  SHEET_GEN_MEMO[sheetName] = gen;
  return gen;
}

function bumpSheetCacheGen_(sheetName) {
  try {
    var cache = CacheService.getScriptCache();
    if (sheetName) {
      cache.put('SG_' + sheetName, newGenId_(), 21600);
      delete SHEET_GEN_MEMO[sheetName];
    } else {
      cache.put('SG__ALL', newGenId_(), 21600);
      SHEET_GEN_MEMO = {};
    }
  } catch (e) { /* cache is only an optimisation */ }
}

function readSheetCache_(sheetName) {
  try {
    var cache = CacheService.getScriptCache();
    var base = 'SD_' + sheetName + '_' + sheetGen_(cache, sheetName);
    var n = Number(cache.get(base + '_n') || 0);
    if (!n) return null;
    var keys = [];
    for (var i = 0; i < n; i++) keys.push(base + '_' + i);
    var parts = cache.getAll(keys);
    var b64 = '';
    for (var j = 0; j < n; j++) {
      var piece = parts[base + '_' + j];
      if (!piece) return null;
      b64 += piece;
    }
    var bytes = Utilities.ungzip(Utilities.newBlob(Utilities.base64Decode(b64), 'application/x-gzip')).getDataAsString();
    return JSON.parse(bytes);
  } catch (e) { return null; }
}

function writeSheetCache_(sheetName, raw) {
  try {
    var cache = CacheService.getScriptCache();
    var gen = sheetGen_(cache, sheetName);
    var json = JSON.stringify(raw);
    var b64 = Utilities.base64Encode(Utilities.gzip(Utilities.newBlob(json, 'application/octet-stream', 'd')).getBytes());
    var n = Math.ceil(b64.length / SHEET_CACHE_CHUNK);
    if (n > SHEET_CACHE_MAX_CHUNKS) return;
    var base = 'SD_' + sheetName + '_' + gen;
    var obj = {};
    for (var i = 0; i < n; i++) obj[base + '_' + i] = b64.substr(i * SHEET_CACHE_CHUNK, SHEET_CACHE_CHUNK);
    obj[base + '_n'] = String(n);
    cache.putAll(obj, SHEET_CACHE_TTL);
  } catch (e) { /* too big or cache unavailable: just skip caching */ }
}

/** lock.waitLock + forget everything read before the lock was won (another request may have written meanwhile). */
function waitLockFresh(lock, timeoutMs) {
  lock.waitLock(timeoutMs);
  SHEET_MEMO = {};
  SHEET_GEN_MEMO = {}; // v72: another request may have written (and bumped the shared-cache id) while we waited
}

function loadSheetRaw(sheetName) {
  var hit = SHEET_MEMO[sheetName];
  if (hit) return hit;
  var shared = readSheetCache_(sheetName); // v72: copy shared between requests (see SHEET CACHE above)
  if (shared) { SHEET_MEMO[sheetName] = shared; return shared; }
  var sheet = getSheet(sheetName);
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  var raw;
  if (lastRow < 2) {
    raw = { headers: [], values: [] };
  } else {
    raw = {
      headers: sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0],
      values: sheet.getRange(2, 1, lastRow - 1, lastCol).getDisplayValues()
    };
  }
  SHEET_MEMO[sheetName] = raw;
  writeSheetCache_(sheetName, raw);
  return raw;
}

/** The shared (cross-request) copy of a sheet if one exists — never triggers a full sheet read. */
function peekSharedSheet_(sheetName) {
  var shared = readSheetCache_(sheetName);
  if (shared) SHEET_MEMO[sheetName] = shared;
  return shared;
}

function rowToObject(headers, rowValues, rowNumber) {
  var obj = {};
  for (var c = 0; c < headers.length; c++) obj[headers[c]] = rowValues[c];
  obj._row = rowNumber; // actual sheet row number, for later updates
  return obj;
}

/**
 * Reads an entire sheet into an array of plain objects keyed by header name.
 * Uses getDisplayValues() so values like a PIN "0042" are never turned into 42.
 * Within one request the sheet is fetched once (see SHEET READ LAYER above).
 */
function readSheet(sheetName) {
  var raw = loadSheetRaw(sheetName);
  var results = [];
  for (var r = 0; r < raw.values.length; r++) results.push(rowToObject(raw.headers, raw.values[r], r + 2));
  return results;
}

/**
 * Rows where  column === value  (strict, like the old findAll(... x.col === value)). Reads only that column
 * unless the whole sheet is already in the request memo. A non-text value never matches (cells are text).
 */
function findAllBy(sheetName, column, value) {
  if (typeof value !== 'string') return [];
  var raw = SHEET_MEMO[sheetName] || peekSharedSheet_(sheetName);
  var out = [], i;
  if (raw) {
    var mc = raw.headers.indexOf(column);
    if (mc === -1) return [];
    for (i = 0; i < raw.values.length; i++) {
      if (raw.values[i][mc] === value) out.push(rowToObject(raw.headers, raw.values[i], i + 2));
    }
    return out;
  }
  var sheet = getSheet(sheetName);
  var lastRow = sheet.getLastRow(), lastCol = sheet.getLastColumn();
  if (lastRow < 2) return [];
  var headers = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0];
  var ci = headers.indexOf(column);
  if (ci === -1) return [];
  var col = sheet.getRange(2, ci + 1, lastRow - 1, 1).getDisplayValues();
  var hits = [];
  for (i = 0; i < col.length; i++) if (col[i][0] === value) hits.push(i + 2);
  if (hits.length > FIND_BY_MAX_ROW_READS) {
    return readSheet(sheetName).filter(function (row) { return row[column] === value; });
  }
  hits.forEach(function (rowNumber) {
    out.push(rowToObject(headers, sheet.getRange(rowNumber, 1, 1, lastCol).getDisplayValues()[0], rowNumber));
  });
  return out;
}

/** First row where column === value, or null. Stops at the first hit (one column read + one row read). */
function findOneBy(sheetName, column, value) {
  if (typeof value !== 'string') return null;
  var raw = SHEET_MEMO[sheetName] || peekSharedSheet_(sheetName);
  var i;
  if (raw) {
    var mc = raw.headers.indexOf(column);
    if (mc === -1) return null;
    for (i = 0; i < raw.values.length; i++) {
      if (raw.values[i][mc] === value) return rowToObject(raw.headers, raw.values[i], i + 2);
    }
    return null;
  }
  var sheet = getSheet(sheetName);
  var lastRow = sheet.getLastRow(), lastCol = sheet.getLastColumn();
  if (lastRow < 2) return null;
  var headers = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0];
  var ci = headers.indexOf(column);
  if (ci === -1) return null;
  var col = sheet.getRange(2, ci + 1, lastRow - 1, 1).getDisplayValues();
  for (i = 0; i < col.length; i++) {
    if (col[i][0] === value) {
      return rowToObject(headers, sheet.getRange(i + 2, 1, 1, lastCol).getDisplayValues()[0], i + 2);
    }
  }
  return null;
}

/**
 * Appends one row to a sheet, built from SCHEMA order so column position
 * mistakes are impossible. Missing keys are written as empty string.
 */
function appendRow(sheetName, rowObject) {
  var sheet = getSheet(sheetName);
  var headers = SCHEMA[sheetName];
  var row = headers.map(function (h) {
    return (rowObject[h] !== undefined && rowObject[h] !== null) ? rowObject[h] : '';
  });
  sheet.appendRow(row);
  invalidateSheetMemo(sheetName);
}

/**
 * Appends many rows in ONE sheet write (much faster than calling appendRow in
 * a loop). Built from SCHEMA order exactly like appendRow.
 */
function appendRows(sheetName, rowObjects) {
  if (!rowObjects || rowObjects.length === 0) return;
  var sheet = getSheet(sheetName);
  var headers = SCHEMA[sheetName];
  var values = rowObjects.map(function (obj) {
    return headers.map(function (h) {
      return (obj[h] !== undefined && obj[h] !== null) ? obj[h] : '';
    });
  });
  sheet.getRange(sheet.getLastRow() + 1, 1, values.length, headers.length).setValues(values);
  invalidateSheetMemo(sheetName);
}

/**
 * Updates only the given keys on an existing row, identified by its
 * actual sheet row number (the _row field returned by readSheet).
 */
function updateRow(sheetName, rowNumber, partialObject) {
  var sheet = getSheet(sheetName);
  var headers = SCHEMA[sheetName];
  Object.keys(partialObject).forEach(function (key) {
    var colIndex = headers.indexOf(key);
    if (colIndex === -1) {
      throw new Error('Unknown column "' + key + '" for sheet ' + sheetName);
    }
    sheet.getRange(rowNumber, colIndex + 1).setValue(partialObject[key]);
  });
  invalidateSheetMemo(sheetName);
}

function findOne(sheetName, matchFn) {
  var rows = readSheet(sheetName);
  for (var i = 0; i < rows.length; i++) {
    if (matchFn(rows[i])) return rows[i];
  }
  return null;
}

function findAll(sheetName, matchFn) {
  return readSheet(sheetName).filter(matchFn);
}

/**
 * Writes one row to AuditLogs. Never allowed to break the calling function,
 * so any internal error here is only logged to the execution log.
 */
function logAudit(userId, action, details) {
  try {
    appendRow('AuditLogs', {
      LogID: generateId('LOG'),
      UserID: userId || '',
      Action: action || '',
      Details: details || '',
      Timestamp: new Date().toISOString()
    });
  } catch (err) {
    Logger.log('logAudit failed: ' + err);
  }
}

/**
 * Writes one simulated SMS receipt in Bengali. In this foundation version
 * it only logs to the SMSLogs sheet (SentStatus "Simulated") — wiring it to
 * a real SMS gateway can be added later without changing any caller.
 */
function logSms(phone, message) {
  try {
    appendRow('SMSLogs', {
      LogID: generateId('SMS'),
      CustomerPhone: phone || '',
      MessageText: message || '',
      SentStatus: 'Simulated',
      Timestamp: new Date().toISOString()
    });
  } catch (err) {
    Logger.log('logSms failed: ' + err);
  }
}

// ---------------------------------------------------------------------------
// 3b. SHARED HELPERS FOR UPGRADES 11–14
// ---------------------------------------------------------------------------

const DAY_MS = 86400000;

/**
 * Removes the few characters (< > " `) that could break the page when a
 * name, goal title or note typed by a user is shown back on screen.
 */
function cleanText(value) {
  return String(value === undefined || value === null ? '' : value).replace(/[<>"`]/g, '').trim();
}

/** True only when the terms checkbox value sent by the browser means "accepted". */
function isTermsAccepted(value) {
  return value === true || value === 'true' || value === 'Yes' || value === 'yes';
}

/** Calendar date (Dhaka time) as yyyy-MM-dd. */
function dhakaDateStr(dateObj) {
  return Utilities.formatDate(dateObj, CONFIG.TIMEZONE, 'yyyy-MM-dd');
}

/**
 * Turns an <input type="date"> value (yyyy-MM-dd) into a Date at 12:00 noon
 * Dhaka time, so the calendar day never shifts whatever timezone the script runs in.
 * Returns null when the text is not a valid date.
 */
function parseDateInputNoonDhaka(str) {
  str = String(str || '').trim();
  if (!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(str)) return null;
  var d = new Date(str + 'T12:00:00+06:00');
  return isNaN(d.getTime()) ? null : d;
}

/** Whole calendar days from today (Dhaka) until the given date. Negative = already passed. */
function daysUntil(dateObj) {
  var a = new Date(dhakaDateStr(new Date()) + 'T12:00:00+06:00').getTime();
  var b = new Date(dhakaDateStr(dateObj) + 'T12:00:00+06:00').getTime();
  return Math.round((b - a) / DAY_MS);
}

/** One CSV cell. Text starting with = + - @ is prefixed so Excel never runs it as a formula. */
function csvEscapeCell(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'number') return String(v);
  var s = String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  if (/[",\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function buildCsv(headers, rows) {
  var lines = [headers.map(csvEscapeCell).join(',')];
  rows.forEach(function (row) {
    lines.push(row.map(csvEscapeCell).join(','));
  });
  return lines.join('\r\n');
}

// ---------------------------------------------------------------------------
// 4. DATABASE SETUP
// ---------------------------------------------------------------------------

/**
 * Idempotent: safe to run again and again. Creates any missing sheet,
 * writes/repairs headers, freezes row 1. Never deletes existing data.
 */
function setupDatabase() {
  var ss = getSS();
  invalidateSheetMemo();

  Object.keys(SCHEMA).forEach(function (sheetName) {
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
    }
    var headers = SCHEMA[sheetName];
    if (sheet.getMaxColumns() < headers.length) {
      sheet.insertColumnsAfter(sheet.getMaxColumns(), headers.length - sheet.getMaxColumns());
    }
    var lastCol = Math.max(sheet.getLastColumn(), headers.length);
    var firstRow = sheet.getRange(1, 1, 1, lastCol).getDisplayValues()[0];
    var headersMatch = headers.every(function (h, i) { return firstRow[i] === h; });
    if (!headersMatch) {
      sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
    sheet.setFrozenRows(1);
    (TEXT_COLUMNS[sheetName] || []).forEach(function (col) {
      var ci = headers.indexOf(col);
      if (ci >= 0) sheet.getRange(2, ci + 1, Math.max(sheet.getMaxRows() - 1, 1), 1).setNumberFormat('@');
    });
  });

  // Remove the default "Sheet1" if Apps Script created it and it's unused/empty
  var defaultSheet = ss.getSheetByName('Sheet1');
  if (defaultSheet && defaultSheet.getLastRow() === 0 && ss.getSheets().length > 1) {
    ss.deleteSheet(defaultSheet);
  }

  seedSampleProducts();
  migrateToDailyProfit();
  PropertiesService.getScriptProperties().setProperty('SCHEMA_VERSION', CONFIG.SCHEMA_VERSION);

  return ok('setupDatabase সম্পন্ন হয়েছে। সব শিট প্রস্তুত।');
}

/**
 * Called on every page load. When CONFIG.SCHEMA_VERSION differs from the one
 * last applied, it runs setupDatabase() by itself, so new columns/sheets from an
 * upgrade appear automatically the first time the updated app is opened.
 * Cheap when nothing changed (one property read). Never breaks the page.
 */
function ensureSchemaUpToDate() {
  var props = PropertiesService.getScriptProperties();
  if (props.getProperty('SCHEMA_VERSION') === CONFIG.SCHEMA_VERSION) return;
  var lock = LockService.getScriptLock();
  try {
    waitLockFresh(lock, 20000);
    if (props.getProperty('SCHEMA_VERSION') === CONFIG.SCHEMA_VERSION) return;
    setupDatabase();
    props.setProperty('SCHEMA_VERSION', CONFIG.SCHEMA_VERSION);
  } catch (err) {
    Logger.log('ensureSchemaUpToDate failed: ' + err);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

function seedSampleProducts() {
  var existing = readSheet('Products');
  if (existing.length > 0) return; // already seeded, don't duplicate

  var samples = [
    { Category: 'Mobile', ItemName: 'Symphony স্মার্টফোন (বেসিক মডেল)', EstPrice: 8000, Description: '৪জি সাপোর্ট, স্টুডেন্টদের জন্য উপযোগী' },
    { Category: 'Mobile', ItemName: 'Xiaomi Redmi সিরিজ স্মার্টফোন', EstPrice: 14000, Description: 'মিড-রেঞ্জ স্মার্টফোন' },
    { Category: 'Electronics', ItemName: 'বৈদ্যুতিক ফ্যান (স্ট্যান্ড)', EstPrice: 3000, Description: 'গরমকালের জন্য দরকারি' },
    { Category: 'Electronics', ItemName: 'ছোট টিভি (২৪ ইঞ্চি)', EstPrice: 9000, Description: 'পারিবারিক বিনোদনের জন্য' },
    { Category: 'Clothing', ItemName: 'ঈদের পোশাক প্যাকেজ (পরিবার)', EstPrice: 5000, Description: 'ঈদ উপলক্ষে সম্পূর্ণ পরিবারের পোশাক' },
    { Category: 'Grocery', ItemName: 'চালের মজুদ (৫০ কেজি)', EstPrice: 3000, Description: 'লিন সিজনের জন্য চালের রিজার্ভ' },
    { Category: 'Grocery', ItemName: 'নিত্যপ্রয়োজনীয় মুদি প্যাকেজ', EstPrice: 2000, Description: 'তেল, ডাল, লবণ ইত্যাদি' },
    { Category: 'Custom', ItemName: 'জরুরি তহবিল (স্বাধীন লক্ষ্য)', EstPrice: 5000, Description: 'যেকোনো জরুরি প্রয়োজনের জন্য নিজের লক্ষ্য ঠিক করুন' }
  ];

  samples.forEach(function (p) {
    appendRow('Products', {
      ProductID: generateId('PRD'),
      Category: p.Category,
      ItemName: p.ItemName,
      EstPrice: p.EstPrice,
      Description: p.Description,
      Status: 'Active'
    });
  });
}

/**
 * Run this once manually from the Apps Script editor to create your first
 * Admin account. Select this function in the dropdown at the top and click Run.
 */
function createFirstAdmin(name, phone, pin) {
  try {
    if (!name || !phone || !pin) {
      Logger.log('ব্যবহার: createFirstAdmin("আপনার নাম", "01XXXXXXXXX", "1234")');
      return fail('নাম, ফোন এবং PIN দিন।');
    }
    var validation = validatePhoneAndPin(phone, pin);
    if (!validation.ok) return validation;

    var existing = findOneBy('Users', 'Phone', phone);
    if (existing) return fail('এই ফোন নম্বর দিয়ে আগে থেকেই একটি অ্যাকাউন্ট আছে।');

    appendRow('Users', {
      UserID: generateId('USR'),
      Name: name,
      Phone: phone,
      PIN: pin,
      Role: ROLES.ADMIN,
      Status: 'Active',
      FailedLoginAttempts: 0,
      LockedUntil: '',
      CreatedAt: new Date().toISOString(),
      Badge: '',
      StreakCount: 0,
      ReferralCode: generateUniqueReferralCode(phone),
      ReferredByUserID: '',
      ReferralBonusAwarded: 'No',
      Branch: getDefaultBranchName_(),
      TermsAcceptedAt: ''
    });
    Logger.log('অ্যাডমিন তৈরি হয়েছে: ' + name + ' (' + phone + ')');
    return ok('অ্যাডমিন তৈরি হয়েছে।');
  } catch (err) {
    Logger.log('Error in createFirstAdmin: ' + err);
    return fail('সমস্যা হয়েছে: ' + err.message);
  }
}

// ---------------------------------------------------------------------------
// 41. DEMO DATA SEEDING — Upgrade 23
//     Run seedDemoData() ONCE from the Apps Script editor (select it in the
//     dropdown at the top and click Run) to create a working Admin, 2
//     Managers, 5 Customers, and enough plans/deposits/groups/campaigns to
//     see and test every feature in the app immediately. Safe to run again —
//     it checks for the demo admin's phone number first and stops if the
//     demo data already exists, so it never creates duplicates.
// ---------------------------------------------------------------------------
function seedDemoData() {
  try {
    ensureSchemaUpToDate(); // make sure every sheet/column (and the sample products) exists first

    var ADMIN_PHONE = '01711000001';
    if (findOneBy('Users', 'Phone', ADMIN_PHONE)) {
      Logger.log('ডেমো ডেটা আগেই তৈরি করা আছে (ফোন ' + ADMIN_PHONE + ' পাওয়া গেছে) — নতুন করে কিছু তৈরি করা হয়নি।');
      return ok('ডেমো ডেটা আগে থেকেই আছে।');
    }

    function daysAgoIso(n) {
      return new Date(Date.now() - n * DAY_MS).toISOString();
    }
    function dateStrDaysFromNow(n) {
      return Utilities.formatDate(new Date(Date.now() + n * DAY_MS), CONFIG.TIMEZONE, 'yyyy-MM-dd');
    }

    // ---- 1) ADMIN --------------------------------------------------------
    var adminUser = {
      UserID: generateId('USR'), Name: 'সাইফুল ইসলাম (এডমিন)', Phone: ADMIN_PHONE, PIN: '1234',
      Role: ROLES.ADMIN, Status: 'Active', FailedLoginAttempts: 0, LockedUntil: '',
      CreatedAt: daysAgoIso(200), Badge: '', StreakCount: 0,
      ReferralCode: generateUniqueReferralCode(ADMIN_PHONE), ReferredByUserID: '', ReferralBonusAwarded: 'No',
      Branch: getDefaultBranchName_(), TermsAcceptedAt: daysAgoIso(200), MonthlyTargetAmount: '', FamilyID: ''
    };
    appendRow('Users', adminUser);
    var adminToken = createSession(adminUser);
    logAudit(adminUser.UserID, 'DEMO_SEED', 'ডেমো অ্যাডমিন তৈরি হয়েছে');

    // ---- 2) MANAGERS (one per branch) -------------------------------------
    var managerDefs = [
      { name: 'রফিকুল ইসলাম', phone: '01711000002', pin: '1234', branch: CONFIG.BRANCHES[0], target: 20000 },
      { name: 'সালমা খাতুন', phone: '01711000003', pin: '1234', branch: CONFIG.BRANCHES[1] || CONFIG.BRANCHES[0], target: 15000 }
    ];
    var managers = [];
    for (var mi = 0; mi < managerDefs.length; mi++) {
      var mDef = managerDefs[mi];
      var mRes = createManager(adminToken, mDef.name, mDef.phone, mDef.pin, mDef.branch);
      if (!mRes.ok) {
        Logger.log('ম্যানেজার তৈরি করা যায়নি (' + mDef.phone + '): ' + mRes.error);
        return fail('ম্যানেজার তৈরি করা যায়নি: ' + mRes.error);
      }
      var mUser = findOneBy('Users', 'Phone', mDef.phone);
      if (!mUser) return fail('ম্যানেজার তৈরি হয়েছে কিন্তু খুঁজে পাওয়া যাচ্ছে না (' + mDef.phone + ')।');
      updateRow('Users', mUser._row, { MonthlyTargetAmount: mDef.target });
      managers.push(findOneBy('Users', 'Phone', mDef.phone));
    }
    var manager1Token = createSession(managers[0]);

    // ---- 3) CUSTOMERS ------------------------------------------------------
    // Registered through the real registerUser() flow so referral codes,
    // sessions and validation all behave exactly like a real signup.
    var customerDefs = [
      { name: 'রহিমা বেগম', phone: '01711000011', pin: '1111', branch: CONFIG.BRANCHES[0], joinedDaysAgo: 150, referralOf: null },
      { name: 'করিম উদ্দিন', phone: '01711000012', pin: '2222', branch: CONFIG.BRANCHES[0], joinedDaysAgo: 95, referralOf: 0 },
      { name: 'সালমা আক্তার', phone: '01711000013', pin: '3333', branch: CONFIG.BRANCHES[1] || CONFIG.BRANCHES[0], joinedDaysAgo: 65, referralOf: null },
      { name: 'আব্দুল হক', phone: '01711000014', pin: '4444', branch: CONFIG.BRANCHES[1] || CONFIG.BRANCHES[0], joinedDaysAgo: 35, referralOf: null },
      { name: 'নাসরিন আক্তার', phone: '01711000015', pin: '5555', branch: CONFIG.BRANCHES[0], joinedDaysAgo: 28, referralOf: 1 }
    ];
    var customers = []; // will hold { user, token, referralCode }
    for (var ci = 0; ci < customerDefs.length; ci++) {
      var cDef = customerDefs[ci];
      var refCode = (cDef.referralOf !== null) ? customers[cDef.referralOf].referralCode : '';
      var cReg = registerUser(cDef.name, cDef.phone, cDef.pin, refCode, true, cDef.branch);
      if (!cReg.ok) {
        Logger.log('গ্রাহক তৈরি করা যায়নি (' + cDef.phone + '): ' + cReg.error);
        return fail('গ্রাহক তৈরি করা যায়নি (' + cDef.phone + '): ' + cReg.error);
      }
      var cUserRow = findOneBy('Users', 'Phone', cDef.phone);
      if (!cUserRow) return fail('গ্রাহক তৈরি হয়েছে কিন্তু খুঁজে পাওয়া যাচ্ছে না (' + cDef.phone + ')।');
      updateRow('Users', cUserRow._row, { CreatedAt: daysAgoIso(cDef.joinedDaysAgo), TermsAcceptedAt: daysAgoIso(cDef.joinedDaysAgo) });
      cUserRow = findOneBy('Users', 'Phone', cDef.phone);
      customers.push({ user: cUserRow, token: createSession(cUserRow), referralCode: cReg.data.referralCode });
    }
    var c1 = customers[0], c2 = customers[1], c3 = customers[2], c4 = customers[3], c5 = customers[4];

    // ---- 4) PRODUCTS (used by a few plans, to show "কতজন সঞ্চয় করছেন") -----
    var products = readSheet('Products');
    function productByName(partial) {
      var p = products.filter(function (x) { return x.ItemName.indexOf(partial) !== -1; })[0];
      return p ? p.ProductID : '';
    }
    var mobileProductId = productByName('Redmi');
    var clothingProductId = productByName('ঈদের পোশাক');
    var riceProductId = productByName('চালের মজুদ');

    // ---- 5) PLANS ------------------------------------------------------
    /** Creates a plan, then backdates its StartDate so it lines up with its oldest demo deposit. */
    function makePlan(customerToken, opts, startedDaysAgo) {
      var res = createPlan(customerToken, opts);
      if (!res.ok) { Logger.log('makePlan failed: ' + res.error); return null; }
      var plan = findOneBy('Plans', 'PlanID', res.data.PlanID);
      updateRow('Plans', plan._row, { StartDate: daysAgoIso(startedDaysAgo + 2), LastBonusAccrualDate: daysAgoIso(startedDaysAgo + 2) });
      return findOneBy('Plans', 'PlanID', res.data.PlanID);
    }

    /** Appends historical deposits (oldest first) and runs the same effects a real deposit would trigger. */
    function seedDeposits(plan, managerId, amount, daysAgoList) {
      daysAgoList.slice().sort(function (a, b) { return b - a; }).forEach(function (daysAgo) {
        var iso = daysAgoIso(daysAgo);
        var isFirstEver = findAll('Transactions', function (t) { return t.CustomerID === plan.CustomerID && t.TxnType === 'Deposit'; }).length === 0;
        appendRow('Transactions', {
          TxnID: generateId('TXN'), PlanID: plan.PlanID, CustomerID: plan.CustomerID, Amount: amount,
          PaymentMethod: 'Cash', TrxID_Receipt: '', VerifiedByManagerID: managerId, CustomerConfirmed: 'Yes',
          TxnType: 'Deposit', Timestamp: iso, SettledInSettlementID: '', ClientRefID: '', SyncedAt: iso,
          ClaimStatus: '', ClaimedAt: '', VerificationNote: ''
        });
        plan = findOneBy('Plans', 'PlanID', plan.PlanID);
        applyDepositEffects(plan, amount, iso, isFirstEver);
        plan = findOneBy('Plans', 'PlanID', plan.PlanID);
      });
      return plan;
    }

    // C1 — long-time active saver, passes the 10-deposit Bronze badge, referred C2.
    var c1Plan = makePlan(c1.token, {
      categoryType: 'Mobile', itemOrGoalName: 'মোবাইল ফোনের জন্য সঞ্চয়', targetAmount: 8000,
      savingFrequency: 'Weekly', targetEndDate: dateStrDaysFromNow(70), productId: mobileProductId
    }, 95);
    if (c1Plan) seedDeposits(c1Plan, managers[0].UserID, 150, [95, 65, 35, 23, 21, 19, 17, 15, 13, 11, 9, 7, 5, 3, 1]);

    // C2 — referred by C1 (first deposit triggers C1's referral bonus); active, then quiet for a
    // few days so it shows up in the Manager's "সঞ্চয়ের ধারা ভাঙছে" early-warning list.
    var c2Plan = makePlan(c2.token, {
      categoryType: 'Clothing', itemOrGoalName: 'ঈদের পোশাক কেনা', targetAmount: 5000,
      savingFrequency: 'Weekly', targetEndDate: dateStrDaysFromNow(50), productId: clothingProductId
    }, 80);
    if (c2Plan) seedDeposits(c2Plan, managers[0].UserID, 200, [80, 50, 20, 18, 15, 12, 9, 6]);

    // C3 — very active recent saver (passes Bronze badge too), part of the demo Family.
    var c3Plan = makePlan(c3.token, {
      categoryType: 'Electronics', itemOrGoalName: 'ল্যাপটপের জন্য সঞ্চয়', targetAmount: 15000,
      savingFrequency: 'Daily', targetEndDate: dateStrDaysFromNow(180)
    }, 30);
    if (c3Plan) seedDeposits(c3Plan, managers[1].UserID, 300, [30, 14, 12, 10, 8, 6, 4, 3, 2, 1, 0]);

    // C4 — only 2 early deposits, then manually flagged AtRisk (what the daily missed-check job
    // would do on its own) to demo the Follow-up list / AtRisk badge right away.
    var c4Plan = makePlan(c4.token, {
      categoryType: 'Clothing', itemOrGoalName: 'কাপড়ের জন্য সঞ্চয়', targetAmount: 4000,
      savingFrequency: 'Weekly', targetEndDate: dateStrDaysFromNow(40)
    }, 28);
    if (c4Plan) {
      c4Plan = seedDeposits(c4Plan, managers[1].UserID, 200, [28, 21]);
      updateRow('Plans', c4Plan._row, { Status: PLAN_STATUS.AT_RISK, PreviousStatus: PLAN_STATUS.ACTIVE, MissedIntervalCount: 3 });
    }

    // C5 — referred by C2; a small goal that fully completes on its last deposit (demos the
    // Completed state, the passbook and the QR receipt on a real paid-off goal).
    var c5Plan = makePlan(c5.token, {
      categoryType: 'Grocery', itemOrGoalName: 'চালের মজুদ', targetAmount: 2500,
      savingFrequency: 'Weekly', targetEndDate: dateStrDaysFromNow(30), productId: riceProductId
    }, 25);
    if (c5Plan) seedDeposits(c5Plan, managers[0].UserID, 500, [25, 18, 11, 4, 0]);

    // ---- 6) COMMITTEE (GROUP) SAVINGS — C1 creates it, C5 joins -----------
    var groupRes = createCommitteeGroup(c1.token, {
      groupName: 'প্রতিবেশী সঞ্চয় দল', targetAmount: 10000, targetEndDate: dateStrDaysFromNow(90),
      contributionAmount: 4000, savingFrequency: 'Weekly'
    });
    if (groupRes.ok) {
      var c1GroupPlan = findOne('Plans', function (p) { return p.CustomerID === c1.user.UserID && p.GroupID === groupRes.data.groupId; });
      if (c1GroupPlan) seedDeposits(c1GroupPlan, managers[0].UserID, 300, [16, 9, 2]);

      var joinRes = joinCommitteeGroupByCode(c5.token, groupRes.data.groupCode, { contributionAmount: 3000, savingFrequency: 'Weekly' });
      if (joinRes.ok) {
        var c5GroupPlan = findOne('Plans', function (p) { return p.CustomerID === c5.user.UserID && p.GroupID === groupRes.data.groupId; });
        if (c5GroupPlan) seedDeposits(c5GroupPlan, managers[0].UserID, 300, [10, 3]);
      }
    }

    // ---- 7) FAMILY PLAN — C3 creates it, C4 joins -------------------------
    var familyRes = createFamily(c3.token, 'আক্তার পরিবার');
    if (familyRes.ok) joinFamily(c4.token, familyRes.data.familyCode);

    // ---- 8) SEASONAL CAMPAIGN (for the public landing-page banner) --------
    createSeasonalCampaign(adminToken, {
      templateKey: 'eid', seasonDate: dateStrDaysFromNow(35), suggestedAmount: 6000, reminderDaysBefore: 20
    });

    syncCustomersSheet();

    var summary = 'ডেমো ডেটা তৈরি হয়েছে —\n' +
      'অ্যাডমিন: ' + ADMIN_PHONE + ' / PIN 1234\n' +
      'ম্যানেজার ১: 01711000002 / PIN 1234 (' + managerDefs[0].branch + ')\n' +
      'ম্যানেজার ২: 01711000003 / PIN 1234 (' + managerDefs[1].branch + ')\n' +
      'গ্রাহক ১-৫: 01711000011-01711000015 / PIN যথাক্রমে 1111-5555';
    Logger.log(summary);
    return ok(summary);
  } catch (err) {
    Logger.log('Error in seedDemoData: ' + err);
    return fail('ডেমো ডেটা তৈরিতে সমস্যা হয়েছে: ' + err.message);
  }
}

/**
 * Run this once manually from the Apps Script editor (select it in the
 * dropdown and click Run) to install the daily savings-bonus trigger.
 * Safe to run again — it removes any old trigger for accrueAllBonuses first.
 */
function setupDailyBonusTrigger() {
  var triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(function (t) {
    if (t.getHandlerFunction() === 'accrueAllBonuses') {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger('accrueAllBonuses')
    .timeBased()
    .everyDays(1)
    .atHour(1)
    .inTimezone(CONFIG.TIMEZONE)
    .create();
  Logger.log('দৈনিক সঞ্চয় বোনাস ট্রিগার তৈরি হয়েছে — প্রতিদিন রাত ১টায় চলবে।');
}

/**
 * Run this once manually (Upgrade 6) to install the daily missed-installment
 * check trigger. Safe to run again — removes any old trigger first.
 */
function setupMissedInstallmentTrigger() {
  var triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(function (t) {
    if (t.getHandlerFunction() === 'runMissedInstallmentCheck') {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger('runMissedInstallmentCheck')
    .timeBased()
    .everyDays(1)
    .atHour(8)
    .inTimezone(CONFIG.TIMEZONE)
    .create();
  Logger.log('দৈনিক কিস্তি-মিস চেক ট্রিগার তৈরি হয়েছে — প্রতিদিন সকাল ৮টায় চলবে।');
}

/**
 * Run this once manually (Upgrade 12) to install the daily seasonal-campaign
 * check. Safe to run again — removes any old trigger first.
 */
function setupSeasonalReminderTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'runSeasonalReminderCheck') {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger('runSeasonalReminderCheck')
    .timeBased()
    .everyDays(1)
    .atHour(9)
    .inTimezone(CONFIG.TIMEZONE)
    .create();
  Logger.log('দৈনিক মৌসুমি রিমাইন্ডার চেক ট্রিগার তৈরি হয়েছে — প্রতিদিন সকাল ৯টায় চলবে।');
}

/**
 * Run this once manually (Upgrade 22) to install the daily manager
 * collection-target reminder. Safe to run again — removes any old trigger first.
 * NOTE: like every other reminder in this app, this only LOGS the message to
 * the SMSLogs sheet (see logSms) — it does not actually send an SMS unless
 * a real SMS gateway is wired into logSms().
 */
function setupManagerDailyTargetTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'runManagerDailyTargetReminder') {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger('runManagerDailyTargetReminder')
    .timeBased()
    .everyDays(1)
    .atHour(7)
    .inTimezone(CONFIG.TIMEZONE)
    .create();
  Logger.log('ম্যানেজারের দৈনিক টার্গেট রিমাইন্ডার ট্রিগার তৈরি হয়েছে — প্রতিদিন সকাল ৭টায় চলবে।');
}

/**
 * Run this once manually (Upgrade 13) to install the automatic daily Google
 * Drive backup. Safe to run again — removes any old trigger first.
 * The first run asks for Google Drive permission — click Allow.
 */
function setupBackupTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'runDailyBackup') {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger('runDailyBackup')
    .timeBased()
    .everyDays(1)
    .atHour(3)
    .inTimezone(CONFIG.TIMEZONE)
    .create();
  Logger.log('দৈনিক ব্যাকআপ ট্রিগার তৈরি হয়েছে — প্রতিদিন রাত ৩টায় Google Drive-এ ব্যাকআপ হবে।');
}

/**
 * Run once to install the monthly report e-mail: on the 1st of every month
 * (07:00 Dhaka) the previous month's PDF + Excel report is e-mailed.
 * Safe to run again — removes the old trigger first. The first run asks for
 * permission to send e-mail — click Allow.
 */
function setupMonthlyReportTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'runMonthlyReport') {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger('runMonthlyReport')
    .timeBased()
    .onMonthDay(1)
    .atHour(7)
    .inTimezone(CONFIG.TIMEZONE)
    .create();
  Logger.log('মাসিক রিপোর্ট ট্রিগার তৈরি হয়েছে — প্রতি মাসের ১ তারিখ সকাল ৭টায় ইমেইলে যাবে।');
}

/**
 * Convenience: installs all the automatic triggers in one run
 * (daily bonus / missed-installment / seasonal / backup + monthly report e-mail).
 */
function setupAllTriggers() {
  setupDailyBonusTrigger();
  setupMissedInstallmentTrigger();
  setupSeasonalReminderTrigger();
  setupBackupTrigger();
  setupMonthlyReportTrigger();
  Logger.log('সব স্বয়ংক্রিয় ট্রিগার প্রস্তুত।');
}

// ---------------------------------------------------------------------------
// 5. WEB APP ENTRY POINT
// ---------------------------------------------------------------------------

function doGet(e) {
  ensureSchemaUpToDate();

  // Upgrade 21: best-effort PWA manifest, served at the same URL via a query
  // flag (e.g. ...exec?page=manifest) so "Add to Home Screen" has something
  // to read. NOTE: Apps Script web apps don't reliably support a real
  // service worker / offline caching — see the note in Index.html.
  if (e && e.parameter && e.parameter.page === 'manifest') {
    var manifest = {
      name: CONFIG.APP_NAME,
      short_name: CONFIG.APP_NAME,
      start_url: '.',
      display: 'standalone',
      background_color: '#ffffff',
      theme_color: '#0e7c5f',
      lang: 'bn',
      orientation: 'portrait',
      description: CONFIG.TAGLINE,
      // Browsers only offer "install" when 192px + 512px PNG icons exist. These are plain placeholder icons — swap in your logo any time.
      icons: [
        { src: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAIAAADdvvtQAAAreUlEQVR42u2deXyU1bnHz/Iu886aTFaykIU1CwQCiARBEUUQEVyo4rVqtYh163Lv1X7Ebre1VXtbb6uoSF2Kti5UBVFRLCK77AQIOyQEErJvs77LOef+cZIQYSYLgjNJ3p/+wYcJmfc97/d9zrOc8xzofPJuYMrUhQqZQ2DKBMiUCZApEyBTJkCmTJkAmTIBMmUCZMoEyJQpEyBTJkCmTIBMmQCZMmUCZMoEyJQJkCkTIFOmTIBMmQCZMgEyZQJkygTIlCkTIFMmQKZMgEyZAJkyZQJkygTIlAmQKRMgU6ZMgEyZAJkyATJlAmTKlAmQKRMgUyZApnq7BHMIIAAQQgghAAACCABgjLEwPwYAYIC1/kyoHzMB6h/QQIgghABQBgxKDMNQicEYBZQCACAWEITn/BPKGCMGAAAgBCGSsSBgLCCMIGD8036Jk9CfLA1ECEIACaOqoQd1DTCGMY5V7Ikx8QNj4rLciQNj4w1KCwZkuCxWBlirQQIMAtgc9BefOSkgVN5YV9pQU95UX+Ntbgx4CSEAQosoyYKIIWKAUcq4lTIB6iPCEEEIVMPwqyqj1CLJGbHxo1OyJmfn5CSmDopLirc5FVHq8vfMyh3T/ueArtX5Wo7XVx+sqVh/4uDuytKTjXVBTYUIWUVZFgTGAGG077+WfbhTPYQQQ2hQ6tNUQkmK0z0qNfPaISMnZQ3PSUq1ivK5MxRrtRzc8Jyv9k/5DNjxI7+uHqyu2FB66Iuje/dUlFW2NGCEbZIsIET69OzWNwGCEGKIgobmV4NOxTYmNevOMZOnDy1Icbnbf4Ywyli7Bx0WmnBigDHW6m5DCDA8G89WNjd8dqT4rZ3rd1aUtgR8VtliESTCaJ/EqK8BxG1DUNcCmprhTrwhp3DBhGtHJA9sNzOUMcRtSA+J6QZPjDKAOhinfVXli7d88fHBXScbahRJtohS3/O1+w5AEACMcEDXAro6KC75nnFX3T9+aqLdxZ8upQy1xeqXWoxjiloZrfE2v7J1zRvbvzpeX6WIsiJKhBJmAhRdbjJCBqWegC89NuGhouseLJrmkBUAAKH0fH/lOxO3NxghAIBHDby4efWizZ+faqx1KDYBIUKpCVDkxe1KU8DnkJWfTb7hwQnTEuxOAIBBKf6uTE6XBokwJiAEAKj1try4ZfWf13/sUQMxio3bqt796sqTR/XiJATCQUPzasHZuWPfvvMnt4683CbJ3OpcGD2s9b+2oKyDzmaTeug8cRPIAKCU2mXLVYNy5+SPq2iqLz5zEgIgC2KvZqgXWyAB4wafJzM24dkbvj935OV8wuqpo8MYo4AxxkIG551MTAwwCCECPf+6tklt2d6vH/v4zbLGWrfNYRBiAvSdTlsMgGafZ1b+ZUvmLkiyuyijAHTX12EAMEbPiZi4AroWNHS/ph6tq8IIctMAISCUDYlPtkqyRRDPSTl2iOxQN1GijAHAEETV3ub5yxav3L/NZXPA1r83Abr0/nLQ0A1Cfj1t7hNX38TdHe5h9Mir5WoIeA9Und5bVV5cWXaqqf5kY11z0E8oqfV5IISgtSIBGWMJNgdG2GWxZsTGp8fEFaRkjkwemJuc5lbsZ3NLPfHZ2y/7919++OvVywSMLYLY6zzrXgaQgHFzwJdkj1k67+Gpg/O7aXgYAJRRAFrTfYTS3ZWlm8oOrz6yt6TqVGVLo04MCJGIkYgEbt7CZQooYzo1dEIZoyIWUpyxecnp04aOnJg5bHRKFkeTVzBQNwxSuylac2z/XW+/UO1tcim23jWd9SaARCzU+1quyBz+93kPZbuTDEoEhLv8V4TSdpNzpLbyveIt7+/beri2MqBrIhYsgggh1AnRiEEIgQghCCyCFGezAwZa3WUGAAT1Pm/Q0CgDjFKMsYQFEWPGWNDQdWIoojQsIeWWEeO/VzBhaELK+V/dqSkiAsInGqrvfnvRxrJDcTanzsv+JkAX2WX2NE0alL/y3sddFmt36CGMcieXMrr2WMlLX3+x9tj+Br/XKskSFjWiB3QdAhBntafHxOUmpQ9NGJAdl5jqdDtkZVB8MmAMcNvGGIDweF2VRw1UtDScqK85UnvmQPWpU0319X4vA0ARRf4L/ZrqttqnDM7/0eXXThmchyDiTnrHQkcnDDUH/bNee2bD8f1uR0xvsUO9AyAB4QZv84Kiaf876y67ZOnyze4Y7Czduf6FjauKz5w0GHXKVoMSrxqwCFJuUuq49MEzho8anZKV6nJj1LPFmYTSiuaG3ZWlqw7t2X7q2IHqiqCh2WVFQLhF9QsQFQzIePiKGXeNmdzN8JDflFcL/tfKpYs3r3bbXQYlJkAXy/Y0Pzzp+ufn3Mv9BtSNJwEA+Op4yTNfrfjs4G6LJFtF2asFNWIMiU++dcTlN+aNHZs2qKPrzYudPMcTsrbKq6f8D7xY29Ed3nH6+EclO/617+ujdVUSFuySxa+rQU2dnjP68atmXzUorzszWvutPbL8tRc2fOp2uKLfDkU7QCIW6j2NC4qmv3zL/C5jHJ6eQRBVeZp+tXrZ33d8ZVAaa7U1+n0YoaKMIT8Yd/VN+Zc5ZEs7aqBtPWtPc46sbVUrDwz5X3rU4If7t72+/cvNJ4+Stq8WELp77FW/mTY32RFDGYWdpo7a48QH3l+yePNncY7YKPeHohogAeEGn2dSds7n8xfKgtB5wEUZRRABAP619+v//vjNsobqeEesTw2qRJ8+bNTPJt8wdXB+u8HoUdqm+4mldpO25tj+P6//+LPDe2Qs2mRLnacx0530xxu+f+vIyzteaiehmWoY1y15asOJg26bI5rnsugtZWCEW4K+osxhK+/7uUO2MAA6ocegBCPs04I/XvHG4x+/aTDmsFjrPU3Dk1Kfn3PfU9Nvz3YncseIr925uEUyeLZewShlEIDsuKT/GH1FblLavjMny+qq4hwujxr8x8711d6WKYNyZUE0KAnHEISQASBh4aYR4zeWHuI1/KhdBBKlACEINaLHWR2f3vdEssPVuffAQ5h9Z8pvWfqnFfu2JrrcPk0FADxxzc1L5j5QmJpFGaWAIYjQxV4GdB5JnE1IGAWA5Sen3zlmskWUNpQe0ogRZ3euO7rv38f2Xz5wyABnbOcMEUqtojR1yIh39mzyaUEBYWYC1JNHAVVdW/6Dx0alZHQesfNPl5dsv/2t547VVyc4YmqaG8amD37v+z+5Y/QVsiBy+L7jFR2tGFGqiNJVg/KmDR25u6L0SPXpRJf7eH3VB/u+Hhw/IDcprROGEIQGJW6rfUz6oL9v/0oUBNMC9cD1afK1/P76/7izcFJ36Pn7znXz3vo/CJEiyfW+lgeKrnvrjkcyYxMNSiCECKII2lEGGKE0zRV3++iJjUH/uuMlMYpNNYylO9dlxSUWpmZ1yhAyKMl2J0mC+EnJdpusRGGxLOoAEhBu8HtuzL/s+Zvupd2j5953X4yxOiijGjFevuX+X1xzi4QFwqiA8CWdsLo9qSHCqEUQb8gpTI+JX3lgB4LIJivv7dmU6e6aIULJFdk5u8+c3FNZapMs0cZQdAGEIAwaWqrLvfIHj9skCYSPeL9Bj2IL6JpTVj774ROzcscQSiEAETQ8oU0RY5SxMWnZ1wwZ8cG+rV4t6JCVd/ds7pIhviF26uARy/ZuaQ76RBxdzlCUAYSQTw2+fvuDY9KyaXjH+Xx6XLKy6ocLx6YP4h9Fw0LE8yngbs3AmPipg0f8a+8Wn6Z2hyEIIaXUISuZ7sR/7tpokaSoisii6DXFCDUFfLPzx83JG0coxWEmL47IygM773l7UbvtWTV/4ejUzG6WVyM7QRuUjE7NXDV/oVNWAroWo9jueXvRygM7+UfhMhqE0jl542bnj2sK+HpadekXAEEIDEodkuWZmXcywGD4bKGA8IHq0/OXveywKDohLot11fyFo1N6AT3fYCglc9X8hS6LVSfEYVHmL3v5QPVpAWEaZjMrBIAB9szMOx2SxaA0eixstACEIfYEfP89ZfaQ+GRKKQr1kvHCgV9Tf/Dei/V+j4CxToyV9/68F9FzDkMr7/25TgwB43q/5wfvvejXVF4hCTm5U0qHxCf/95TZnoAPQ2wC9I1pPqBr6bHxDxZdxxgL505SxjBEj33yj21lR9w2R6PP89It949NyzZIb6LnLEOEjE3LfumW+xt9HrfNsa3syGOf/ANDFC7O4otDHiy6Lj02PqBrUeLnoegwPyioqz+eNNOt2CijIYeG5wOXl2xftPHTRGdsTXPjQxOn3zP2SoMSAfcyeloZwtig5J6xVz40cXpNc2OiM3bRxk+Xl2zHYbaM8YVNbsX240kzg7qKoyPMRNFhftTsuOQfTZgWzvxQxiCE1d7mn654w6HYmoO+yzKHPTvzTkIphr24yRqGiFD67Mw7L8sc1hz0ORTbT1e8Ue1thhCGtEPcCP1owrTsuOSArkaDEULRMIgBNXjf+KutohTO/DBGEYS/+WJZWUO1hAURCX+bu8AqyaCta1gvFb94qyT/be4CEQkSFsoaqn/zxTIEIWNhjZBVlO4bf3VADUbDy4MiPoJBQxsYl7Rg/DV8KU+YyQtvKjv86tYv4+0x9d6mx6+eMyJ5oEFJVAW0F5y8MCgZkTzw8avn1Hub4u0xr279clPZYR66hzZCgC0Yf83AuKSgEXlPCEXc/PjVwOy8sW6rndLQ5gdCQBh7as0HlDG/pualZD56xQzCQk9eUd77IuTlYYgIo49eMSMvJdOvqZSxp9Z8QBgLyQbPK7qt9tl5Y/1qIOJGKMJfb1DitNgfLLqOhWnrRChBEL1XvHnVwV0xik019Kemz3PKCmAgDG2QUBqFELG2XWOhJzIGnLLy1PR5qqHHKLZVB3e9V7yZF8JC5YQgA+DBouucFnvE15pFEiCMkE8Ljh2YPSwhhbHQuR8EkUHpc+s/USS5KeCdkTN6dt7YcMuDgoZW7/NghCCIrvZyhFEIAEao3ucJGlrIoSCUzs4bOyNndFPAq0jyc+s/MWjohYsIIcbosISUsQOzfVowsvN4ZC0QJITcVXhluF29/JXdVHaouLJMEWUM8WNXzQ5nXXhny/nvv/LcupUGJTyhEvHaNb8GDJFByXPrVs5//xXAwm5hZgA8dtVsDLEiysWVZZvKDnGDGjosBeCuwisJISCiKw4iBhCEUDP0FFfcjOGjAQCh53IIAACLNn9OGPVqgaKsoZOyhjMW2vxQRi2iVJiS+bP3Xpq46JefHynmW98JjUxvOcYY382DIPz8SPHERb/82XsvFaZkWkQpZL0CI8QYnZQ1vChrqFcLEEYXbf68fRDOd5sAADOGj05xxWmGHkFXOpKLrfy6WpiWlWh3hoze+Ytb2lCz5ug+h2zVCbnvsqmduMnchbpu2ChrTHxxZdnMV5++6Y0/Hqg+jRH6jh2jdncHI3Sw5vRNb/xx5qtPF1eWWWPirxs2CnTSxJMxAMB9l03VCXHI1jVH95U21ITMTfN4PtHuLEzL8usq6ocAQQAZpdcMGQHCzF/8NX1nz+YGv8egZHB88k35l4UL9VvfYMBGpWbmJKZACFyKdcWBHUUvPPnA+0vOeBpbHaNL37qg3d2p9bX858dLx/914UcHdroUK4QgJzFlVGomAyyc18JD9JvyLxscn2xQ0uD3vLNnc/tQhJiyAbhmyAhGaQTXzUUMIEKpRZKvzM4L90ZihFRiLNu7xSpZvGrgtoIiqyiFC2Taf6eI8MycwqCmAQZiFBsDYPGW1Zf99Yln1i7XCcEIUcYukX/d7u7ohLy0ZXXhc4//ed3HAEKXYgUMBDVtZk6hGCa70zGEtIrSbQVFXjVglSzL9m5RiRESOD5oV2bnWSQ5gj09IgMQhFAlWmZswpCEZBBqvw6hFAJ4sPr0wZoKGYuyIN6YO7YT499xTK8ZMhJjgTLGh9Vtczb4vT//5B/jn39i2d6vEYS8gHAR/etz3J3LX1j44Ad/awh43VYHAoB/F8bCNUNGdvMWbswdKwuijMWDNRUHq09DEMKV5oM2JCE5MzZBJRHLKEYGIARhUNcL07JsokxCOUC8pff6EweCuhY09Lzk9IKUzox/xzEdmZKR5U5oz9IalIhYcNuc+6tOzfvHX2a++vRXx0v4Pg2Dkm/pX4d0d/adKY+12kUsGJSwtmx7ljthZEoG6HR3W/tEXJCSmZecHjT0oK6tP3GgfUDONVeM2kS5MC0rqOuoXwEEAISMXZmVG84p5sOx+sheEQuqoU3IGCJhTLsy1BBCQolLVqYNLQhqZ+vVjDGDEptkcVqUVYd3z/jb7xf865Vj9VV88esF+9ch3R2HrNgkS8fQD0MU1NRpQwtcskIo6dJUUEoljCdkDFENTcTC6iN7w2HHv+LKrFzIWKSC+cgAxBiDWBiemBrSpPOafEPAu7/qlEUQAYQzho0G4SLaUKH/9cNHQ4jOIZMySiiNUWwWUXply+orFv3yd2s+qPW1XEDisRN3hzJ6js/LGIAQXT+8Z7cwY9hoAKFFEPdXnWoIeHkdPuR8NzwxFWIhUjUcFAnjAw1K4hRbVlwiCFVO597JoerKSk8jhDDOah+VmtWl8e9ougrTspMcMRoNkSDhHonb7vJp6i8+/eeE5xcu3bnOoBRDRFnXjlGX7k6IdBfVkxwxhWnZPbqFUalZcVY7hLDS03ioujJkrMrvLisuMU6xGd2wbX0FIAB0aiQ5YuKtjpDLn/l8X1JdrhuGTsjAmPgEm4M3VekOnZTRAY6YydnD/WoQhd8VhCFy211nPE13//P5qxf/z5pj+/ne53CJx+64O6HTXWpwcvbwAbw1R/dugQGWYHMMjInXCdENo6S6PLQbBAADLN7qSHLE6NSA/ccCaYaRHhuniBJjIbDgf7Hj9AkEkUb0/OSBEha6HzTxn5ydN67zKYMB1upf211bTh6Z9srv7n5n0cGa0InHbro74eYjfjE9ugUJC/nJAzWiI4h2nD7RPiznosaYIkrpsXGaYUTEAkVoxzVjmbEJAIQ+lo1P7aebGzBCOjGGJiS3OozdGx/uO08ZnB9vcwYMHSPUyQNmjBmMOCQLA+DNnes/3L9t/uVTfz5lToLN2ZbBg/x36oT8bdua36/58HRzvcNidSlW0g2nXidGvM05ZXA+CFeuCZeShmBoQjKhVMTC6eaGcPE/v7HM2ATQj3wgABmlg+KSQoZg3CZ5tWBZY42EBQRRRmxil+mT82exRLtzZEpGoHtpfsIoZTTGagMQ/nndx4XPPf7SltU6JXxS66a7E3L+CujqyJSMcOWazrNBGbGJCCIJC2WNNV4tyO1NyEBsUFxSpPLREev5END1ToaPMuYJBnjnsIyY+AtICgsI35g7ds3h4u4PK6EUAeC2OhoDvkeWv7Zk65o/zbor1eV+7OM3Pz20ByEUa7VTxrq/BAcCSAzjxtyxvBrf04ZWGTHxEAIIoScYoIxBAMOdpNnJYPZBgBhjCAsFAzJCx/AAQABaggGdEgCARRS7cxjleXYVAgBmDB/9C2sPl1y1ncuMINpXVX7Da8/IgtAc8POOvj29DIMSp9XOlxugnpsHRZQsoggA0ClpCQacsnJ+tocPYMGADBShSD4CUxhPzrqt9rDTPwDH6qpqvS0AgHibc0jCgG4GwGfvCiEGWKY7YWj8gIChIdSt2EdAWCdGg6cpPSb+toIiRZRFjCmlFkG4ZsiIooyhjd4WnRjd3HuPEAwY2tD4AZnuBAYY6smyr7YyxYB4mxMAUOttOVZXBcKvRHBb7TB8f/Q+mYkGRqc+RHtT3As+EIkXVqcPH6VrGur0NiFoQ8fXEm9z/ub6eVse/t1/XnmDTw1CAAUk+IOBa4eOXPvAr56/+Yduxd7g6xZGCCBd06YPH9V5AbXziZgT0+XxCUZ/K6aCS594h63x81iLZOnk+QkIE0Y4Or+dMW/7o3/45TW3xiq2Rr8Ptk1nAEKvFgQAPDxx+q6fPPPbGfPibc4uMSKUWiTL7Lyua8DRP5jR6ERf8jcDQgBAblJ6Rmz8yaY6WRA72n9+PqZBSYO3OcnlfnzKnPbzMVXDkDA+p2rLI3DV0BPszien3nz/+Gte2frvJVvXlDfUhDxTF0KoGnpGbHxuUnpP599eNs6R+uJLPWHzwqpVlKYMzu9YWIUACAhTABp8LQiA+ydM2/jg/zw59eZEu8uglDEm8FacITNMCDHGDEoT7c4np968/dE/fNManXW1eAF1yuB8qyiRS19kYP0QIKGrnu3dnP67NO1z8sahtlxiOzoYgAUTpm16+HeLb71/cHxyl+h809cOg5HfSwHgbR4YYwihOV1lw7s0ot10BIXIbcyITC2MMdbg94Z7QgCAwfHJ/OjTOl/L0doz4IIOY+PkFWUOGxw/QKMEQtgRnZdvmZ+blMZrq91Bp3OMdjz6h59deQNgrMHvgRBqlAyOH1CUOezC5i9+s0drz9T5WgAACXbn4PhkEH4fd4PfyxjrR7UwSoziMydBmAIhAMBpUUSEAQBBXQ/o2oXPYow6ZEthWpavqQ5DdD4636YDcEeMEuzOP91w19ePPrXg8msxRL6musK0LIdsIT1JQJ+XHtSCug4AEBF2WpSQpowPYPGZk5T0q1oYAIoohp/RGYLQYVEa/D7GwMmmuiu+VdIJzMkbJwKw8Nq5wxJSQIei+sV6H4S2Hpq5iWkv3zL/p5NnPvXFspl8/voWK71ONtUxBhhjDovCOwZfwGD2QYAYYBCh4/XVIW0yr2TZJUtmbOLR2irK6MnGmpC2qjvilNxWUHRbQdFFR+ecy8YQctdtWELK0jt+3PECLmCIAAAnG2t47+LM2ES7ZAl5wgYfwOP11RAhFglnOkIWCMKyxtpw7iUfiDSXm29hPlJbBb51G5dLh865XlcbRt/mu/jNHqmt4lue01zucK8QH5SyxlrQf9ZEM8YkQTjVWM/7tIWqMAMAwNi0bMqohMX9VeUaMb5lKuW7PO0AfWtSEYQaMfZXlUtYpIyOTctuH5ZzRpJ3BzzVWC8J/akWJiKh2tNU5/fwRhPnvVUQAJCXNFAUBBHj8qa6Wp8HAsh64anYF/aCQQBrfZ7ypjoRY1EQ8pIGgrCFZ1jn91R7mkQksP5jgQSE6wO+0voaEKpAyE3F8KSUFEcsY6ze791TUQp657HqFyB+m3sqSuv9XsZYiiN2eFJKyHQAH7rS+pr6gE9AuL9YID7HM2IcqqkAYXY8UUbdij0/OT1o6ICxVYd3t71y/cIGAQBWHd4NGAsaen5yulux0/C75w7VVLAIxfAgcploxiBcV3ognHfM38JpQ0fqxJAFacvJoxohqPc3tOvWI0FII2TLyaOyIOnEmDZ0ZDjry4duXekBBmGk3q7IPBLKmEUUd50u9ekqDr/jaXJ2rkWULIJYUnWquLIs5A7fPia+p7u4sqyk6pRFEC2iNDk7F4TZPYch8unqrtOlFlGkrD8BxBiTsVTWWHu0tirk68V3+OYkpeUkpqpEVw39owM7Ljgb1KtmLwYA+OjADtXQVaLnJKbmJKWF3NPdVu6oKmuslbHE+hVAHJGgpq47URIOC0KpjIW5Iyf4taBdVt4t3uzXtc63WPSB+Asj5Ne1d4s322XFrwXnjpwgYyGk3eWDtu5ESVBTcb8qprbfP0To30f3gTDlRp51vX1UkdvqEBA+Vlf14f5tEEDK+uwsxg8F/3D/tmN1VQLCbqvj9lFFIMzZZ3zQ/n10X6Ry0BEGiDJmFeVdp0trvC0hN34jCAmjWe7EqUNGeFS/iPGr29aAXt5ZvMvgFADw6rY1IsYe1T91yIgsdyJhNGQAjyCq8bbsOl1qFeUIJjgiZ4EYkwSxsrl+1aHdIFxvAwYAAA8VXYchskvK5tIjG0oPQYj6pCtNKIUQbSg9tLn0iF1SMEQPFV0XLnfBh2vVod2VzfXSNxdb9heAOCAY46W71oU7E557PBMzhxekZAZ0lTDy7Fcr+qz9AQAC8OxXKwgjAV0tSMmcmDk8XE0NQcgAWLprHcY4sukxFNl3ziZZdpSfOFxbCSGiofvZUgGhn06eGdDUGMW+6uDuFSU7wp1n06vND0ZoRcmOVQd3xyj2gKb+dPJMAaHQ3REphRAdrq3cUX7C1umWgT5vgYCAcEvQ++Lmz2GYWAwjTBn9XkHRjJzCpoBPFsSFn73dogYABH0mHOM74VvUwMLP3pYFsSngm5FT+L2CIspCn/vJW5q8uPnzlqA34gelRRggwqhVVlaU7Gjwe1GYEJ0xgCFcOPVmBKFVkksqy/66cRU/X6KPmB9GMUR/3biqpLLMKskIwoVTb8YQhnxB+GrrBr93RckOq6xEfBBQxF8+iyCV11cv3vrvcCE6RohQMjFz2H3jr67zNsXZY575cvm+qnLhQjfsRdvkJSC8r6r8mS+Xx9lj6rxN942/emLmMBLmLCIe6i/e+u/y+mqLEPkTnFE0vH+KbHl165d+XQsZzwMAIESUsV9dOzfTnaQRQ6fGD5ct9msquJTH88COunSTFwB+Tf3hssU6NTRiZLqTfnXtXMoYDHMWEYLIr2uvbv1SkS3RYIMjDxBjTBHlE/VVL21ZzevwoYMOxpLsrudm3+MJ+FwW27ayw4998hZGl2oiY4wZxNCJoRODEYNcGkwJoxihxz55a1vZYZfF5gn4npt9T5LdxRhDoWvMFEL40pbVJ+qrFFGOBi8wKurbhFGLKP9lwycNAV84I8Qjrzl54x664vqalsZEV+yiTZ+9sWMdP732ol+SiIU4mzPO6oizOmJtTmvPO4R0KX5W8Bs71i3a9FmiK7ampfGhK66fkzcu3FlEbb1HfX/Z8IlFlKPEBYTOJ++OhusQEG7wtfx2xrwnp95MKAkdfTBGAVN1fcri3+w6fcJhsQY0dcNDvx2bln3Rj/02KPGqQT53UcYUUbII4sX9/QLCO06fmLToF4oke4L+wrTstQt+JYsiAjDMscMEI/y7NR/8YtXbbpsz4ieFRZEFAgAQRhyK7Y9rVxytq+JnpId2SgCwSvLr33swzuowCBGxMOu1p3dXlvGT2C8u0DGKzWWxuizWWMV2KejZXVk267WnRSwYhMRZHa9/70GrJMNwC6QoRQgdrav649oVDsVGGImSBxctADEGBIQ8WvDxT94KuVC6zRlCBiW5SWlL5j7gCQZEjJuD/hlLnroUDLGOugT0zFjyVHPQL2LsCQaWzH0gNynNoCTcUTJ8+fPjn7zl0YICQtGTAouiNX68C/iK/dvbzk4n4WyDQcms3DFvzHuoKeBTRKlFDcxY8tTuiovM0KWIwlrpqSibseSpFjWgiFJTwPfGvIdm5Y7pZBbmIf3yku0r9m+PUWxRlbzA8uRR0XM1EAAAwYbSQ3eMnmSXLSzMwajcDhWmZmW6E9/ds9khK15NfX/f15Oyhg+MiSeUwugr2vOtqwLCW8uPznr9mWY1YBWlpoDvtdsevHvMlZ3QQxlDCNZ6Pbcs/ZNKdIxQVCXgowsgBoAsiFWexiN1Z24fNZExGs6kn8OQXbaqhv769rXJjtgxadl8V3z0dOUhjPKGr69uW3vbW88RSmVBau4GPW2hO/qPf/51W/lRp8Uabfn36AKIv3A2ybLn9HFFkidl53TiFnRk6J3dG2VBlATxveLN1d7mqwblWgSRd/+HET1SlAHGc81eLfjjFW/88vN3HRaFMtYc9L1++0Nd0sM/fXbtikUbP42eyCuqAeIMWSR59eE9kwblZruTusPQqNTM1Uf2NAZ8CXbXuqP7vjxeMio1M80Vx9fhR8oUEcoND9px+vjtb/1lxb6tic7YpoA3RrG+ecejtxcUdYeer04cuPfdFx2KLTqXYkYjQKB1kzn45OCuW0dOcFvtnUDQHpddN3TUjlPHj1SfTnS5yxpr39q1QSdGYVq2IkqUUQrYd4kRYRQAhhFqUQNPr12+4P0lFS0NcXZXTXPDuPTBy77/n1dm53ZOD7dbJxvrrn/19zolQpS5PtEOEANAxGKD37Ot/NjNI8dbRYmysIetcIYGOGPvGD2xIehfd2y/IsmyIKw6sPPjg7sS7K785HTU1oEFwkvY8pIBRimDACCIIITL9n599zsvvLd7k0OxAgAafZ4HJk7/xx2PpMXEdeX3MIxQU9B/69I/Ha6ttElK1K4Ej1KAeNhiFeUjNZWbyw7fPmoifwU7YYgyKgviDTmF+ckDN5UeOtNcH++MrfY0v1u8edupY8mOmOy4JAQhBNCgFAB2EeM0BgBjlDCGIeJ96dYc2//I8teeXru8JRiMsTnqvU0pTveSuQ88dtWNEhbCLfRppwcAFjT0ma/+YWPpoVirnUSf69MLAOJDabcoh6rK6/y+WbljaVvXxHBpG8YYAywvOf32URM9mrqt/KhOidtq31916u09m748tg9BlB2XpIgiT+2cPWin5zCxtsicFz55L0ePGny3ePNPPnr96bUrjtZVua12n6YaxLhv/DVv3fHIZQMHc0OCwp+60t4a5pHlr32wd3OcI8aIYnpA9NTCOpGAcYOn+eFJ1z8/597WvEinj7u9GPnV8ZJnvlrx2cHdFkm2irJXC2rEGBKffOuIy2/MGzs2bVDH3pS8Ty+f3UJOc6xt5Qg/uazj0TsGpTtOH/+oZMe/9n19tK5KwoJdsvh1Naip03NGP37V7KsG5XW8sE7o4bf2yPLXXtjwqdvhuhR14n4HEOClVm/zgqJp/zvrLrtk6fJJcNvAf2bpzvUvbFxVfOakwahTthqUeNWARZByk1LHpQ+eMXzU6JSsVJe7p3vzCKUVzQ27K0tXHdqz/dSxA9UVQUOzy4qAcIvqFyAqGJDx8BUz7hozuS0c6yKhzW/KqwX/a+XSxZtXu+2uKLc9vQmgNjvUNGlQ/sp7H3dZrN0pvxNGeWWbMrr2WMlLX3+x9tj+Br/XKskSFjWiB3QdAhBntafHxOUmpQ9NGJAdl5jqdDtkZVB8Mj/slPMIIDxeV+VRAxUtDSfqa47UnjlQfepUU32938sAUESR/0K/prqt9imD8390+bVTBufxpSkUsC5PCuO30xz0z3rtmQ3H97sdMdFve3oZQAAAEQv1vpYrMof/fd5DPD/UnSUcHc3VkdrK94q3vL9v6+HayoCuiViwCCKEUCdEIwYhBCKEILAIUpzNfrY/JgMAgnqfN2holAFGKcZYwgI/wido6DoxFFEalpByy4jx3yuYMDQh5fyv7pKeEw3Vd7+9aGPZoTibUydGb3kovQkgboeaA74ke8zSeQ9PHZzPTxTsMsHDWs8ebD2xgFC6u7J0U9nh1Uf2llSdqmxp1IkBIRIxEpGAwh97AwGgjOnU0AlljIpYSHHG5iWnTxs6cmLmsNEpWRwX0uYpd+mY84ALQbTm2P673n6h2tvkUmy9xfb0SoAA78pg6AYhv54294mrb+I+bDdbtZ/f/rIh4D1QdXpvVXlxZdmppvqTjXXNQT+hpNbngWeb7kDGWILNgRF2WawZsfHpMXEFKZkjkwfmJqe5FXtHa9f91vrtl/37Lz/89eplAsYWQex12wR6H0CgbV9ms88zK/+yJXMXJNld3TRFHdM2lAF03sMO6FrQ0P2aerSuCiPYFuMDQtmQ+GSrJFuEcw/A42fIIwgg7O6RhO2Gp9rbPH/Z4pX7t7lsDtg7e/j1SoDOutU+T2ZswrM3fH/uyMu7GeyEiNcA4wF8N40HbV1ixiCE4Zafdic8XLb368c+frOssdZtc/SuaavXJBK7fJA2ydIU9L2zZ9OeirKClMxEu4uf2N39p8qhQW0ZZAb4f22UnL8mEbbarfZ/0v3EI1+WiiA8WFNx/7LFv1vzgWroTou1V4TrfRAgzpCIsSJKxWdOvrlzvUaMvKQ0u2yBABgXtKwMtq1DROf937Y0scf1D8YYYQxDiCCs9bb877qV9y17eW9VeYxiu3TbkkyAQPffbMaYVZIpY6sP7X6neItGjIKUDEWUuDUCkVud2OoeIYQg9KiB/9vw6Q//tfij/dskUbJKMqG0D2zu78U+0PkxNkY4oGsBXR0Ul3zPuKvaDyHkRXJ0CbeYhnB0EGo1VzXe5le2rnlj+1fH66sUUVZEiVDSZ9r09R2AOvo0QV0LaGqGO/GGnMIFE64dkTzwvIjpIq9UZIAxxs6J7PZVlS/e8sXHB3edbKhRJNkiSvQib/EwAbpkGGGIgobmV4NOxTYmNevOMZOnDy1IcbnP5mwYZQzA1t0XPV4kxGurHAcIQcdiRWVzw2dHit/auX5nRWlLwBfyUFUToN6CETQo9WkqoSTF6R6VmnntkJGTsobnJKVaRTlkcA7CH7Lc/un5Ab9fVw9WV2woPfTF0b17KsoqWxowwjZJFhAifc7q9BeAzkYKEEEIVMPw6yqj1CLJGbHxo1OyJmfn5CSmDopLirc5lR7ufg/oWp2v5Xh99cGaivUnDu6uLD3ZWBfUVIiQVZRlQWAMEEb7/Nj2C4DaQ3Tu2BJGVUMP6hpgDGMcq9gT7a6BMXFZ7sSBsfEGpQUDMlwWKwOty4P4H5qD/uIzJwWEyhvrShtqypvqa7zNjQEvIQRAaBElWRAxRNxhZ/3lWI++e258yAmItAXOsiAqogQBoAwEDf1EffXBmgrGKOBhPxbOT0lTxhgvkiMEIZKxIGDskK0Ink08GoyAfiYB9Evx5F7bBAcFUVQkqd37CemztKcluXXhLhNlfSKZYwL07SxTa0DVrR819U0hcwhMmQCZMgEyZQJkygTIlCkTIFMmQKZMgEyZAJkyZQJkygTIlAmQKRMgU6ZMgEyZAJkyATJlAmTKlAmQKRMgUyZApkyATJkAmTJlAmTKBMiUCZApEyBTpkyATJkAmTIBMmUCZMqUCZApEyBTJkCmTIBMmTIBMmUCZMoEyFRv1/8DMse73Mm4MNkAAAAASUVORK5CYII=', sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
        { src: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAB5kklEQVR42u2dd3wVx7n355nZ3dOPehcgCUQRXTQbg7HBxgU3EvcSlxTfJI6d8ube3PTk5qbnpjjNSdx77MTdsbFNjMEYjOm9iqbedfrZnZn3j5GE0JEEhj3SETxf88nHAXwk7c48v6fNM+D/9u0EQRAEOfug+AgQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAESTk0fATImQcQQgCIJAAEAHr8Ppzwv5VEHvt3KaUkBAiRUuJjRVAAECSVDD10m3hl3IWUQIglOBccCMS5ZQl+zKBzfuLPZOzY9qDMYJokkgHVKJOEUIBukVDy0FMwEAQFAEGS5deDgoAkUkppcs6FiHFLSkkEJ4QwTZdS+J2eDKfX4rwoLTPPlyYlIUTqjM0oHq1RKiWBhEhA/aYlxPqj+03OCQEAUh9or25v0RjriEbaoyEAyi2TEEIoAwAH0xilOmM9vyWJsQKCAoAgtkC7Lb6UpuBxM24KLjknlBpMy/L4MlzeURnZmW7vxLxijbKZI0YDIQX+jHxfOhci3eWmcOqFLiFFWyTMKK0LtNV2tEpCPjqy3xJ8e/3RlnDwUGtTayTYHArEuUWEAMZ0ygxN1ykD6NQDgXKApLJT5f/27fgUkBRz8ykFIgnhQkQtM26ZRErKWKbLW5KZU5yWNbVg5JjsgtLM3LE5BV7D6dKNgY046Uz9n5Q5pgDdf39g8YiY8WA8uqextqqlYV9T7ebaw0fbmw+2NLZEgoJzAmBoulPTGaVAiJBESoFqgKAAIEgfZpcClUSanEfNuMUtAOp3ukZn54/LKZxeWDK9qHRcTkGhP5NRmmDipXK3SVclALorvwBwGt+VyvSrf5Gd/yK7Ph9owmdzIWo6WnY31m6srtpYc3B3Y83+prqOaERKoTHNqRs6Y0BASIGRAYICgJzlzj5QCkDAEjxqmXEzDpRme/wTcovmjCyfO2rsuNzCsdkFvSy+kFI59QCEEuj8ZyhQBWDRJQ1U/TTH68GeptrdDTWrD+1Ze3jvzobqplCHFMLQDaema5RJoqQAxQBBAUDOkjUHnb5znFuheIwI4Xd5yrPzF46ZNLdk3IyishHpWceZUSmklNBVAIYU/tEk6SoEEwkA7PgM0pG25vXVB1Yf3L1837a9TXUdkRCh1GM4DKZ1xjEYFiAoAMiZavcZgJQkYsWjZpwA5HvT5pdNOL90wqLySWOzC3t6+pYQPXp+his99IBoPX46LsSeppp39m57r2rnygM764LtREqnbrg0A4BwVAIEBQA5Q1YYIZRSIBC14uF4jAIdnZW3cMykS8dPm1U8uigtM9Ho02Fs8wdC9CUG1e0t647uf2PXpuX7tu1vrhdSuA2HUzMkkUJg0RhBAUCGJ6qua3IrGI9KIUoy8xaPm3JlxYwFZRU+h6vLJgohJQU6rD39U4sMhBTqEanfDMQiKw7seGXH+mW7txxsqQdKvYZTZxpWjBEUAGSYufxSyrAZj5vxDI/vojGTl1RUXjZuWq43rTsHQrp6/M/yx9V9VqA7A9YQbP/X7k2v7djw9r6traGAoRtu3QAADAgQFAAkhRcTAANqCisQjTg0fUJe8Scnzb5+6rljcwqPs/sUhqpvJ7XDAqksfLcS7Gms+fvmD/6x7cOd9UdjlulzunSqqZI4Pi4EBQBJFZQvHzHj0Xgsw+NbOGbS58+5+ILRE5UtE1JIif7+x4sJAIjKDnEh3t2//U9r3lq+b1trKOA0HC7dwDPGCAoAMvQwoARIMBY1BR+dlXfHjAXXT507Nqeg2+U/g4u6yUYVjXsEBLV/37z6kfUr9jfX65R5HU4iCZcCHxSCAoAMuumnVErZEYtIISuLS++bd/k1k2ap6q6yShQoGn4bAoLOaRZEnSoIxCIvblv321WvbzhaBRT8DhcAqNwagqAAIINk+tujEQZw6fhpd8+5aPG4qeo0E7r8gxMQxLm1bPfmB9a+/cauTVzKNCfKAIICgAya6aeweOzUr56/ZNGYyeqPuBBY3R2UgEAKcSwv9M6+rf/33mvL9mzmAmUAQQFAkoPK57RFw71Mv3JLKcVszyDLABE9gq2eMpDudHdnjRAEBQA5vSUCwAACsSiX4tJx044z/UQywGulhxIuRfdcUiUDb+zexID6HE4cKYGgACCnsTgIYZSpEQ7Ti0r/e+HS66acg6Y/xWXguS1rfrL8hY3VVWqkBBccRQBBAUA+HoxSS4hANFyclvXNRUs/M3uRzhia/mEhAybnf/vwnR+/88LR9maf061RioUBpO9t7jh/Gj4FpCcUgFLaHgkbjN0z79LHb/rSgrIKRikXglGKHT6p/OJUEVhjbNaI0bfNOJ9LseHogUAs6jIMIHjtAIICgAyIRlnEiofisasrZjxz6323TJ/vMRzY3Dm8ZECViL0O5yVjp14zadbRtubNtYcJIQ5Nx/PDCAoA0qfhoARIWzgwIj37gWs/98NLbsjx+LkQXfOckWEDKBmQUkiZ6027cdp5FXnFaw7tqW1vcRoOdfUmPiUEBQDpcvwZC8VjFrfum7/ksRvvmTVitBo5xijFAT7DVQYAKIB6j5PyR9xSOZ9LsfrgblNwp25gKICgACCEAgUgraGOCXkjHr/pnv84d7HbcKh0P5r+M0MGVGHA63BeMm7q3FFj1x3Zf6il3mU4AEMBFAAUgLPa8acsZMZMbt03f8njN90zPrfI6sr54MM5s2QepJRcyjHZ+bfNmB/j/H0VCmgYCqAAIGelRaCUtoaCE/KKlePv0HQuhHYGOf7qGJTsvotRSnUPl5Cyv19Sku6/2dOJPjNCAQrAhXDqRo9QoNHtcGCDEAoAcja9dUpNzjsioc/PveSZW+8b7o6/JFLKTisvuufkwzHocb/ogL+O/c1uum5w7PzwTm0AMhwHH/UKBdqi4ZUHdjDKdMbw2PBZCB4EO+vQGGsLB/N96b+9+s5rp5xDCFEZ/+Hl2ksi1QWJtP/+1JZwkFFaF2ir7WhVl6scaW+qam7QmNaXywsWt0qzckekZRNChBQF/ox8XzoXItPt7fPzRdetLBQIkGF23U33S39+y5r7Xnq4LtCW7vZanOMGQQFAzkwoACHQFupYOHbKX6+7uywzj0tBh4nlEl15mUSLHzHjjaGOA80NR9ubD7Y01AbaDjTXx7i1p7GWUdoRjXREQ9B5uxYnA5+JpZRRRgiRUvidHr/TxYUYm1PgYFpZVl6BL70kM7c4LassKzfH43fpRqIeQFeyZVjoqCCSAT3QUv/Z5x5YvmdLusdPCN41hgKAnHmOP6VRy4yZ5tcuuPLHl93EgFqCa5SluoWSUhKiHR+gtEfD+5rqdtQf3VJ7aEd99cHWxoZge2skyIUkghNKASgFcGg6IZIB1SiTRKpk/sB5m64EjwQCluBcCkIgZplCSikFEYJQxihkuLy53rSSjJyKvKIpBaMq8orHZOenOd09P6ozq5byF2GqZcCl+Oa/nv7Vu684dN2p6RaOjkABQM4YdMbaIqFcb9ofln566aTZysylrJeqXOlenv6RtuYN1VXvH9y9ufbQ3sbaukBbxIwRKYEyB9M0xjTKlH1XrY1Sks4ex1PNbQMhBIAQld5RvwPq0VmCW5zHuCUFJwAu3ZHvSy/PKZhaMOq8knGVRaUj0rMG/nFS7YGrR/fCtg+/+MKDDcH2dJfHxHQQCgAy7F8wIRrTmgNt80dXPHLjF8sy8yzBGWWpZookISqj3vPUcXV7y7oj+1cf2rP28N6dDdWNoQ4iBKXMoekG09T9M8fadgb3qXYWiAmoG1ri3IpZphCcUJrj8U/ILZozsnzuqLGzRowuSsvs/hmFEAAEUu+yTEkIF1yj7EBL/R3P/GHl/h1ZvnSLW5gMQgFAhiudSf9A293zLvvllbd5DWcKpn2Ug9wzybOrofqN3Zve2rt1U/XBmo5WIoXGNKdu6IwBAZW5TrWWFQBQ1RRJpMl51Ixb3CJAC/0Z04pKLi6ffOm4aeNzi3omiFIwJlDLIxiP/r9XHn9g1b/SfelYEkABQIYljNKYZcW5+YPF139z4VJCiJCCpswkZ+U4d6fIhRQfHt7/8o6PVlXt2lJ3uD0UBMbcumFoGhAiJJGdXT/DI+oCoBSIJCRuWWEzLjlP83in5I+cVzr+qoqZs0eOVi9CFTlS6irN7kXy4+UvfG/Z3w2mOzQNp0mjACDDCY2ysBlza8Zvr7nz1sr5XIjUqUb2cvl3NlS/uXvT05tWb645GDPjGtNchkOnTCnE6cwqgK5e/Z4/+AmLwMf+vesg2Wl+D8q+m4JH4jGLWw7dmFpYctO0uZeMmzahKyZIqYBAyRKj9IkNK+978eGwFXfrDktgSQAFABkW1p+x9kgo1+N/9dP/XVlUanKus6FP+6gMeLcOBWKRV3asf2rjqhUHdgajYV3T3YaDAVX9Nh/X4qo6rUrKK40BQuLCkpIIKWKWqf5WZyfPAFAKQNUpAYemq0FJBtVkZz6NdJUcPrYqdIUFwKUIx2OmZXqd7gVlE26ePu/Kihk+h6tHQJASFQK1bDZUV13x4E8aQh1pLg+eEkABQFIdg2lNoY55JeMfvemesszcVEj6K9PffdZsa93hpzesen7b2r2NdRTA63BqlKkJDR9j4Xbl3FWS2uQ8zi1LCCk4kZJpupQyx+vXKPM7XaOz8ggh6kjXpPwRUpJEV1v95ra6I+r4GCFkf3N9RzRiCd4Y7AAAbpkEACjTKDWYpjOmSiynUJNQB5ItwYOxqJCyPCf/2klzbqqcNzl/pPoLXIhUkAGrsyzccPvTv191cFe2xx/nFm4xFAAkRdEZa+5omzdm4qt3fSPN6R7yI77dyQRCSJxby3ZvfmDt2//evyMUDbsMh1M3lLH7GEYfAAgRUsa5FTVNITghxNCMLI+3OC0r2+ObnD8y2+ObUVxGgZZn57sNh1PTe53YOkkiZjxqmeF4bG9TnZBi/dEDTaHA1rrDTaHA0fbm5lAwbsUJIZQyp64bTOu8ieXjdCSpJxM145F4zON0Xzi64u45Fy0eN9VgWqcMDHXiTi2h9mj4iod+umrf9ix/OraHogAgKZn5oawlFLhlxvzfL/10+lBbfzVwRusy/c9uWv3bVa9vOFoFFLyGU508OhlD2Z1D51LELDNqxomUmqYV+bPG5xZOLhhZmpEztbBkbE5BltvbX4lbSKHa+uWJXPXuJBIhcoBPaw4H9zTWbq45WNXauLX28K6GmuqOZsuyCIBTNxyazoCefA0DANS5vGA8KoWsLC69b97lN0ybq2TAEoINqQyohdQWDd/zwoNPrl+Z6fFhPQAFAEkx689YS0fbPecvuf+auwgh6uTRkCd8GoLtf1n7znNbPthSc0hnmtfhJJJweWKXv3uaQtyywmZMCuE0HKMysqcXls4vHT+lYNTE/OIMlzfBNKueRQmdp7i6znGdUo+N7Kr/HisGE+izVNsaCW6vO7ql9tDKql0ba6oOtTZF4zGg1K07DE0jJx0WMKAESDAWNbk1pXDUdVPO/dycRbnetCFPCnUvpy+9+NDv33st05+O9QAUACTVrP8V919z59De39sddjSGOh744K2/frj8cEuDoRsewyHliTvKAYABSEkiVjxqxgmBrj76KfNLx0/IK3Lrjj7MPQA9dlx3MBSOHMv795aEsBnbWV+9smrXW3u3dJ5jINKpGy7NACD8JJRApX1C8VjcjI/MzP3s7IV3n3txjsdPhnRsn9IwRumXXnz49++9ihqAAoCkkPX/0vlX/O6aO4cwa9w1FxNMzp/etOqHbz2/v7HW7XQ7Nf2EBd7uSdQRMx414xTo6Ky8hWMmXTpuWs+TtIQQLoWUJNVm7HTPLAIgrEfiSJ1kfmP3puX7tu1vrhdSOHVDFSSEOEGnkyoURy0zHA2Pzin47sXX3jRtns5Y93Meqh+TUXrviw/fjxqAAoCg9SfHV3qf27LmJ8tf2Fhd5dIdLt04YaJfmTmTW4FYlBBSnp1/4ZiJV1bMXFA2QXVGkmOzdHom6FMXVWYQ8rippYFYZMWBna/s+Ojf+7bvbaojhPgcTp1pJ5ZGAAY0YsYjZmx6Uel/L1x6XdcE76F916gBKAAIWn9iCaEqveuO7P/esr8v27OFAvgcrhOafiUYKtGR6fEtHDNp6aTZ3R3xpKs7KPWnaZ7QXHb/sKTr9MML2z5cvm9bSyigkmPkRK1QSgYCsYiQcvHYKT9YfP2sEaN7PnzUAAQFAK3/oBrK7lxEXaDte8uee2bjqkA8mu7yqLNXA2d7pJQd0YiQYkrhqOsmn3P91HPH5hQeZ/cpDMf7tgYIC1TKp1sJ9jTW/H3zB89tXbOl5hAF6ne6AGDgvJA6ldYWCfkM543T5/1g8XX5vvQhyQihBqAAIENq/SlrCRyr+g6y9e/Z5/P4+ve+v+y5A021freXUTqAJwuEMMpMYQWiEZ1pi8dOuXn6vE9OnuPQdEKI6BwFekbZ/f6UAICoHtOYZf5j69qnNq5atmeLyS2f06VTjQsuB4ycuBAd4WBZdsH3F19324zzyVD0CHVrQGdN2JeOvaEoAMhg+f7BjnvmXT4k1r+7I3BnQ/U3Xnvy5W0fup0up2YMsP+7TD8PREJpLs9N0+fdPnPBOSPLu13+4XKFlr2PUXYVTgghaw7vffSjFU9vXNUeCflcHp2ygWVAoyxqxcPRyFWTZv90yS1qptAg9/4epwGrXs/0+jEOGHbgpfDDDINpzR2tt8684K/X3T341t8SXHmgP13+wh3P/nF7/dEMjw8A+sv5ACEaZVzK9nDQrRu3z7rwL9fefeesC4rTspT5gK7r1886zwug8+SwEEDIiPSsKyZUXjVxJpdyR92R1nDQ0A2d9ntRu5CSUeZxuLbUHn70oxVSyrkl4xilluCDNvAVuk5lL5lQub+5fm3VTp/LczKHPBAUAOQUMz/N4cD80RMfv/lLBmOD6TirAWiMsn3NdTc88esH17zlNBwuwxgg58MoTTD9F+Z4/VwIdc6WnoWGP0Eglf6pdqA8X9oVFTN6yYBG6QAy4DIMSci/dny06tCe80rHZXv8SowH59FC14C8ReVTVh/au6uh2mM48f4AFAAkKda/PRqaO2rcK5/+RrrTLQex9NeZYgb40wfLbnvq/l2N1Rke/wAHuyhQAGiPhlyanmD6CUPL309AoBpee8lAezTs0h3qqpk+hRkI8Tjduxtrntqwyutwzh4xBgBUdDg437kkxKUbSyfPWVW1a39znVt3oAagACC2vidKo2Y80+3912e+me9LG8wToWokZGsk9LnnH/jJ2/+kjLkNR3+OPwAwSkPxaMwyr6qY8eQt96HpP00ZqG5v2Vp3xBLcqev9/YdCSpduxLj1wpY1+1vqLxwzyW04Bi0dpPTGrRuLyic/vXFVMB41NE2iBqAAILZAAeKcOzVt2We/Mz63cNCsv+y8uYWtObz3E4/84u29WzK9aQRIf/6dRpkprI5oeFpRyUPXf/5biz6Bpv/0ZeDGaefNGVW+re5IVXO9xpjBtD6fv5SSUupxuNYe2vPazg2VxWUj07O5EDAo6SAKwIXIcHsWjZn81MaVMc41SlEBUAAQWywCjZixv13/HxePnTJo8/3V1YAU4Pfvv/GpZ/7QGAqkuT39tfpQAEppayiY4XL/4orb/rj002NzCtVJMDT9pykDkpDy7Py7Zl1Q4M9YfXBXUzDgdjiA9D1lVEjpcbpqO9qe3LDS73SdM6pcFRgGRwMswYvSMkdm5Dy/ZY2h6adzkxqCAoAQQojOtNaOlh8vufU/zr3Y5JbOtMFJ+zDK2qLhzzz355+984LLcDh0vb+0j0ZZ1DKD8ehtlec/dtM9l4ydyijlUjBA02+DDAAAl0KjbNaI0Usnz26LhD48sg8IODS9z1BASOnQdULIi1vW7GupX1g+2aUbg5MOUlM9phaWODT91a1rvC6vwKYgFADkdKx/c6D1P+Zd9uPLb+aCD47150JolB1oqb/+8V+/tm1dlj9D9jOypsvxD4xIy3rg2ru/fdEnMt1enkrX254ZqIfJhcj2+JZOnl2RN2LNwT21HS1uh7PPUEBVhr1O99qqXe8f2nPB6Iost29wysKqFXV+2YT6cGDlvm1epwc1AAUAObW9xNqjofNKJzx+07266sJJ/gZWKabl+7Zd+dDPdzVWZ3rTzH5uAex0/GPRT81c8MytX54zckx3uh/fXZJkQBUGJuWPuGHa3MZQ4MPD+wAGCAWE1+XZ11T7981rpheVjM7KG5w4QJ3lXlg++b2qXfuaal26AwvCKADIx97tcW5muryvf/qbOR6fKvEl9SuqQ0kaZY9+tOLax35lSekxHP0l/TXGWsKBEWmZD1x397cWfcLrcKrSNOZ8kmtbAVS51e90LZ00uyJ/xJqDu2sDrR6Hsz8NcOlGKB57eN3ykozcyqJSde4akvxNSikNTVs0ZvLTG1eFzZhGGSoACgDysXYRDcWjT9x875yRY1RGPqlfTt2swij98fIXvvbKY27DqVPWZ/BOAQhAW7DjyomzXrrrv2aPGKNaTSg6/oPoHMiuUODG6fN2N9ZuPnrAaTjU0eLeui6lRpnGtBe2fcgoXVBWIaWQSW4NAgBL8Ey3d2xOwZMbVjo0AwvCKADIyaIx1hrs+MaiT3xh7iWD0PajZsgAwJdefOiny57zu30ApM+wXaM0Yplxy/qfy2784yc+4zWcaiIxOv5DEgpYQvgdrpumn2fo+lt7tggpHVofTaKSSApgMP31rWubo+ElEyoBQM3hSKZKUUvwCbnFMct6e/cmj9OFp8NQAJCTeCWUtUeCF5ZPfvj6L0gpk91Lo9o9g/HovS8+/Kf338jyZ/Q3lFijrC0SLkrL/PttX7l9xgIhhcSM/1CHAkJKSeT5ZRVzS8Yt37etPtDuNvo7iCu9Ls+Kvdvqgu0XjJno0PRkt4cCASHlwjGTVh3avauh2mU4sRiAAoCcwLMzuZXp9r58139luD3Kk0q29W+Lhq948Kf/3LI609f3YHd1vrc1FLhwzOR/feabk/NHqqwUOv6psGBUvmVMVv5N089bf7RqR91ht8PZX6jncbpW7d+26uCepZPnuHQjqRoAAIRISmHB6InPbHo/YsbRXUABQAZ2/2lHOPjELfeeM7JcCJHU1L+y/u3R8JUP/XTVgV1Z/Vh/1TvYFg7eO//yJ276ks/hUn2i+LJSKRSgXAifw3Vr5fy2aHjFvu1O3eizJCCk9Do9u+qr3z+465ODogFCiEy3tzw7//F177odGASgACD9oFHWGgp8cd7lXz3/imSn/rut/xXK+nv9fbZ7MkrjnEfisb9d//lvLlyqus7Rj0tJDQBVy7ls/PSRGTn/2LIGgOqsj4HSQgqv07W7vnrVoGiAKgZU5BU3hYPv7d/ucWAxAAUASdwnlIbisQl5xc/e+mWNUprM1P9JWn+NsmAsmun2/POOr39y8hwuBFCKJ7xSFgAgAEKIGcVl55WOf33XhrZI2KUbYqg1AAhIIi8YPfHlHetrA22GpmMckCpmBx9BqiClEOL3S+/yGA4pSTKtv+zM+5/I+rdHw4X+jNfu+saiMZPUVTBo+1NdA7rO4i4aM+m1u75R6M9oj4b7DCVNbmV5/asO7LrioZ+2RcMUaPIccwCQkngMx++X3iWEIGj9MQJAjrO2jLUGO7664MrPzrkoqckf1e8ftcwlD/5kAOuvM60lFJhXOn7Z5749Jjt/0CbQITZmXYrSMm+aPm/NoT27G6q9TlfiqY7uOGD1wd03TjtPze9MkuehRsWVZeYFYpHle7ZgVygKANK1NygNxWMVeSMev+lLGkti8kcSqa7i+tKLD/1zy+osX3p/1r852DGvbPyrd31DzZBB6z8cNUCVhT8xec6qg7t21w+kAbvqDjeFQ1dWzJREEuic5ZCE6AQkkeeVjH915wZMBKEAIMfC9phlPnPrl8fmFIikjXyQnRd7sfteeviPq/7VX8dnT+uf5nQP5s0ziO1ONxfCpRufPJEGeJzuVfu3t0RDl42v5EIAJCXXp06fOXW9Ir/40Y9WGExD848CcLajUdYaDnz1gis/O2dRUjMtXHCNsp/9+8Ufv/FsVlrmyVh/IdH6D3sNUOOATqQB0ut0v7tro9PhPL+sgidtZtyxRFA8unzvVuwIQgE42/dn1IoXp2U/efO9hqYlb96nsv6Prl/x1Zcf9bv9QpyU9R+cCwWR5MaXJ6cBUgqX071sz6aRGTmVRaXJ0wAgIAmZM6L82c0ftEVDOsM5cUNqgvARDO3mjJnmr6++Pd3llkmbzaJO7a44sOPOZ//o0h2yryYMtP5ntJ9BhRRpTverd31jXtn45mBH4sUSkhBJpEt33PnsH1cc2MEo628Q7OmveSllusv966tvj5kmHiZHAThbgy9K2yOhqyfNumbiLJ60ZIua8HyotemmJ3/r1h0UaGLlTaMMrf/ZpgGJyUYpJQXq1h03PfnbQ61NGmVCiCStfC7FNRNnXT1pVnskhGlGFICz0PknlhBu3fGzJbdKIiE5YbCUkgBpi4Rvfep3DcF2Q9MTY3+Nso5oeD5a/7NJA+aXje/o63yAkMLQ9IZg+61P/a4tEib9DIW1YflLIon82ZJb3brDEoJgGIACcFahAQtEQ5+fu7g8O1+IZHX+cCko0HtfemjV/m3pLi9PCOoZpYFYpNCf8cId/6l6ftD6n9kawIVIc7pfuOM/C/0ZgVgk0fvmgqe7vKv2b7v3pYcoUJ6cCx0ppULI8uz8z89dHIiGNMA+YxSAs8f7B4ha8aK07G8uXCqlpElL/WuU/fmDtx5f926WPzOx5Z8CjVtWtsf3wh1fz3J7sePzbIBRyoXIcntfuOPr2R5f3LISJd/kVpY/8/F17/75g7e0pBUD1LU231y4tCgtO2rFsRiAAnDWbEKg4Xjsexdfm+7yJOleDnV666OjB772ymN+tzdxDwOAJDJixp6+5b7KolI16QFfzVmiAZbglUWlT99yX8SMSdLHCrQE97u9X3vlsY+OHtAo40koBqhjAekuz/cuvjYcjzEMPVEAzoonTmkgFpleVHrnrAuFFMlw/1VU0RYJ3fHM75VlT8zkUoD2cPBv139+QVmFxXHSw9mFRpnF+YKyir9d//n2cDBxEUoplU7c8czv2yIh5a0nIwgQUtw568LpRaWBWARvFUUBOAuQRArx3Yuv1ShN0tA3LgUA3PvSw9vrjnidrkT3TaOsNdTx5fOvuHPmBVxwjaH1P/s0gDEu+J0zL/jy+Ve0hvpoCuJCeJ2u7XVH7n3pYQBIRjFADYnTKP3uxddKIfDaYBSAMz/67oiGLp0wPXmtn+rM198+XP74h//O9PoTT/wyytoioUXlU3915aew6ntWb36gXIhfXfmpReVT2yKhxNuHLM4zvf7HP/z33z5crlHGk1AM6G4JvXTC9I4otoSiAJzZ3r8kDOh/XnC1JCQZ/o6QglF2sLXxv19/0uv2Jvr+FGjUjI1Mz3761i9D14WC+F7OTqDr9T9965dHpmdHzViiN8CF8Lq9//36kwdbGxllIhlNQZJIQv7zgqsZUBwMgQJwhrv/l4yfNr90vEyC+6+ytKbgn/77n1ojoT5vg5JEWoI/fMMXcjw+kbQGJGT4BAEgpMzx+B6+4QuW4DLBK5FS6oy1RkKf/vufTMG7l5m9+0JKMb90/CXjp2EQgAJw5rv/6t+T4f5ToP+34tXluzenuzx9pv7bQ4H/ueTGC0ZXYNsP0m1/LcEvGF3xP5fc2B4K9FkMSHd5lu/e/H8rXlWnyZKxNQgGASgAZ4n7n4wpm+oG+X3NdT965x9+j8/qy/q3hANXTZ7znxdezfGCF+T4tcEF/88Lr75q8pyWcB8aYAnh9/h+9M4/9jXXsSSMiGCUCgwCUADObPefJtP9l4QIKb/2ymPheDyx75MCRM34qIycv157NyESsPCLHA8AJUT+9dq7R2XkRM14r9yg6goNx+Nfe+UxkZzpEN1BAMUgAAXgzHP/A9Hw5ROmJ8n954IzSp/dvPrlrR/2mfwBgIgZ+83Vd+R6/UIITP0jvQ0BgBAi1+v/zdV3RMxYYmuASgS9vPXDZzevZpTa3hHUHQRcPmF6IBrGIAAF4IxysLgUX5x7STLcf3WWuD7Y/q1/Pe12urjss+s/cPusC66ZOEuNhsb3gfRlgpkl+DUTZ90+64LWPosBUridrm/96+n6YLs6x5uMIOCLcy/hUhCcD4cCcIY8YkpDsUhlcdn80glq4q7d20ZQoD986/mqplqnbiQmfyJmfFRm7s+X3CqS8NWRMysOoELKny+5dVRmbqSvRJBTN6qaan/41vMUqLS7Gqxmlc8vnVBZXBbCg8EoAGeI80/A5Nb/W3ClSzeEFPZmX4QQlNJNNQcfX/+e3+1LPPYFAFEz9pur78jx+CX2fSInMMEgpczx+H9z9R3RvhJBFud+t+/x9e9tqjlIKbW3GgxA1OVl/2/BlSa3AIMAFIBhb/0BImZsdFb+1RNnSZIE9x8IEPj2G88EY5HE3I5K/nxq5oKu5A++buQEqK7QaybO+tTMBX0mghhlwVjk2288AwSk3SaaApVEXj1x1uis/D5LEQgKwLDaTkCjseidsy9064YQwt4FzYVgQF/cvu7NXZvS3b3H/QNAjJvZ3rTvL75eYvIH+VhWWMrvL74+25sW471vbeSCp7u9b+7a9OL2dQwotzkIACGEWzfunH1hNBbFEaEoAMPa/ycm55le/03T5pHOTjv7fH9JAEicWz9863mgVPalPaFo5CeX31ySkYOHfpGPIwAgpCzJyPnJ5TeHopFEKywJAUp/+NbzcW4B2NzXoLbJTdPmZXr9JueYB0IBGMbufyAWXlQ+uTQzh9s9+VlIToE+v2XtxqMHfA5Xr2ysGjpdOWL0HTMXJGnoNHKma4C4Y+aCyhGjEwc1CyF8DtfGowee37KWAhWS2/uluRSlmTmLyicHYmEMAlAAhitSEgfTVPenvaPfVEqnORz8zpvPuAxnH6N6JRFC/GLJbRplSRo6jZzJsWvnoGb2iyW3ib4GNXMpXIbzO28+0xwOqpSRreubEEK+OPcSB9PwUBgKwPB8shTCZrQif8R5JeMlkfYWYIUUAPDXtW8faKhxJbR+Mkrbo6GrJs5cOGZikoZOI2d+/Eopl2LhmIlXTZzZnjCeQUrp0o0DDTV/Xfs2ANg7IIhRKok8r2R8Rf6IsBmlFN0XFIDh92RpPB6/bsq5GrW5UCalpJQ2h4N/Wr3M7XL3dv+BWEL4HK6fLbmVEALSti+K73T4hJ72vCy1eH625Fafw2UJ0Ssdz6Vwu9x/Wr2sORyk1OYggAuhUXrdlHPj8ThFM4UCMNwiaBLnVqbXf+O0uYQQeztwuBRA4G9r3znc0uDUerv/GrBAJHTL9Hnl2flccLtO0wAAFwJlIPVNP7ev2YxSygUvz86/Zfq8QCSkAev1tZyacbil4W9r3wFi85VhasvcOG1uptevSs0ICsDweaxAQ7HIRWOnlGbm2luDVTOlY9x6atMqw3CIBPffFDzN5fnK+VdIdUjAJrNSG2hllHbKAL7gFDT9hCjTzyitDbTaFgQQkER+5fwr0lweU/TuyRFSGIbjqU2rYtyyd5KzqkKXZuZeNHZKKBbBJmYUgGEVARCQQl5VMZMQYu/IFCE5APxz69ot1Yc8hlP05f7fPH1eeXa+ENIW958LQYD8+YO3vv7Ko83hAKMUCEnGDbHI6QWFhFHaHA58/ZVH//zBWwSILYlHSqkQsjw7/+a+ggAhpcdwbqk+9M+tawHA3nYgtbavqpgphcRTwSgAw8f6A0Ss+KisvEvGTiWE2NjHpmZKR8z4L1e8Ymhaby+vt/tvp54tGjP5l8ueO/f+bz+2foUlBAMqpBCYERpqhJRCCgbUEuKx9SvOvf/bv1z23KIxk220mEDIAEGAlNLQtF+ueCVixu2d5Kw2ziVjp47KyotYcexkQwEYHjCgkVh0yYTp2R4fF9zGhauaf1ZW7dxw9IDH4eqV/0mG+6+CcULItKKS8SPLq1oabn/69wsf+OE7+7ZRoBQLA0OY85GSC0EBKNB39m1b+MAPb3/691UtDeNHlk8rKul+cckPAoTH4dpw9MDKqp32tgMBABc82+NbMmF6BE8FowAMo53JKLuqYqbs9J9sjC0IIeQPq99kQHudLAAgpuD+ZLj/AFxwv8O1cMwkIXiuL/2DQ3sW/+VHtz/zh50N1VgYGIIF1iPdv7Oh+vZn/rD4Lz/64NCeXF+6EHzhmEl+h8tez6M7CPC7PKbgCR8sGdA/rH6ze4nauPokIVdVzGSUoZ+BAjBs8j+lWXlzS8aBfV4YUYM/ge5sqF6+d5vH4eyV4WXAAtHwrZXz7XX/e1gAcvn46ZKAybnXcPqd7sfWv3fO/d/6wVvPN4U6sDAwaHSn+5tCHT946/lz7v/WY+vf8zvdXsNpci4JXD5+OrHb8+gOAm6tnB+IhtnxQQAXwuNwLt+7bWdDNQU7R4RSACBkbsm4UswCoQAMl/xPNB5bPHaKz+G0Of9DJCHkyQ0rg9Fwn5d1GEz79OyFyXCTlIxVFpfl+dLjwpJECiky3B5JyPffeOac+7+FhYFBoFe6/5z7v/X9N56RhGS4PUIKSWRcWHm+9MriMmKr59Ez8vj07IUG0/q8dCgYDT+5YWX3QrUx+vQ5nIvHTonGY5gFQgFI/fwPAaC2e2HqUtZgPPbclg+cjt6zHxilwWh48bip0wpLZBKO/qrcboEv/fyy8eFYVBkXLgQlJNObVhtou/2p+7EwkMxFlZDuf+r+2kBbpjeNks5uHwoQjkXPLxtf4EtXtSKbPRtKpRTTCksWj5saTLiykUvhdDif2/JBMB5jNh8K64w+Ae8KRgFI/fxPXJh5vjTbvTB1+OuNXRv3Nta6dEfCBgMh5O0zFtAkXNTX7X4S1ZMnjwmbJMQSXGdapjcNCwPJyvn0le7P9KbpTLME7/GEQUqSjM7jnmuAAtw+Y4EQspdzI6V06Y69jbVv7Npo76GwHtFnWlyYmAVCAUjhpwkQjkUXjK6w3QtTVzU9un4FBehV/qUAoXh0SlHJFRUzpJS98rP2LRRKCJkzqtzvclvHXzwgpbQE92FhwHbTL4WK/JpCgZ7pfp/htATv5QRYgvtd7jmjyrtflu0wYFLKKypmTCkqCcWjCf6NpACPrl9h78Vz3dHngtEV3dEnggKQkhEAASnEgrIKe70wISQFuq+5fsX+HR6Hq1f5lwKNx2M3Tpvr1HRu95WTx74KBSFFWWberBGjw/FoYpaJS4GFARt9bXXbDwA8tv69c+7/Zs90f6KmMkrD8eisEaPLMvOEFEmangZAuBROTb9x2tx4PNbrdC4XwuNwrdi/Y19zPQVqY/inFs+CsgopBJ4IQwFIXSzB/W7vojGTCSGU2Fj+FYSQN3ZvDER6l38BiMmtTK//hqn2Dx3qMwNw9cSZnPP+9iEWBk4TSaQlOAVglL67f/tlD/749qfvr+k4Lt3fp+fBOb964szk5QC7vQ1CyA1T52Z6/WbCiB6NskAk/Mbujd2L1iYjBYSQRWMm+93eXtEnggKQMo+S0ogZH5dTUJqVK4mdjZgMaJzzpzau0nVd9M7/0GAssqh8su1Dh/q0MoSQ+aUTHLpjgMQOFgZOPecjBBDQKNvXXHf3P/5y2d9+/ObuzZkev6H1Svf3kSxy6I75pRO6X1PSBKBzRM+i8snBhBE9gkhd15/auCrOuY0dO5RSSWRpVu64nIKIGac43hwFICUfJZhm/KLyKTplNs5/VjXAzTUHNxytchuOxCZrIOTayeeQpJX+euYZJJET8oon5ReHzdjAeQYsDHy8tyyFkJJR2hEN/+jtf8z7w3f/snqZUzfSXZ7EdH+CfYSwGZuUXzwhr9j2myf6S8hcO/mcxNcvhHAbjg1HqzbXHFRib+Mu0Cm7qHyKacYpZoFQAFIxeJeSMjZ31Fh7vTBJJCHkpR3r4pbZy6sCgIgZH51dsGRCJbF16NAA+9DBtCUTKk3TPJlKIxYGTsaeqnQ/BXhs/Xvz//i977z+VCgey/SmqT86iT1MTdNcMqHSwTR7b57oLx4lhCyZUDk6uyBi9j6cxYDGLfOlHeu6l66N0efcUWMpwyPBKACpBwCYwsr2+G1vAGVApZSrqnYxxnrlf9Shs4vGTvYYDnsPnQ28Dy8qn8KYdvLmGwsD/Un78en+n9z+9P27G2sy/ekM6Mknu4WUjGkXlU9Jdv6ne6lzwT2G46KxkxMPZwkiGWOrqnZJKe3MAnU1g2Z7/KawsBkUBSDlBCBixivyivN96VJKuxaoEAIA9jfXb6o+5DacvfI/aujQ1RWzulJByV8uAISQKYWjSjNzox/naD4WBhJFMSHdvynT43fphsX5yfvOABC14qWZuVMKR5HkHADu2xMg5OqKWYkjeoQQbsO5qfrQ/uZ6ALBrLAQASCnzfekVecWJYQeCAjDkzxE45+eMKqdg5ykY5fK/unNDezig9+7/OTZ0aNB2vvL+0hyui/vy/k4sA1gYOFG6/+OmxVQUePHYyWl2D4A7oR/Q34genbL2cODVnRuIrWMhuBQU4JxR5ZxzLAOgAKRYOC8JAJ07apy9Ybjaae/s20oZk33lf5IxdOhkvL9rJs7SPk4WKMECno2FgdNP9/f5mRrTrpk4eFEgOdGIHkkkZeydfVvt9Uu6ygDjcCYECkAKunXc53SNyy20cRdKKSnQukDbhqNVLt3RyzJKSQCSMvrxZDRp9sjyAn9GnJ/60fyzrTCghvmcZro/0RDHuVngz5g9snwQ8z/H/IDLx08HgF7vSkjp0h0bjlbVBdooUPsupySEkHG5hT6ni0s8DYACkDoPkdKIGR+bXVCaaecJAGXx1x3ZX9vRajC950bq2vmZyRv9OIDREVKkOV3njCqPxGOn86XPksKAcu0Zpfua6+5+/tTT/X2KcSQeO2dUeZrTlYwBcCf0AyqLywr8mb38ACmlwfTajtZ1R/YT+7qTO08DZOaOzcbTACgAqQQQYnJrQl6RTpmNGQxlGlYf2i0TBjxQgLAZqywuTdLoxxMqExCwK+1wBhcGhJQq3W9y/rN/v3je77/zlzWnnu7vzy2+ZuIsIDDIqbPuET2VxaVhs7cfAECkFKsP7Sa2NoMKKXXKJuQVmdzCIgAKQOoIAIAQ0wpLlDmz62MZUCHlmkN7ExtA1dChi8onk+Sf/+rzGyOEXDhmUrZHzQOwYTOeYYWBHgOc4bkta865/5vfeO3JkBnL9Jx6uj/RBJvcyvb4LxwziQzKKZA+I9SLyicnjuhRzaBrDu0VtjaDqs01rbAEcCgQCkBKOXqgaVMKRhH7KsCql7Qu0Laj/qhLN3rpChfCaTgWlE0kg9L63af3l+v1TykcFTFjdk69Hv6FgZ73Na47sv/yB39y05O/3Vp3JNPj1yizcZQNBYiYsSmFo3K9/sGPArsX3oKyiU7DwRMalF26saP+aF2gTXVw2vgVpxSMAk3DU4QoAKnh/gNYgme6vONzi9T/tdG92lBd1Rjs0KnWqwAQ4/GSjJzynHwy2KW/Y98eA3pVxUxuWfYq0LAuDHDReV9jbUfrf/zjrxc98MM3dm/yO12evgY4n7415JZ1VcVMFSkOge0AIISU5+SXZOTEeLxXGUCnWmOwY0N1lY1BqvoS43OLMl1ea1A731AAkP4XZcwySzNzc71pktg2CV1lTldW7ZQJzh0FiJpmZXGpR3fwoXD9SNeAxsvGT0/SgMZhVxjole6fff83H/hgGQFId3m4ECIJ37AaPXvZ+OnE1tGzH2vlcyk8uqOyuDRqmgllAJBSrKzaSewrA1AASWSuN600Mzdm4eUwKACpIACEmMIalZFt2DqlRN0As7nmYOIJACAAUqrRj0OVFVEtGSWZOWOzCyJWPEkD6IdFYaBXun/O/d/8xmtPtoSDmR4/6X+A82k/f4hY8bHZBSWZOfaOnv24PzshZH7pBJCyVyCoTgNsrjlo7/0wUkqDsVEZ2abAOjAKQEoIABAuKvKKbQx11QmAQDy6r6nOkZDuFFIyTZ9qa8nh1NIdOmWXjp9mxuM0mQspZQsDfab7t9UdyfT41X2Nydy31IzHLx0/zd7Rs6ey+AmZWjCKaXriKnVo2r6mukA8auNpAPVVKvKKCcc6MApAKjiAhAClY3MKbXesqpobajradNrHCYBif8bY3EIyRAWAnpv/6okznYYz2TYoBQsDg5nu7/OrOw3n1RNnDq0ToJbf2NzC4oRTgVJKneo1HW1VzQ22h6pjcwqBUqwCowAMPUJKXdPHZOXbuBVV0+f2+iOReKzXeHcKEDXj43OLslxeMUQFgJ6bvyJvxKiM7BgfjIRsihQGBj/d31t6AWLcHJWRXZE3YoidAAAhRZbLOz63KGrGe30njNJIPLa9/gixbyiQ2mJjsvL1hJgDQQEYgg1gcSvb7S3LyrN9K26sqSJEQsIGEIJPKRxJhuIEQK+fnQvu1o0Lx0w8hcFwp+78Dl1hYEjS/YmoMVAXjpno1g0+1M0w6oFPKRwpRO+LQoEQQuTGmirb3Y6yrLxst9fiOBcaBWBoBYAQLnmGy+vWDRtPPKpVvquhBijt62OhLDMvZR4AWTpp9ikPhjudHMhgFgZ6pvt3Nhxd+sgvbnjiN4OT7u/T5mpMWzpp9jEzO9SUZeYlfieSSKB0V0ONvb6RJNKtGxkuL5cczT8KwBBHADHLKsnM8RgOu64BUJ8TMeMHWxoMTet9BExKQzemDHUFuKdQnf5guFM2yoNTGOCyM93fGOr42quPzfndt17esT7d5R6cdH/ikhu6AXD95mSmFIwydIP3nlcoDU072NKgJvjb8qDU53gMR0lmTszCCAAFYMiRMt3lsdeuAYHGUKA+0K5TTfbKOAkry+Udk12QEpvfvsFwp6OXySsMdKb7gZqc/+mDZZW//q//W/EqAUhzuQcn3d+n6A7VALgBnIAx2QVZLq91/F1dkhCdavWB9sZQAAjYq5PpLg/BGgAKwJC7P1KIKQV2ZuSVo3S4taklEtKOv3EJAOKWNSIjy+9w2Xjv2GmaSBsHw52Ok25vYaBnuv/NPZvP+f23vvDPv7VEgpluHx3EdH/fi26IBsAN4JL7Ha4RGVnx411yKaVGWUskdLi1idjXCNRZdSgYKXEiEApAiiSCbP/Mg60NUoiECjAxBc/zpTs0zcaSw+mQjMFwpy4DdhQGEtP9Sx786dbawxlur0r3yyFdaUM7AK6fJyYdmpbnSzcFT1yxUoiDrQ3DYtOhACAf2xlhmj6zaDSxcQwckYSQo+3NIsGeAgEixITcIjJ0Z4D7zAIlYzDcqT690yoM9Jnu9zlcHsOZCtPohnwA3AAx64TcIpLgkgOA4NbR9mZi30AI9SVmFo1m2AmKApASORBbt6Ha1UfamiFhCITabfm+dGXpUkgFkzMY7nRM0sctDAyQ7hdyaNL9fdq+oR0A15/oEkLyfemJSXlJJDB2pK3Zdp8dgKD1RwEYYueXS5HmdBX4M9SKtGmTqxRQY+InpsgQiIQ1lNzBcKeeETq5wkAKp/t7M+QD4AZwyfscCKH2ycHWRmJfgUhtiwJ/RprTxVMmDEIBOBuxBM9weorSsuy1yJbgkYRzld3WKkUyv8fW0KAMhjt1GRiwMJCy6f6+nnNKDIDrD9bPwB8KEDHjNnoGaqMVpWVlOD0p5XCgAJyFjw9i3Ixzy8bcBQXaEYvuaaxxHu9PAYAprFyvf3R2PkmxItigDYY75RxFf4UBRmljMBXT/X0ttpQYANdnKEwIGZ2dn+v1m8d3ggopnZq+p7GmI2bnSDhCSJxbMW5S7AI6PTR8BKez7k1hFaVlqWPANlpkgzGdaqIvedAp8ztdhKTWwu8eDPfLd19JKdvU6+lZkvsMpyTksfXv/XPb2u9dfF260/2Dt5472t7ic7pVd3/KrrcUGQDX19snhBC/06XTPiaiC0J0qhmM2bjv1GHgorSspvBBPeGwJIIRwCCt+zjnhWkZTk23awmqT6lub22PhrXjUz1AiJDS63CpazFSaxkN+mC4UzejXYUBIPD1V5/43D/+0hwOpWC6P9HqpcgAuH7WraQAXodLyN7TqzSg7dFwdXsrsa9zQUrp1PTCtIw4x2kQKABDqgGWrVZDCUlNe0tbNMwSToHFLLM8J99rOFPkFFjP721IBsOdPIzSnkZTVX0z3J50l8fQjkv3AwGWanWMFBsA14dLLqXXcJbn5Pe6qEtKyShri4Zr2luI3b3LVsJBGQQFYAgyC8m2VscF1Kkb7Q7ZYLiTeZhtkVDYjPcaVKCKwMepLAFT8NZwUEipUZY69iUFB8Cd/OKkACwZJWvM/KAADDk6s7+OotF+E6Ypm6YY2sFwA5r+cHs0fOPU826YOjcSi9D+oxMKEDZjM4pKv3L+FYTIllCHICQVZCDVBsCdwuIcYEmn1NZDAUBO3uMFyfmM4lLbHfMqNQcicZ9Lmen2EkJS0PNJhcFwiaY/GI9eNn7am5/51lO33FtZVBpPuLu8149gcivL4/2/Kz/1wT3/e/e5ixkhqSADqTYArg9fnBBCSKbbm+iVA4AUosrWaRBqu80oLpWc4zggFIAzJwJQ1d2qlnrRx1gVkEKoU2Cp2faQCoPhepn+Nz7zzdfu+sbFY6cIKcNm7ISn9QDAFJwLMTF/xJ8/+dn37/lRashAag2A6ysZIwkhUwtGJQ5oA0KE4FUt9cS+aRAYAdiWbMBHYMvSHzRRsWTqdqr0HAwXsUxG6WAKlfpybZEwo3DZ+GlfPX/JojGTlSyZ3HJo+kkGJaoIbAkOBCryiv/8yc/eO++y363617Ob3m8JdfhcHp0yPohnxFJzANzHXZzJMNbY/YkRwFknKqkc7g7VYLg+vf5FYyYLKbkUp1aBVP+VkJILoWRgqKKB1BwA93EXJxprjACQMx/VPHNVxcx3dm8ehOTsAF6/JGpmxml9DxSAAAgppZRDFQ30HABnCU4x442gACCpGlFSQshl46d/1+1LnA4/jEx/6siAKXia29c1AA5DdgQFAElZAaAgpRyTlTetaNSqql0+p1vY2reqhvWLwTL9Qy4DlNJANDyvdPyYrDwpJUX/H0EBQFIZLoVG2bzS8Sv2bqME7DL/QAijzBS8PRzUGBtM0z+EMkAJcMuaVzoeACzBNWC4wBBbQ3YEsZXOwXAVsxyGg9vRswSEaJQJQlpCHRrAnbMXvvHphDLv4PbGDFqJmEvhMBxXV8wiKTYADsEIAEmaDe2/0yP1eykYpZLIqYUlk/JHbKk77DEcJ7qH8SS8/lBHustz97mL7513WUVeMSFESikGy+sfqmiAUgjFY1PyR04tLJFEMprq7po8pSWNYARwZhrrU8bs/4IBDYbBKxNCGIzNHjnGNM1Tq1v29PoZIXefu/j9e370509+tiKvmAuh7oFKkY745EUDlFDTNGePHGMwJlJ4UunJLE7TvjszUFRQAFIIe1e2CvNLM/MoZbK3eyWB0s21h4bD0u/MAtGPfxZsYNMvpGSUpuBhqGTIgJSSUqryP6l9AqRzQW6uPQSU9jruKwmhlJVm5hG7s1jJEJWzDUwBnU7AK4Gx9UeriN3zuUozcqFP0wnQEg6mujHoehpzS8aNyS443NbkOLn7EgZI+HRf3EhS/we3KSkEABErPia7YG7JOJLCA+BID3VqCQcTh21IKYHS0oxc2xfY+qNVwJgkeMQMBeBMiQAUA9x0mvpGUBkvLoXP4Zw5omxPY41LN/iAAnAGmH7bZYACRM34zBFlPoeTS8GGQ+pvgNeUjMt7MQLAFFBKWDvbP1LlOgbwfYZBeCQlIeTycdOJlANELCeT8KHDM9V72kkhIFJePm46GT5zFAa4xCIpY8yxBoARwBCbOUI0W51TlUstTMtMd7otwXvm0KWUDk3f21gXjEc9hiPVLgXr7QwCJYRcNHZKYVpWezSssd63xZ5hXr+90QAAxC2zMC3rorFTSGoPgOtM8gAE49G9jXW90n3qqrh0p7swLZPYXbvSKMXsD0YAQ2n9DcZq2lujlm33n6hPKUrLSHO6e81WlIRQgGAsoqYup34WSEiR502rLC7tNRjuDPb67YoG1AC4yuLSPG9aig+A63qnIKQMxiIUoJdRtqRIc7qL0jKIfbUrAIhaZk17q8EYagAKwJA5PjrVqtubw2YcCNgYp8c5N4VF+1r3puAd0QgZDgcCVBZr0ZjJouvWjrPQ9J+aDAABwXn3OefU94QIIR3RiNnXZcWUEFNYcc5t3HdAIGzGq9ubdarhnFEUgKGzcUQ6mG7YN+tcOc5+h3NsTmHUOu76KqU3DcGO/U11ZDjkhSkBQsgVEyrT3D5LcI2dvab/48kAY5bgaW7fFRMqux9jintChJD9TXUNwY5eFpkCRC1zbE6h3+G0N5QxmOZgusAWIBSAIUSjrDUaqm5vJrbedqRR5tKNPl0/1WAzPNYWpVLK0Vl504tKgvFoazh4lpv+k5SB1nAwGI9OLyoZ3TkAbnhsUt6PfRdSunTDxjuB1Uarbm9ujYaScdUwCgByso4PA9oejdR2tBJC7PLI1ceUZOQkfiIF4JapzoINi/ZnZRTOGVVOOf88mv6Tk4HPn7uYcn7OqPLhIvZqKW6uPcStvq5clrIkI4fYl7RU26K2o7U9GmFAMQV0Wr4mPoLT38P2rkApJQEyIj2r7wuvAeoCbYQMj8Fgqn3l7nMuvnHq3KmFJeTM6vCxcQn17BT6w9JPf27OojSXh6R8/0/nkiSEEFIXaEvsywQCkvMR6VndC9u+bUIotoFiBDDkW5db5kfV+210yZXRL07Loqx3gUsSSSjd2VBNhskgFPVNlmTkTC0sQa//5KOBqYUlymseRm95Z0M1SZwDISVlWnFaFrFvDoT6Eh9V7+874EAwAhjsEDgJQWiJmgbRe+kTnbL6QFvMsgzGhtHzkcPkDHPqRAMwfIadAYGYZdUH2vQ+BlgRoLTE1jkQydt0GAEgH9sZAUq31B4m9p3RVdt+ZEZ2pstjHd9XJ6U0NO1Ia3NHLAIAw2UPAAB6ah9XBmD4HPkGgI5Y5Ehrs6FpvU6BWYJnujwjM7JtjGbUWtpSezhx8ByCAjAE5q0tErLVnyKSyByPL8+XZgoLjt9sGtWaI8F9TbVkOHSII2c8ahHua6ptjgS143tAgRBTWHm+tByPTxJpr6C1RUI4CgIFYOjdH4emHWxpDMVjdrnk6nNculGSmRu3rF5+EwOIm/Etw6cRCDnjg2BCyJbaQ3Ezzo5fqwAQt6ySzFyXbtg1uUR9TigeO9jS6NDwFBgKwBCvfsKAtUaC6jCwvV7V+NxCKURfHysPtNTjw0dShwMt9Yl9nkBACjE+t9DeaFUdA26NBBngHAgUgKGOADSmNYWDB5rrid05memFpYRA4rUwlLItNXZWHRDk1C2IysjXHKaUJV4FQwhMLyy18cupLXagub4pHNQYRgAoACmwAUzL3NdcR+zLyajT/xPzRrgMR685ukJKp27saqhujgQpnoJBhtoBokCbI8FdDdXOhLPrXAiX4ZiYN4LYN9BCbbF9zXUm9oCiAKQCQIgUYk9jjZ2fCUAIKc3KLfSnm8Ls3QjE9KMdrXsaagjWgZEhRS2/PQ01RztaDdZ7ELQpzEJ/emlWLrG7pXVPY40UAs0/CkAKOEFEEkZ31B8ltnaCCil8hnNMdn7Msnp97LAbCIGcyYu/nyEQFCBmWWOy832GnWPg1FfZUX+UMOwBRQFIiT1AdKodam2Kc26jmyOkBICphSUiYSCEJFICrKzaSYbPWSHkzAx/AQghK6t2SoBe5lhNtJ5aWAIAdlaAAeKcH2pt0qmG5h8FIAUEQEqHple1NDQE29W1GPYsdAKEkPmlEyAh0S+kdOr6hqNVITOGw7CQIVz5DGjIjG04WuXU9V4rX0oJQOeXTiD2DYFQVyE1BNurWhp6XT2GoAAM2TbQKGuJBHc1VBP7TqirULeyqDTH6zeF1asM4GDGwdbGvY11BMsAyBChFt7exrqDrY0OZiQUAKwcr7+yqJTYlxpVX2JXQ3VLJKhRhgKAApAaDxFAWpa9h7PUcbB8X3pFXnHEjPc+DkZpNB5bcWA7wTIAMlSuD5GEkBUHtkfjsV6DngAgYsYr8orzfek2Xl7dfehMJhTGEBSAodwJktJNNQeJrUl5LgUFOGdUOeecJpQBgNK3924leBoAGTq/hxDy9t6tiTN5KAHO+TmjyqmtVxqozbWp5qDEKUAoAKkkAERn2s76alNwG82xypzOHTUOgPYKdoWUbt2x4WhVbaANTwMgQ7DmpaRAawNtG45WuXVHQgGAANC5o8YR+woASnJMwXfWV+sMK8AoACmDEMKlG3uaaqtaGoCAEMKu5U4ImTVidIE/I877OA1Q29Gy4egBgmUAZPDXvJSEkA1HD9R2tCSeAIhzs8CfMWvEaBsjVCEEEKhqadjTVOvSDbt2GQoAYgMMWCAa2d1QQ+y7+k6dBsj3pVcWl0bMGO09aYtIKV/ftbErCEGQQY57yeu7Nkope1l4ChAxY5XFpfm+dBtPAKglvruhJhCNMMCrgFEAUgkAIqVYfWg3sbUqq/ysRWMmJ54G4FI4DceyPVsCsSjDjghkMG2/lIyyQCy6bM8Wp+HoleVXJwAWjZlsb2yqttXqQ7ulFFj2QgFIsYiYSMbYmkN7hZQ23uOqar9XTKhMc/tMwXttQpdmVDXXrz64m2AWCBnM1S4lIWT1wd1VzfUuzejlfJiCp7l9V0yoJPaNACKEMKBCyjWH9jLGBIa8KACp5hO5dGNH/dG6QJuNd3VRSqWUo7PyphWNCsejNKHZjgv+0o51PUJkBBmM9U4IeWnHOi56n36nlIbj0WlFo0Zn5UkpqU33gKpe0rpA2476o+p2AXwHKACpJQA61ZpCHbZXZbkUADCvdHxiM6jKAr29Z2soHsMsEDJoS51RForH3t6zNTH/oxpA55WOB1sbQLtrzk2hDp3iFGgUgNQDAATnqw/tIbaWAVTq/+qKWYam99pRKuzY31T72s4NSg/wLSDJRi2z13Zu2N9Um+iMcykMTb+6YhaxtQG0qwCwR9g6cQtBAbANQaSuG2/v3WIKzqhtD5ZRKqWcWlhSWVwajscSY2pJyPNb1xA8EYYMjskAIIQ8v3VNoo9DKQ3HY5XFpVMLS6SU9u4CU/C3927RdQMLACgAKSkAQrh0Y3djbVWznacBOr0qxm6ePs80zV5ZICGF1+F6Z+/WqpYGChRLwUhyF7mUFGhVS8M7e7d6HS6RkP8xTfPm6fMMxuzM/6gTAM0NuxvxBAAKQAqjUdYRDr6zb6sKCOx7SZQQcum46T6X2+rdC0R0prUEO57dvFrpAb4FJJkCIAghz25e3RLs0JnWy9+wBPe53JeOm969aO2KrQkh7+zb2hEOahRPAKAApCpqRM+KAzuIrQkZSkFIMSYrb8HoilAs0iuyFlIYhuOZTaujlskShkYgiG3LWxIGNGqZz2xabRiOXt4GozQUiywYXTEmK09IQamdEyAIISsO7AAcAYQCkOIBstvhXLF/h+0jetT9MLfPWCCkJL2zQNJjOLdUH3x1x3oA4JLji0CSAZccAF7dsX5L9UGP4UzIN4KQ8vYZC+y9AaZ76NCK/TvcDicmOVEAUtlFkgbV6wPttjeDMqCSyEvHTy/PKYiYsYRGCEkpPLp+hZASS8FIsowFgJDy0fUrKIVe504AIGLGynMKLh0/XRI7z0J2N4DWB9oNipfAoACkNmomhO0jegCAC+E1HNdNOTcai/baYFwIr9O9bPfmTTUHASjHKhliu/svBADdVHNw2e7NXqe71xpjQKOx6HVTzvUaDi6ErZ2a3UOHcAIECsAwCJOTNaJH9f/cUjnf6+xdClY7MM6tBz9cjnsESZZzQ8iDHy6PcyvRwbcE9zrdt1TOJ7aOfxh46BCCApBy9BzRI23NAlFKhRQTcosWlk8KxaK9SsFccp/T/cSGlXub6igFbJVDbEQIQSnsbap7YsNKn9Pdq87EKA3FogvLJ03ILRJSUGpn/kf2P3QIQQFISUcJgAv+8o6PoCuAtU9dCCHki3Mv4VL0KgVLSXTKOiKhX7/3KhDAjYLYufAIAQK/fu/VjkhIpyzBDgOX4otzL+leojZ+ZSDk5R0fJQ4dQlAAUhQuhcvhfG3nxqZQwOYsEFAp5fzSCZXFZaFYhB4fiVuS+1yepzauwiAASYb7/9TGVT6Xxzre/adAQ7FIZXHZ/NIJqmPHxmCaUdYUCry2c6PL4cT8DwrAMHGXpHRpxqHm+jf3bCa2jugBIEIKl278vwVXxi2rt08kiU5ZOwYBSHLc//ZISKesV0wLAHHL+n8LrnTphrC1Tqs2zpt7Nh/C/A8KwHDbMxIovLzjI2L3iB4KTEr5iclzphSNCsWjvT4cgwBkcN1/CMWjU4pGfWLyHCkltfWiLrW2X97xEVDA818oAMNq20jhcbje3rPF9hE9AIRL4WDazdPmxeOx3hF37yAAtw1y2q5M/+4/BRqPx26eNs/BNG6r+989dOjtPVs8CUOHEBSA1N42khhMawl2PLPJ/hE96lDYZ+YsGpmZG7Xi0FcQ8OTGVXub6hhlGAQgp+P+M8r2NtU92Zf7DwBRKz4yM/czcxbZe/ire8s8s2l1S7DDSBg6hKAApPzmIcIwjOe2fGAJYeNcXLXxhBBZbu/n5y4OR8IsIQjQKA3EIv/12hNEdVEgyKn5MUAIIf/12hOBWESjtJf7z4CGI+HPz12c5fYKmw9/EUapJcRzWz4wDEMQdGJQAIaf9yTdunNH3ZH3D+4CAvaezlXtQJ+dc1FZbmHE7B0EcCHSnJ6Xt3+0fN92hgeDkVOCC8GALt+3/eXtH6U5Pb1WEQBEzHhZbuFn51xkb/OP+tJA4P2Du3bUHXHrTiHQ/0cBGIYAkBi3/rD6TUIIAXs/GYQUWW7v/1xyYyQe7SP6BkIp/fprj1uCAxDsoEA+nu8vJQCxBP/6a49T2sfZXgY0Eo/+zyU3Zrm9Qtrs/qsv94fVb8a4hd3/KADD1oeSwudwv7N3a1VLI7P7thYKTEhx7ZQ504vLArFIr+OXQgifw7XhyP5HPlqBF8UgHzt+lZICfeSjFRuO7Pc5XL0qSZTSQCwyvbjs2ilzhBT2Nv8IKRnQqpbGd/Zu9Tnc2P6PAjB8/SiiM9YS7Hh60ypCiLR1KQN0lpq/e/G1UgjoS348Ttd/v/7UwdZGauuEXuQssP5wsLXxv19/yuN0JZpgIEQK8d2Lr1XlWXuddLVNnt60qiXYoTOGjWwoAMM7CHA6nA9/+O+wGaeU2puKYZRyKa6ZOOuS8dPawkF2/GVJUkoH05uC7d9f9neVMsLXgZycAAgA+P6yvzcF2x2s9wRmRllbOHjJ+GnXTJzFpc0NDlJKSmnYjD/84b+dePoXBWDYxwBSunTH/ua6l7avA2K/FQZJJJE/uvRGr8PFE0aEWoJneHyPfbTixe3rNMqwGoyc2GURQqPsxe3rHvtoRYbHlzh3lgvudbh+dOmNkkjbj5sLKYDAS9vX7W+uc+kOrF2hAAx/DSBSZ9ovV7wSMePU7isbKaVCiGmFJbfNOL8jHNAYS1Qgp+748kuPNIY6ABNByAnsrwSAxlDHl196xNmX/dUY6wgHbptx/rTCEiHsHPxJCJGSUKARM/7LFa/oTMNjjCgAZ8SmEsLjcG04emBl1c5kpGIAqJDiuxdfW5pdEE1oCRVSunTjUEvDf772BMVEEHIiB5wC/OdrTxxqaXDpRi93AQCiZrw0u+C7F18rpACgtn91AFhZtXPD0QOehMozggIwjMMABlT1g9re1kYBpJR53rT/veymcDTS52UdGR7fo+ve7UoE4aXBSB9wwVXy59F17/aZ/GFAw9HI/152U543TSbh8lHo6v5kQAm6/ygAZ9DWEj6n+/WdG1dW7aJJOJnFKONC3DB17lWTZ7dFQol1OVWK+PJLjzQEOyjFrlAk0fuWlNKGYMeXX3qkz+Q7o7QtErpq8uwbps7lQvTqOLBlj1CgK6t2vb5zoy/hykkEBWB4oyY5//zdl5IRBBBCgBAK8KsrP+U2jMRLWYWUTt041Nr42ecfIAQkJoKQ3i6CIAQ++/wDh1obnX0lf7gQbsP41ZWfosm5mUV96M/ffUng3b8oAGdkEOB3et7ctSlJQQCllAs+Jiv/24s+2REKaLSPRFCm2/fy1rU///dLjDILE0FIj7XBKPv5v196eevaTHcfyR+N0o5Q4NuLPjkmK58Lbm/tt6f7/+auTf6EsRMICsAZEgTwZAYBFKiQ4qsLrlg4bmqfiSBL8DSP7ztvPvPu/h3YFYp0G1+Nsnf37/jOm8+k9Zn6p7QtElo4bupXF1whpKBAk7E1lPvP0f1HATgbggBIQhCgQnOdsgev/3yGy2PyPq5RBQIaZXc++8fGUACPByPq0G9jKHDns3/UKIOEoT8AYHKe4fI8eP3ndcq6l5m9+wLQ/UcBOKuCACA2j4frDgK44CUZOT+5/JZgOJgYBAgpnLrjcFvTTU/8RhIipTx7ztoAAKP0hL/oWeOCyq7Xf9MTvznc1uTUHYldwozSYDj4k8tvKcnI4YInw/0nQADdfxSAsycIeGPnxhe3r0vSoGaV3//M7IW3zb6wJdiReDSMC57u8ryzd/PXXnmMUXr2nAyImSYPh9oi4bZIqL9fViQUjMfOGvdfMEq/9spj7+zdnO7yJPYHa4y1BDtum33hZ2YvVHWCZOwIBvTF7eve2LkR3f/BR8NHMOiOKAFKf/jW81dMmEFBzd212e1hQKWUv7v6zg1HD+xtqvM4nL32lSV4hsf/m/denVI46s6ZF1icJ+rEGeb7E0LKcwounDTL7/L0N2GGAg3GIueMLO/ySs9k1Et/+KN3f/Peqxkef5+p/2A0MjF/xO+uvlNKmy/86g5BAIglxA/feh7U0GlMSQ7y1vB/+3Z8CoOtupS1hAN/ufbuz85ZxO2+L+yYY0XpR0cPLPjj9zTGAEAmNPYRQgLR8PL/+N6CsgpLcI0yfDVnCep1rziwY+Gff+BzupUt7rU8pJQW5yu+8IOZxWVJXaV/XfvO555/oM/uIyTZMMf50/ApDDKSEEbp2sP77pp1oUs3SBIKaxTAErw4LSvL7fvn5g+8TndiqocCpUBf3bn+wjGTitIyuRBndvpbSimJlIRIIvv5pf6IwBn9HFTbz4bqqk8+9ishJaMssQ6kM60t1PG7pZ++auLMJDkHKvZtj4ZveOI33PYrZZCTNBT4CIbEEjk1o7q96cfLX0jegDaNMkvw/zj34ttmXdDc0aKz3uk+IYWhaU2hwNJHftEcDjJ6hl8eCQAUKO383z5/df6FM9v6M0qbw8Glj/yiKRQwNC3RM9CZ1tzRctusC/7j3IuTFxqqwXM/Xv5CdXuTUzNw8CcKwNkUg0vuc3r+tHrZ3qY6SiFJc68YUCHF766+a97oSW2RYGIRjwvhc7hqOlqXPvLz9mj4rKoJn4Woqm97NLz0kZ/XdLT6HK5EyWeUtUWC80ZP+t3VdwkpkpH6J4QIISiFvU11f1q9zOf0WBKTPygAZ1cUQDRKw2bsv157AgjI5DidAEAkSXe5n7j53lxvWtwyaV+j4vxO98oDu6546Kft0bA6TYbv54y0/hRoezR8xUM/XXlgl9/pTsy5U6Bxy8z1pj1x873pLjeRycqGSSBA4L9eeyJsxjRKsfaLAnDWwYVIc3le2rYueS2hhBBKqSX4qIzsp2+5L2zG+ry/2xI8y+tfhRpwdlj/VQd2ZXn7aPtRs8rDZuzpW+4blZFtJWHkQ/fKV62fL21bl+bC1k8UgLM2DJDSoetfeenRtkg4sVHHLtQI6AVlFQ/f8IWIGYO+5lCY3EINOHusv8mt3tafECAQMWMP3/CFBWUVPGmpf1X7bYuEv/LSow5dx9T/0IJdQEMqAIQ4NL22o4UTecnYqTw5g1ZUaG8JXllUqjPttS0feN3eRPsupPA6Xbvrq1cd3PXJyXNcuiGwN+PssP6EEJ1pre3N/7vk1nvmXprUnmB1jfB3lj37+s71fqcHb/1FATjL96d0GY73DuxcMLqiLDMveb2YAJQLPr+soiUWeXfvVo/Tldh9lKgBZ3xv6JmN6vk5ofXXGGsJtH/pgit/dOlNXHBGGSTt+1HnD77wz7/5XW60/igACAFKLSE+PLzvthnnG1pS5m11xvgAUsrLx1fWBdtX7d/mdXpOJg5ADTizrb/OtJZA291zL/3D0k9LKSilSToFLaUkQELx2LWP/aolEtI1DfM/KACIurfdONRcbwp+ybhpyUsEAQF11umi8invVe3eVV/tdboG0ID3D+6+fEKlz+GykjQFDEkaKo1TH2xf+sgvB7b+zcGO+aMnPnHzlxgFQiB5Ys+lYJR9642nX9y6Ns3txdovCgDSbXMHLREEkhCDaUsnz3n/4K7d/WuAx+Hc11z3982rF5RVFKVlogYMO+u/sbrqor/8z/b6oxlub59TFpT1n1c2/pW7vuFzOCUhSbT+x5I/D/qx8ydlwC2dMgBQSu954aFQPAZAkhcdUwAhRbrT/epd35hXNr452JF4SFgZkTSnu6ajdclDP31n3zZ1gQxG7KkeTXaZ2nf2bVvy0E9rOlrT+ur372n9X73rG+lOt5BJTPSpoW+heOyeFx6ilBLMKGIEgCRuEqdmHGppaI9GlkyoTF4iiHR1fLt045OT56waKA6QTl0PxeOPrPt3cXrWjOIypUvYGpSycSQQQil9aN2/b3j815aU6oLoga1/Wqf1T6IvqJI/X335sdd2fISN/ygASL8b2O1wvrdv2/Ti0oq8Yp7MrMtJaoCUUqPU0PS/b3q/NRJaPHaqGhmEZeFUQ5V8hZRfefmRb73+lN/l0Sjtc8zUYFt/wTXKXtq+7msvPZLh9aP1RwFABkJj2lt7tlw75ZwMtycZtwUkasAnJs9ZfXD3rrrDHqc70WQol99tOFbs277q4J5Lx0/DsnCq0V3yveaRXz6zcVWGxydJ31lEjbGWQNv80RNfOZb5SeJ7FFJQSg+1Ni195BcSAGNHFADkBOhMawkHttQeurXyfNLVvplsDbhu6rktkfCq/du9TlefhkNK6XG4djVUP7dlzeSCkWOy8oUUmA5KhahREskoe2fftqse/vnmmkMZbl+fXjYQojPWEmi/e+6lj970Rb/DlWzrL7sGcF/3+P9trz/icbjweDkKAHLibeN2OHfUHjaluHjsFJ7kXarmUTs0/YqKGc2R4Irdm10Od5+N4EJKt2G0RkKPr3+PUXp+WQUAWJgOGkrHXzBK1VDlzz73QNiM+RxOq0/rDwBAWzta7zn/ij9+4jMG04SUyY7huBQaZd9+45nH172b4fVzvO8FBQA5SbfOZTiX79s6vah0Qm5xsvMtSgMkkUsmVBqG4609WxhlDKgkiUeFpc6YzrTXt3+0oebgwvJJfoeLCwEYCgy6lyCk1CitD7bf/OTv/vT+Gz6XW6eM9xW9UaBCyogZ+5/Lb/7JZTer0C3Zsq2yUi/v+OhLLz6U1k9QgqAAIP0ZZQIAb+3Zct2UczPdXiGSO5YHAAiAEGJBWcXI9Oznt3wAQHXWx11R6v97nK7NNQf/sWVNYVrWpPwRAICV4UGDC0EppQDPbVlz4+O/XntkX6bXL/pp0mWUxrkViUcfvO7zXzrv0u7/NrkejBCMskOtTdc88nMuJaMUG4hRAJCP4+IRojO9NRJcd2TfjdPO01myRkQc04CuiyQri0rnl074166NLeGAx3D2mbcVUnoMZ1s0/MzG9w+0NJw7aqzf2Xm7CIYCSQ0NhZSM0rpA2xdfePA7bzwb5Za/n05/QojOtPZoKNvte+GOry+dNFt55cl+PapzIWKZn3j0F7sbazwGpv5RAJBT2kgew7m77nBLJLSkYkayiwHd6QIuxOisvKWTZ3109MDu2sNel0f2owE6Yy7DWHtozz+3fliYlomhQLIdf9bl+N/0xG9W7N+e4fEySvscqQadNzu2nlc24eW7/rOyqEwdEBuM71MKSul9Lz30z80fZHrS8Kp3FADklD0+4XV6Vu7Z4nK4zi+bYHKL0UHQALAEz3L7PjF5ztGO1rUHdzt0g1HaZzpIdQe1RcPPbHp/f1P95MKR2R5fpxVAGbDRpAJQgH3NdV9+6ZHvLns2all+p5v3n/YRUraFOm6ZdcETN99b4MtI6oTnnpjc0pn283+/9NO3nsvyZ/Y5gAhBAUA+hga4HO43dm8qzymYWlgyOA346kIYdUQg2+t/a8+WqGk6DaPPg0WdoYBurD2099nN73sdzmmFozTKBB4btuHtS0kIA2py6y9r3/7U0/d/cHBPhrtfx58QojEWisUA4P+uuv2nl9/i1HQhBRsU628JrjPt6U3vf+nFh/xuH7b9oAAgNgBACMCbuzctHjutKC1zcHIsana0kPKcUeULyyetrtp1qKXB43D16XJ2hQLOiGW+uO3D13ZtLMnMKc/OVxkhgjJwSqZfpfsB4M09m2966nd/W/sOAVA3uct+XplGWUuoY0Ju0fO3f+0Tk+eoBq3BObKnUkwbqw/e8MSvCQCjgIXfYWBb/N++HZ/CMBBqSqNmPM3pXvOlH4/KyFbp4MH50ip70BoJ3fviQ098tMLr8uiM9dfVBwAUIBiLCimvnFD5v5fdVJFXrKyD+iN8lSfl9Uup3u+O+qPf+tfTr+zcQAG8Dqf6o/5WiMl5MBK6deaC311zV4bLM2hpH9JVnzjU2nTO/d9sj4aduoF9nxgBILYhpXRoeksk+OHhfZ+YMsetGyKZUyJ6osrCbsPxiclz8vzpq6p2tUVDbsPRnyVS36pD0zfXHnpyw8qDrY1lWXl5vjSMBk7e66cAO+qPfufNZ7/68qOb6w77nW6Daf310gAhGmMd0bDf4frlVZ/68WU3q2t8Bs36q++5LRq+9rFf7Wmq8TpcaP0xAkDsR6OsJRyYXzrh5bv+y+9wJvX6jkSzLomkQPc11939/F+W79nsd/vUYLgBohZLiEAklO7y3DDtvHvnXdYjGiA4Suh4GyqkJN1e/+9W/evZTe+3RUI+l0c70UPmQnSEAwvHTn3g2s+pER1ABm/qjpCSENkRi1710M9WVu3MdPuw7QcjACRZm83ncO2qPVTd0frJyeeo8b+Ds9UBAAAswbM9/lsr5zt0Y1XVrkAs6jYcsn/NoIR4HC5LytVVu57auKpnNKAKDGf5eDBJiOhK0/f0+t+v2qXrhtfhIlKKfiItlfFvj4R1xr63+LoHPvm5bI/PUjf6DqZbICWj9LPP/fnVbWuzfekmWn8UACR5cCk8LvfaQ3uaw6ElEyoHUwNI11ABRun8sgnXTJp9uLVp09EDjDGD6f3ZKXG8DDy5cdWhtqZsj29EehYFAELOzryQyvao5k4AWHN47/++88JXXn7kZEy/igXj3OwIB6+cOPPZ277yiclzKIDoqhwMmvVXX/FLLz78t7VvZ/rSTY7WH1NAyODkggJt95x/xf3X3KmaggbTgMrOs/6UEPL4+ve+v+y5A021ftWb2H+yAghhlJnCCkQjOtMWj51y8/R5n5w8x6Hp3TkQSiFJN5KnjMsvhZDdGbCYZf5j69qnNq5atmeLyS2f06VTjQs+QP9MV84nWJZd8P3F190243zSNRxiMB9cT+v/+/dezfSlY+YHBQAZRA1grKWj7UvnX/G7odAA0pn8JRSgLtD2vWXPPbNxVSAeTXd5pCQDHP1XV1ZJKTuiESHFlMJR100+5/qp547NKewMcYQg5ExTAmX3lflWv7Onsebvmz94buuaLTWHKFC/0wUAYsBLNylQANIWCfkM543T5/1g8XX5vvTutzCoP06X9b/3xYfvf+/VTH+6hb4/CgBytmkAIcQSQqOUELLuyP7vLfv7sj1bqOpVl2Lga42VKQzFY3EznunxLRwzaemk2VdWzPA5XMcpwXC+RUR2pXG67X4gFnllx/oXtn24fN+2llDA0A2P4ej+YfvdpQAMaCAWEVIuHjvlB4uvnzVidM+Hj9YfQQFADRgaDei2CISQ57as+cnyFzZWV7l0h0s3TigDFIACNbkViEUJIeXZ+ReOmXhlxcwFZRO6laArXa5aW1JdDCSRUkoh1Y8G3XZ/xYGdr+z46N/7tu9tqiOE+BxOnWlCCjHg81GmP2LGI2ZselHpfy9cet2UczpzPkP6rtH6owAgqAF9ZIRMzp/etOqHbz2/v7HW7XSrUQQnMHOEUEoJIREzHjXjFOjorLyFYyZdOm7arBGji9Iyu/8ml0LKzsGlqRMZKLMoCQEgrEd7a3V7y7oj+9/YvWn5vm37m+uFFE7dcOkGIWTgbE+3NEYtMxwNj84p+O7F1940bZ7O2JDkfND6owAgqa4B3TXhITxz231EuTHU8cAHb/31w+WHWxpUokMO2NbSw+EFKUnEikfNOCFQ6M+YVlRycfmU+aXjJ+QVuXVHT8lRTegAQAkMWiORJIRIKdTRCAL0+KcdNmM766tXVu16a++WTdUHazpaCZFO3XBpBgDh/R/l7Wn6AUAlx0Zm5n529sK7z704x+Pv+XiHROBlz6ovWn8UACT1NGDJ/dfcpbbrUGlAzx6hhmD7X9a+89yWD7bUHNKZ5nU4iST8JKbDd2tY3LLCZkwK4TQcozKypxeWzi8dP6Vg1MT84gyXN9FIdUoCAfUhQAgBcmqJI9n5T+ft6pL0Ye4VrZHg9rqjW2oPrazatbGm6lBrUzQeA0rdusPQtG7recKvyIASIMFY1OTWlMJR100593NzFuV608hQ9Pn0erDqp/7Siw/9/r3X0PqjACCppwGUtYQCt8yY//uln053uofQW1TpAi6lKlHGufXsptW/XfX6hqNVQMFrODXKTlge6MoOgeoI4lLELDNqxomUmqYV+bPG5xZOLhhZmpEztbBkbE5Bltvb3+liIQUhQLoS9AMLT5dayAE+rTkc3NNYu7nmYFVr49baw7saaqo7mi3LIgBO3XBourpQUwiZeK1mP3EPtQQPxqNSyMri0vvmXX7DtLkG04i6+HdI811qIbVFw/e88OCT61dmevCsLwoAkpLojDV3tM0bM/HVu76RNtQaQI6vD8e5tWz35gfWvv3v/TtC0bDLcDh1g5yoASYxLABChJRxbkVNUwhOCDE0I8vjLU7Lyvb4JuePzPb4ZhSXUaDl2fluw+HUdJV2/7hEzHjUMsPx2N6mOiHF+qMHmkKBrXWHm0KBo+3NzaFg3IoTQihlTl03mEYB5Ek7+50uP6WEkKgZj8RjHqf7wtEVd8+5aPG4qcr0D2FFp5f1b4+Gr3jop6v2bc/y42kvFAAkhTGY1hTqmFcy/tGb7inLzB3MkZAnkxQihGytO/z0hlXPb1u7t7FODbnUKDthobgPMejM8Ughpcl5nFuWEFJwIiXTdClljtevUeZ3ukZn5Slblun2TsofISVJNKrqN7fVHWkJB9W3ur+5viMasQRvDHYAALdMAgCUaZQaTNMZowCEgDxWDzhZVIHXElyNTS3Pyb920pybKudNzh/ZbXaHMOHTjVo8B1oabn/696sO7sr2+ON4wQsKAJLquSDG2iOhXI//1U//d2VRqcm5ulI4FWSg26VVHfFPbVy14sDOYDSsa7rbcDCgorOL8mOu485r7TsTOGpCRlxY6lRazDLV35JSkIEDDkoBqCr0OjRdnb0yqCa7Gm9k5/wbcjK5neO/QwJAKQCXIhyPmZbpdboXlE24efq87tMPKmBKBdNPCFHLZkN11RUP/qQh1JHm8mDeHwUAGSYaQFnYjLk147fX3Hlr5fxUSCZ0o0q13SeYdjZUv7l709ObVm+uORgz4xrTXIZDp+zkc+gDqIKq//b8wQcuCPf8cvJY8fe0vgdVwzAFj8RjFrccujG1sOSmaXMvGTdtQm5Rl68taMrcl9CduHtiw8r7Xnw4bMXdugPz/igAyHCCURqzrDg3f7D4+m8uXEoIEYNyrfxJBwRSCNktS0KKDw/vf3nHR6uqdm2pO9weCgJjbt0wNA0IEZKcQlgwZJuq09knsrOLKS45T/N4p+SPnFc6/qqKmbNHjlYvosvlT6EDbt2L5MfLX/jesr8bTHdoGs73RwFAhh8qSd0WaLt73mW/vPI2r+FMhZLAwAEBIWRXQ/Ubuze9tXdrZx+9FBrTnLqhMwanlHMfjI3UVZOQRJqcR824xS0CtOscw+RLx00b3+Xvp5rL3+O74hplwXj0/73y+AOr/pXuS1clFtxKKADI8HzBhGhMaw60zR9d8ciNXyzLzOscGZ9i36cknfOPe2bA1Una1Yf2rD28d2dDdWOogwhBKXNousE05Th3JeUH1UpB1wUJ6hsQQsa5FbNMITihNMfjn5BbNGdk+dxRY3ueZO6c/g8EgKbg8+edJd/6O575w8r9O7J86Ra30PajACDDHp2xtkgo15v2h6WfXjpptiRSSpKyN/T2nJXf/ZtH2po3VFe9f3D35tpDextr6wJtETNGpATKHEzTGNMoAyDKIhNCjtVpT1Ub1FkyQo4dMu7SG2IJbnEe45YUnAC4dEe+L708p2BqwajzSsZVFpWOSM8a+MdJtQeuHt0L2z784gsPNgTb010ebPdEAUDOHDRKo5YZM82vXXDljy+7SZ08SrV0UG+3tGvGTq+Zl+3R8L6muh31R7fUHtpRX32wtbEh2N4aCXIhieCqk4cCODSdEMmAapSpc7wAJy4Cq8ovELAE51IQAjHLVL1JRAhCGaOQ4fLmetNKMnIq8oqmFIyqyCsek52f5nQfn04RMBymmaplwKX45r+e/tW7rzh03anpFib9UQCQM4zOkkCoY+HYKX+97u6yzDwuBSXDY96y6MrzJLrSETPeGOo40NxwtL35YEtDbaDtQHN9jFt7GmsZpR3RSEc0BEAJIVzwE7aBMsoIIVIKv9Pjd7q4EGNzChxMK8vKK/Cll2TmFqdllWXl5nj8vc6XKU8fesyxSHFUNYUBPdBS/9nnHli+Z0u6x49JfxQA5IwOBRhrCwfzfem/vfrOa7tmCw/tgeFTsFySdHYFDZBaUUe66gJttR2tqrPlSHtTVXODxjTSR2cnWNwqzcodkZZNCBFSFPgz8n3p6vjYAKkqQggFAmSY3VvQ/dKf37Lmvpcergu0pbu92OmPAoCc+TBK45YVikU+P/eSny25xedwDfnAmdPSAyKlPDayDboKtGDb53cVmnuOmTvVGXOpIJ9qTFMgFvmv15780+o3PQ6Xgb2eZ6cpwEvhz0KklBqlLsOx8sDOV3ZuGJdTMCY7HwDUebHh58UQUFkXNWKBdln/LknoSh9JdchYKM+9z1/yWFPRsRBBfV73h3d9/rC0/mrIBAV4Z+/W6x7/9es7N2R4fOpCedwXKADIWaMBhEgpPQ5nbaDtyQ0r2yKhuSVjnbqhSpfD9xbG44ShC3rcLzrgr2N/E2wOJFLI8f/mv56+76VHmiPBNJeHC4G2HwUAORsRUhpM1xn7976tr+zcONxDAeQkHf+Xtq31Od06007mbgYEBQA5g0MBKQnxOF3docCM4jKvw9l1xyHKwLDXeEkIo7QpFPjOm892Ov5uLxfidGYcISgAyJkWCmiMvbtv2/Nb1xSmZU7KH6FCAUAZGKbS3jXTDQCe27Lmhid+/a+dG7xOt8Gw3ougACAJoQAhxONwtUZCz2xavam6amrhqFxvWqcMoAgMp1dJRFfOZ2fD0c8998CP3nkhYsX9To+Q6PgjKABI/6GAzphLN7bUHn70oxVN4UBlUanX4YSuC6rwEaU4vGvMXGOo47vLnv38P/62re5IusutUYoZfwQFADmx/yildBmGIGTF/u1Pb3zfpRvTCks0xoSUgkiUgRQ1/VIQQhilJud/Wfv2rU/d/+buzQ7dcBsGtvogKADIx5EBKSkhHsMZiEde3Lbu1Z0bMt2+SfkjVM84ykAqmn7oTPff/uwfHvxwuSWFz+EmEkc7IP2CJ4GREy0RAAYQiEW5FJeOm/bV85csGjOZdLaXSAYUH9HQmn4gncMw3tm39f/ee+2N3ZsYUJ/DyWXK3ZqAoAAgwxIKFAhpi4YZhcVjpx4nAylzje1ZFJ91Xi1wnOlftmczFzLd6ZaECEz3IygAiL0wSqWU7dFILxkgnUeNhuuAhGFl+qUQsnt4X0/Tn+Z0qZYtfEoICgCSfBkAuHT8tLvnXLR43FSDaUoGhssw5GGHCraU6Y9za9nuzQ+sffuNXZu4RNOPoAAgQyEDHbGIFLKyuPS+eZdfM2mWz+EiXTVJCpgXssXl78znqHJLIBZ5cdu63656fcPRKqDgd6DpR1AAkKGSAaAESDAWNQUfnZV3x4wF10+dOzanQP0pBgR2ufyEkD2NtX/fvPqR9Sv2N9frlHkdTiIJtvYjKADIEKNmZ0bMeDQey/D4Fo6Z9PlzLr5g9ERlvIS67R3wNPHJufzqZjEgtPMWM/Hu/u1/WvPW8n3bWkMBp+Fw6YbE5k4EBQBJrcUEwICawgpEIw5Nn5BX/MlJs6+feu7YnMLugIAQgrXivu0+keq0Vg+Xv+bvmz/4x7YPd9YfjVmmz+nSqcY7r0lGEBQAJAWXFCGUUill2IzHzXiGx3fRmMlLKiovGzct15t2nBJgTNDl7/e0+w3B9n/t3vTajg1v79vaGgoYuuHWDQAQeJoXQQFAhgvq9hWTW8F4VApRkpm3eNyUKytmLCirULViQoi6n4uq+1fOImdf2X01tKfT7gdikRUHdryyY/2y3VsOttQDpV7DqTNNPSJcTggKADJcAwIgELXi4XiMAh2dlbdwzKRLx0+bVTy6KC2z+292X0Z2phaNRddVkxo9dny6ur1l3dH9b+zatHzftv3N9UIKt+FwaoYkEl1+BAUAOVOWGgADkJJErHjUjBOAfG/a/LIJ55dOWFQ+aWx2IethFrvFYFhHBj1ukz/O6HMh9jTVvLN323tVO1ce2FkXbCdSOnXDpRkABEc4ICgAyJmsBMrHj3MrFI8RIfwuT3l2/sIxk+aWjJtRVDYiPavn31dlTyDD4IreHhZfqpJ4zz890ta8vvrA6oO7l+/btrepriMSIpR6DIc6QyfQ7iMoAMhZtPgIqI4gS/CoZcbNOFCa7fFPyC2aM7J87qix43ILx2YX9IwMlKEUUqhryiiBzn+GxtxLIokgym5Ldaf8cdIlxJ6m2t0NNasP7Vl7eO/OhuqmUIcUwtANp6ZrlKnOH7yhBUEBQM5qVDlUEmlyHjXjFrcAqN/pGp2dPy6ncHphyfSi0nE5BYX+zF56QLrmkiozrMTgWKBwehGDJIQo6066zDyRXZ/fR62CC1HT0bK7sXZjddXGmoO7G2v2N9V1RCNSCo1pTt3QGQMCWNdFUAAQpM+wgABQCkQSwoWIWmbcMomUlLFMl7ckM6c4LWtqwcgx2QWlmbljcwq8htOlGwN8oAoXlD0/GbNLAbr/Ph1w2HXEjAfj0T2NtVUtDfuaajfXHj7a3nywpbElEhScEwBD052azigFQoQkUmJRF0EBQJCPExkod1tKaQoet0xTcMk5odRgWpbHl+HyjsrIznR7J+YVa5TNHDEaCCnwZ+T70rkQ6S43PY0bC4QUbZEwo7Qu0Fbb0SoJ+ejIfkvw7fVHW8LBQ61NrZFgcygQ5xYRAhjTKTM0XacMAFRQgp4+kspo+AiQVEZISbpsKANwG45OPSBSStkRjbSGQzsbqqWURHBCCNN0KYXf6fE7XRbnRWmZeb40lbzRGZtRPFqjVEqSmBhSv2kJsf7ofpNzlTyqD7RXt7dojHVEIx3READllkkIIZQBgINpjFK34fCAs/tbklJyKTCrj2AEgCBJXr4EADrz/Cr7L6QEQizB1VVZcW5Zgh+z8pyf+DMZO+YfUWYwTV18plEmOxNEnZWAznYfNPYIRgAIMvhIVZpNSLNQAEo1IonOWM8y8Mn0C/U06J2dmUCI8usJwSw+ggKAICkuDF3dO33Jwyl9HIKcgeCN3giCICgACIIgCAoAgiAIggKAIAiCoAAgCIIgKAAIgiAICgCCIAiCAoAgCIKgACAIgiAoAAiCIAgKAIIgCIICgCAIgqAAIAiCICgACIIgCAoAgiAIggKAIAiCoAAgCIIgKAAIgiAICgCCIAiCAoAgCIKgACAIgiAoAAiCIAgKAIIgCIICgCAIggKAIAiCoAAgCIIgKAAIgiAICgCCIAiCAoAgCIKgACAIgiAoAAiCIAgKAIIgCIICgCAIgqAAIAiCICgACIIgCAoAgiAIggKAIAiCoAAgCIIgKAAIgiAICgCCIAiCAoAgCIKgACAIgiAoAAiCIAgKAIIgCIICgCAIgqAAIAiCICgACIIgKAD4CBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQBAUAQRAEQQFAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBUAAQBEEQFAAEQRAEBQBBEARBAUAQBEFQABAEQRAUAARBEAQFAEEQBEEBQBAEQVAAEARBEBQABEEQJPX4/7NyspuUjR4BAAAAAElFTkSuQmCC', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }
      ]
    };
    return ContentService.createTextOutput(JSON.stringify(manifest)).setMimeType(ContentService.MimeType.JSON);
  }

  // Apps Script runs the page inside a sandboxed iframe, so the browser's own
  // #hash / ?query never reaches the page. The receipt QR therefore carries
  // ?verify=<TxnID>; it is read here and handed to the page explicitly.
  var verifyId = (e && e.parameter && e.parameter.verify) ? String(e.parameter.verify).replace(/[^\w-]/g, '').substring(0, 60) : '';
  var pageHtml = HtmlService.createHtmlOutputFromFile('Index').getContent()
    .replace('<!--INIT_PARAMS-->', '<script>window.__VERIFY_ID__=' + JSON.stringify(verifyId) + ';</script>');
  return HtmlService.createHtmlOutput(pageHtml)
    .setTitle(CONFIG.APP_NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Exposes the safe subset of CONFIG needed by the client
 * (never expose SPREADSHEET_ID to the browser).
 */
function getClientConfig() {
  return ok({
    APP_NAME: CONFIG.APP_NAME,
    APP_URL: CONFIG.APP_URL,
    VERIFY_URL: (function () { try { return ScriptApp.getService().getUrl() || ''; } catch (e) { return ''; } })(), // v73: the web app's own address — always keeps ?verify=
    TAGLINE: CONFIG.TAGLINE,
    YOUTUBE_VIDEO_ID: CONFIG.YOUTUBE_VIDEO_ID,
    MANAGER_PHONE: CONFIG.MANAGER_PHONE,
    WHATSAPP_NUMBER: CONFIG.WHATSAPP_NUMBER,
    SAVINGS_BONUS_ANNUAL_PERCENT: getGlobalProfitRate(),
    PROFIT: getProfitSettings(),
    REFERRAL_BONUS_AMOUNT: CONFIG.REFERRAL_BONUS_AMOUNT,
    MISSED_AUTO_PAUSE_THRESHOLD: CONFIG.MISSED_AUTO_PAUSE_THRESHOLD,
    BRANCHES: getActiveBranchNames_(),
    ALL_BRANCHES: getBranchNames_(),
    DEFAULT_BRANCH: getDefaultBranchName_(),
    ARCHIVE_AFTER_DAYS: CONFIG.ARCHIVE_AFTER_DAYS,
    INACTIVE_DAYS: CONFIG.INACTIVE_DAYS,
    DEFAULT_REMINDER_DAYS_BEFORE: CONFIG.DEFAULT_REMINDER_DAYS_BEFORE,
    BACKUP_KEEP_COPIES: CONFIG.BACKUP_KEEP_COPIES,
    OFFLINE_MAX_AGE_DAYS: CONFIG.OFFLINE_MAX_AGE_DAYS,
    PAYMENT: getPaymentSettingsInternal(),
    SITE: getSiteSettings(), // Upgrade 20: social links, quotes, per-role videos, carousel, testimonials
    ACTIVE_CAMPAIGN: getPublicActiveSeasonalCampaign().data, // Upgrade 21: nearest seasonal campaign, for the logged-out landing page banner
    APP_VERSION: CONFIG.APP_VERSION, // so the Admin can confirm which delivered zip is actually deployed
    DAILY_TIP: getDailyFinancialTip(), // Upgrade 22: today's financial tip
    PROFIT_STAFF_COST: getProfitabilitySettings().monthlyStaffCost, // Upgrade 25: Admin's own cost assumptions
    PROFIT_OTHER_COST: getProfitabilitySettings().monthlyOtherCost
  });
}

// ---------------------------------------------------------------------------
// v72 BATCH CALL — a dashboard used to fire 8-22 separate google.script.run calls at once; each one is its own server
// execution with its own start-up cost, its own login check and its own re-read of the same sheets. runBundle() runs the
// listed READ-ONLY getters inside ONE execution (so every sheet is read at most once and shared by all of them) and
// returns one envelope per call, in order. Each getter still does its own role check, so nothing is exposed that
// the individual call would not give. Only the getters named below can be called this way.
// ---------------------------------------------------------------------------
function bundleFunctions_() {
  return {
    getMyDashboard: getMyDashboard, getProducts: getProducts, getMyCommitteeGroups: getMyCommitteeGroups,
    getSeasonalTemplates: getSeasonalTemplates, getCustomerChartData: getCustomerChartData,
    getSavingStreakCalendar: getSavingStreakCalendar, getGroupSavingsLeaderboard: getGroupSavingsLeaderboard,
    getWeeklyProgress: getWeeklyProgress, getReferralLeaderboard: getReferralLeaderboard, getMyFamilyOverview: getMyFamilyOverview,
    getTodaysCollections: getTodaysCollections, getFollowUpList: getFollowUpList, getMyCashSettlements: getMyCashSettlements,
    getPendingOnlinePaymentClaims: getPendingOnlinePaymentClaims, getManagerChartData: getManagerChartData,
    getManagerDueTodayList: getManagerDueTodayList, getStreakRiskCustomers: getStreakRiskCustomers, getManagerVisitRoute: getManagerVisitRoute,
    getAdminStats: getAdminStats, getAllUsers: getAllUsers, getPendingPlanActions: getPendingPlanActions,
    getFlaggedTransactions: getFlaggedTransactions, getPendingCashSettlements: getPendingCashSettlements, getBackupStatus: getBackupStatus,
    getAdminChartData: getAdminChartData, getCohortAnalysis: getCohortAnalysis, getBranchComparisonStats: getBranchComparisonStats,
    getTodayPriorities: getTodayPriorities, getKpiAlerts: getKpiAlerts, getMonthForecast: getMonthForecast,
    getTargetVsActualTrend: getTargetVsActualTrend, getCustomerSegments: getCustomerSegments, getCollectionHeatmap: getCollectionHeatmap,
    getFunnelData: getFunnelData, getManagerScorecard: getManagerScorecard, getProfitabilityEstimate: getProfitabilityEstimate,
    getPendingWithdrawalRequests: getPendingWithdrawalRequests
  };
}

/** calls = [[functionName, arg1, arg2, ...], ...]  ->  ok([envelope, envelope, ...]) */
function runBundle(calls) {
  try {
    if (!Array.isArray(calls) || calls.length === 0 || calls.length > 30) return fail('অনুরোধটি সঠিক নয়।');
    var fns = bundleFunctions_();
    var out = calls.map(function (c) {
      var name = c && c[0];
      if (typeof name !== 'string' || !Object.prototype.hasOwnProperty.call(fns, name)) return fail('অনুমোদিত নয়: ' + name);
      try {
        return fns[name].apply(null, c.slice(1));
      } catch (err) {
        Logger.log('runBundle ' + name + ': ' + err);
        return fail('সমস্যা হয়েছে, আবার চেষ্টা করুন।');
      }
    });
    return ok(out);
  } catch (err) {
    Logger.log('Error in runBundle: ' + err);
    return fail('সার্ভারে সমস্যা হয়েছে।');
  }
}

// ---------------------------------------------------------------------------
// 6. SESSION HANDLING (no Session.getActiveUser() — this is a public web app)
// ---------------------------------------------------------------------------

function createSession(user) {
  var token = generateId('SESSION');
  var payload = JSON.stringify({
    UserID: user.UserID,
    Name: user.Name,
    Phone: user.Phone,
    Role: user.Role,
    MustChangePin: user.MustChangePIN === 'Yes'
  });
  var cache = CacheService.getScriptCache();
  var seconds = CONFIG.SESSION_HOURS * 3600;
  // CacheService max is 21600 seconds (6 hours) per key, so also store in
  // PropertiesService as a longer-lived fallback.
  cache.put(token, payload, Math.min(seconds, 21600));
  PropertiesService.getScriptProperties().setProperty('SESSION_' + token, payload);
  PropertiesService.getScriptProperties().setProperty(
    'SESSION_EXPIRES_' + token,
    String(new Date().getTime() + seconds * 1000)
  );
  return token;
}

function getSession(token) {
  if (!token) return null;
  var cache = CacheService.getScriptCache();
  var payload = cache.get(token);
  if (!payload) {
    var props = PropertiesService.getScriptProperties();
    var expiresStr = props.getProperty('SESSION_EXPIRES_' + token);
    if (!expiresStr) return null;
    if (new Date().getTime() > Number(expiresStr)) {
      props.deleteProperty('SESSION_' + token);
      props.deleteProperty('SESSION_EXPIRES_' + token);
      return null;
    }
    payload = props.getProperty('SESSION_' + token);
    if (!payload) return null;
  }
  try {
    return JSON.parse(payload);
  } catch (e) {
    return null;
  }
}

/**
 * Every business function must call this first with the token it receives
 * and the roles allowed to use it. Throws a plain Error which the calling
 * function's own try/catch will convert into a fail() envelope.
 */
function requireRole(token, allowedRoles) {
  var session = getSession(token);
  if (!session) {
    throw new Error('AUTH: আপনার সেশনের মেয়াদ শেষ হয়ে গেছে, আবার লগইন করুন।');
  }
  if (session.MustChangePin) {
    throw new Error('AUTH: আগে নতুন PIN সেট করতে হবে — আবার লগইন করে PIN বদলান।');
  }
  if (allowedRoles && allowedRoles.indexOf(session.Role) === -1) {
    throw new Error('AUTH: এই কাজের অনুমতি আপনার নেই।');
  }
  return session;
}

// ---------------------------------------------------------------------------
// 7. VALIDATION HELPERS
// ---------------------------------------------------------------------------

function validatePhoneAndPin(phone, pin) {
  phone = String(phone || '').trim();
  pin = String(pin || '').trim();
  if (!/^01[0-9]{9}$/.test(phone)) {
    return fail('সঠিক মোবাইল নম্বর দিন (১১ ডিজিট, 01 দিয়ে শুরু)।');
  }
  if (!/^[0-9]{4}$/.test(pin)) {
    return fail('PIN অবশ্যই ৪ ডিজিটের হতে হবে।');
  }
  return ok(true);
}

// ---------------------------------------------------------------------------
// 8. AUTH: REGISTER / LOGIN (with lockout protection — Upgrade 1)
// ---------------------------------------------------------------------------

/**
 * referralCode is optional (Upgrade 8). An unknown code is ignored quietly
 * rather than blocking registration, so a typo never locks a customer out.
 * termsAccepted must be true (Upgrade 14). branch is optional (Upgrade 14) —
 * an empty value means CONFIG.DEFAULT_BRANCH.
 */
function registerUser(name, phone, pin, referralCode, termsAccepted, branch) {
  try {
    name = cleanText(name);
    phone = String(phone || '').trim();
    pin = String(pin || '').trim();
    referralCode = String(referralCode || '').trim();

    if (!name) return fail('নাম লিখুন।');
    var validation = validatePhoneAndPin(phone, pin);
    if (!validation.ok) return validation;
    if (!isTermsAccepted(termsAccepted)) return fail('শর্তাবলীতে সম্মতি দিতে হবে।');
    var userBranch = normalizeBranch(branch, true);
    if (userBranch === null) return fail('শাখা সঠিক নয়।');

    var existing = findOneBy('Users', 'Phone', phone);
    if (existing) return fail('এই মোবাইল নম্বর দিয়ে আগে থেকেই একটি অ্যাকাউন্ট আছে। লগইন করুন।');

    var referrer = null;
    if (referralCode) {
      referrer = findOne('Users', function (u) {
        return u.ReferralCode === referralCode && u.Role === ROLES.CUSTOMER;
      });
    }

    var newUser = {
      UserID: generateId('USR'),
      Name: name,
      Phone: phone,
      PIN: pin,
      Role: ROLES.CUSTOMER,
      Status: 'Active',
      FailedLoginAttempts: 0,
      LockedUntil: '',
      CreatedAt: new Date().toISOString(),
      Badge: '',
      StreakCount: 0,
      ReferralCode: generateUniqueReferralCode(phone),
      ReferredByUserID: referrer ? referrer.UserID : '',
      ReferralBonusAwarded: 'No',
      Branch: userBranch,
      TermsAcceptedAt: new Date().toISOString()
    };
    appendRow('Users', newUser);
    logAudit(newUser.UserID, 'REGISTER', 'নতুন গ্রাহক রেজিস্ট্রেশন: ' + phone + ' (শাখা: ' + userBranch + ', শর্তাবলীতে সম্মত)' +
      (referrer ? ' (রেফার করেছেন ' + referrer.Name + ')' : ''));
    syncCustomersSheet();

    var token = createSession(newUser);
    return ok({
      token: token,
      user: { UserID: newUser.UserID, Name: newUser.Name, Phone: newUser.Phone, Role: newUser.Role },
      referralCode: newUser.ReferralCode
    });
  } catch (err) {
    Logger.log('Error in registerUser: ' + err);
    return fail('রেজিস্ট্রেশনে সমস্যা হয়েছে, আবার চেষ্টা করুন।');
  }
}

function loginUser(phone, pin) {
  try {
    phone = String(phone || '').trim();
    pin = String(pin || '').trim();

    if (!phone || !pin) return fail('মোবাইল নম্বর ও PIN দিন।');

    var user = findOneBy('Users', 'Phone', phone);
    if (!user) return fail('এই মোবাইল নম্বরে কোনো অ্যাকাউন্ট পাওয়া যায়নি।');
    if (user.Status !== 'Active') return fail('আপনার অ্যাকাউন্টটি সক্রিয় নেই। ম্যানেজারের সাথে যোগাযোগ করুন।');

    // --- Lockout check ---
    var lockedUntil = user.LockedUntil ? new Date(user.LockedUntil) : null;
    if (lockedUntil && lockedUntil.getTime() > new Date().getTime()) {
      var minutesLeft = Math.ceil((lockedUntil.getTime() - new Date().getTime()) / 60000);
      logAudit(user.UserID, 'LOGIN_BLOCKED', 'লকআউট চলাকালীন লগইন চেষ্টা');
      return fail('অনেকবার ভুল PIN দেওয়া হয়েছে। ' + minutesLeft + ' মিনিট পর আবার চেষ্টা করুন।');
    }

    if (String(user.PIN) !== pin) {
      var attempts = Number(user.FailedLoginAttempts || 0) + 1;
      var updates = { FailedLoginAttempts: attempts };
      if (attempts >= CONFIG.MAX_FAILED_LOGINS) {
        var lockUntilDate = new Date(new Date().getTime() + CONFIG.LOCKOUT_MINUTES * 60000);
        updates.LockedUntil = lockUntilDate.toISOString();
        updates.FailedLoginAttempts = 0;
        updateRow('Users', user._row, updates);
        logAudit(user.UserID, 'LOGIN_LOCKED', 'পাঁচবার ভুল PIN — ' + CONFIG.LOCKOUT_MINUTES + ' মিনিটের জন্য লক');
        return fail('অনেকবার ভুল PIN দেওয়া হয়েছে। ' + CONFIG.LOCKOUT_MINUTES + ' মিনিট পর আবার চেষ্টা করুন।');
      }
      updateRow('Users', user._row, updates);
      logAudit(user.UserID, 'LOGIN_FAILED', 'ভুল PIN (চেষ্টা ' + attempts + '/' + CONFIG.MAX_FAILED_LOGINS + ')');
      return fail('ভুল PIN দেওয়া হয়েছে।');
    }

    // Successful login — reset the counter
    if (Number(user.FailedLoginAttempts || 0) > 0 || user.LockedUntil) {
      updateRow('Users', user._row, { FailedLoginAttempts: 0, LockedUntil: '' });
    }
    logAudit(user.UserID, 'LOGIN_SUCCESS', 'সফল লগইন');

    var token = createSession(user);
    return ok({
      mustChangePin: user.MustChangePIN === 'Yes',
      token: token,
      user: { UserID: user.UserID, Name: user.Name, Phone: user.Phone, Role: user.Role }
    });
  } catch (err) {
    Logger.log('Error in loginUser: ' + err);
    return fail('লগইনে সমস্যা হয়েছে, আবার চেষ্টা করুন।');
  }
}

/**
 * v57: the page calls this on every start-up with the token saved in the browser. Nothing role-specific (menu, sidebar,
 * dashboard) is shown until the SERVER confirms the session is alive AND the account still exists, is Active and has the
 * role we return here — so a stale or edited browser copy can never show another role's menu.
 */
function validateSession(token) {
  try {
    var session = getSession(token);
    if (!session) return fail('আপনার সেশনের মেয়াদ শেষ হয়ে গেছে, আবার লগইন করুন।');
    if (session.MustChangePin) return fail('আপনার সেশনের মেয়াদ শেষ — আবার লগইন করে নতুন PIN সেট করুন।');
    var user = findOneBy('Users', 'UserID', session.UserID);
    if (!user || user.Status !== 'Active') {
      destroySession(token);
      return fail('আপনার সেশনের মেয়াদ শেষ হয়ে গেছে, আবার লগইন করুন।');
    }
    return ok({ user: { UserID: user.UserID, Name: user.Name, Phone: user.Phone, Role: user.Role } });
  } catch (err) {
    Logger.log('Error in validateSession: ' + err);
    return fail('আপনার সেশনের মেয়াদ শেষ হয়ে গেছে, আবার লগইন করুন।');
  }
}

/** v57: removes a session everywhere it is stored. */
function destroySession(token) {
  if (!token) return;
  try { CacheService.getScriptCache().remove(token); } catch (e) { /* ignore */ }
  try {
    var props = PropertiesService.getScriptProperties();
    props.deleteProperty('SESSION_' + token);
    props.deleteProperty('SESSION_EXPIRES_' + token);
  } catch (e) { /* ignore */ }
}

/** v57: logout now also kills the session on the server (before, the token stayed valid for 72 hours after logout). */
function logoutUser(token) {
  try {
    var session = getSession(token);
    if (session) logAudit(session.UserID, 'LOGOUT', 'লগআউট');
    destroySession(token);
    return ok(true);
  } catch (err) {
    return ok(true);
  }
}

function getMe(token) {
  try {
    var session = requireRole(token, null);
    return ok(session);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 9. PRODUCTS
// ---------------------------------------------------------------------------

function getProducts(token) {
  try {
    requireRole(token, null);
    var products = findAll('Products', function (p) { return p.Status === 'Active'; });
    // Upgrade 21: social proof — how many people are currently saving toward each product.
    var savingPlans = findAll('Plans', function (p) { return p.Status === 'Active' || p.Status === 'AtRisk'; });
    var countByProduct = {};
    var seenPair = {};   // v64: count each customer once per product (popularity = number of customers)
    savingPlans.forEach(function (p) {
      if (!p.ProductID) return;
      var pair = p.ProductID + '|' + p.CustomerID;
      if (seenPair[pair]) return;
      seenPair[pair] = true;
      countByProduct[p.ProductID] = (countByProduct[p.ProductID] || 0) + 1;
    });
    products.forEach(function (p) {
      p.saverCount = countByProduct[p.ProductID] || 0;
      delete p._row;
    });
    return ok(products);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Private-ish Drive folder (link-shared view only) that holds every uploaded product photo. */
function getOrCreateProductImagesFolder() {
  var props = PropertiesService.getScriptProperties();
  var savedId = props.getProperty('PRODUCT_IMAGES_FOLDER_ID');
  if (savedId) {
    try { return DriveApp.getFolderById(savedId); } catch (e) { /* folder was deleted, make a new one below */ }
  }
  var folder = DriveApp.createFolder(CONFIG.APP_NAME + ' - পণ্যের ছবি');
  props.setProperty('PRODUCT_IMAGES_FOLDER_ID', folder.getId());
  return folder;
}

/**
 * Saves one product photo (base64 without the data: prefix) into Drive and
 * returns its public view link. Throws an Error with a Bengali message on bad input.
 */
function saveProductImageToDrive(base64Data, mimeType, label) {
  if (!base64Data) throw new Error('কোনো ছবি পাওয়া যায়নি।');
  if (base64Data.length > 7000000) throw new Error('ছবির সাইজ অনেক বড়, একটু ছোট করে আবার চেষ্টা করুন।');
  var mime = String(mimeType || 'image/jpeg');
  if (mime.indexOf('image/') !== 0) throw new Error('শুধু ছবি (JPG/PNG) আপলোড করা যাবে।');
  var ext = mime === 'image/png' ? 'png' : (mime === 'image/webp' ? 'webp' : 'jpg');
  var bytes = Utilities.base64Decode(base64Data);
  var blob = Utilities.newBlob(bytes, mime, 'product-' + (label || 'img') + '-' + Date.now() + '.' + ext);
  var file = getOrCreateProductImagesFolder().createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return 'https://drive.google.com/uc?export=view&id=' + file.getId();
}

function addProduct(token, data) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    if (!data || !data.itemName || !data.category || !data.estPrice) {
      return fail('ক্যাটাগরি, পণ্যের নাম ও আনুমানিক দাম দিন।');
    }
    var imageUrl = cleanText(data.imageUrl);
    if (imageUrl && !/^https?:\/\//.test(imageUrl)) return fail('ছবির লিংক অবশ্যই http(s):// দিয়ে শুরু হতে হবে।');
    // A directly uploaded photo wins over a pasted link.
    if (data.imageBase64) {
      imageUrl = saveProductImageToDrive(data.imageBase64, data.imageMime, 'new');
    }
    appendRow('Products', {
      ProductID: generateId('PRD'),
      Category: cleanText(data.category),
      ItemName: cleanText(data.itemName),
      EstPrice: Math.round(Number(data.estPrice)),
      Description: cleanText(data.description),
      Status: 'Active',
      ImageUrl: imageUrl
    });
    logAudit(session.UserID, 'PRODUCT_ADDED', data.itemName);
    return ok('পণ্য যোগ করা হয়েছে।');
  } catch (err) {
    Logger.log('Error in addProduct: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin: upload (or replace) the photo of an already-existing product directly from the device. */
function uploadProductImage(token, productId, base64Data, mimeType) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var product = findOneBy('Products', 'ProductID', productId);
    if (!product) return fail('পণ্য খুঁজে পাওয়া যায়নি।');
    var url = saveProductImageToDrive(base64Data, mimeType, productId);
    updateRow('Products', product._row, { ImageUrl: url });
    logAudit(session.UserID, 'PRODUCT_IMAGE_UPLOADED', product.ItemName + ' (' + productId + ')');
    return ok({ url: url });
  } catch (err) {
    Logger.log('Error in uploadProductImage: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 10. INSTALLMENT CALCULATOR & PLANS
// ---------------------------------------------------------------------------

var FREQUENCY_DAYS = { Daily: 1, Weekly: 7, Fortnightly: 15, Monthly: 30 }; // v64: Fortnightly = every 15 days

/**
 * Pure calculation — no sheet access. Rounds the installment UP so the
 * customer's total savings never falls short of the target.
 */
function calculateInstallment(targetAmount, frequency, targetEndDate, flexible) {
  targetAmount = Math.round(Number(targetAmount));
  var intervalDays = FREQUENCY_DAYS[frequency];
  if (!intervalDays) {
    return fail('সেভিং ফ্রিকোয়েন্সি সঠিক নয় (Daily/Weekly/Fortnightly/Monthly)।');
  }
  var start = new Date();
  var end = new Date(targetEndDate);
  var totalDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  if (totalDays <= 0) {
    return fail('লক্ষ্য পূরণের তারিখ ভবিষ্যতে হতে হবে।');
  }
  var totalIntervals = Math.max(1, Math.floor(totalDays / intervalDays));
  var installmentAmount = Math.ceil(targetAmount / totalIntervals);
  // v64: flexible ("যেকোনো পরিমাণ") plan — there is NO fixed installment. 0 is the marker; the customer may
  // deposit any amount each interval. totalIntervals / suggestedAmount are informational only.
  if (flexible) {
    return ok({
      installmentAmount: 0,
      suggestedAmount: installmentAmount,
      totalIntervals: totalIntervals,
      intervalDays: intervalDays
    });
  }

  return ok({
    installmentAmount: installmentAmount,
    totalIntervals: totalIntervals,
    intervalDays: intervalDays
  });
}

function createPlan(token, data) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);

    var customerId = data.customerId || session.UserID; // manager/admin can create for a customer
    if (session.Role === ROLES.MANAGER) assertManagerCanServe_(session, customerId);   // v81
    if (!data.categoryType || !data.itemOrGoalName || !data.targetAmount ||
        !data.savingFrequency || !data.targetEndDate) {
      return fail('সব তথ্য পূরণ করুন: ক্যাটাগরি, লক্ষ্যের নাম, টাকার পরিমাণ, ফ্রিকোয়েন্সি, শেষ তারিখ।');
    }

    var goalName = cleanText(data.itemOrGoalName);
    if (!goalName) return fail('লক্ষ্যের নাম লিখুন।');
    var seasonKey = getTemplateByKey(String(data.seasonKey || '')) ? String(data.seasonKey) : '';

    var flexible = (data.flexibleAmount === true || data.flexibleAmount === 'true' || data.flexibleAmount === 1 || data.flexibleAmount === '1');
    var calc = calculateInstallment(data.targetAmount, data.savingFrequency, data.targetEndDate, flexible);
    if (!calc.ok) return calc;

    var newPlan = {
      PlanID: generateId('PLN'),
      CustomerID: customerId,
      CategoryType: data.categoryType,
      ProductID: data.productId || '',
      ItemOrGoalName: goalName,
      TargetAmount: Math.round(Number(data.targetAmount)),
      SavingFrequency: data.savingFrequency,
      InstallmentAmount: calc.data.installmentAmount,
      AccumulatedSavings: 0,
      Status: PLAN_STATUS.ACTIVE,
      PreviousStatus: '',
      PendingAction: '',
      PendingActionReason: '',
      StartDate: new Date().toISOString(),
      TargetEndDate: new Date(data.targetEndDate).toISOString(),
      AccruedSavingsBonus: 0,
      LastBonusAccrualDate: new Date().toISOString(),
      LastDepositDate: '',
      MissedIntervalCount: 0,
      GroupID: '',
      SeasonKey: seasonKey,
      ArchivedAt: ''
    };
    appendRow('Plans', newPlan);
    logAudit(session.UserID, 'PLAN_CREATED', newPlan.ItemOrGoalName + ' (' + newPlan.PlanID + ') for ' + customerId + (flexible ? ' [যেকোনো পরিমাণ]' : ''));
    return ok(newPlan);
  } catch (err) {
    Logger.log('Error in createPlan: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Flexi-Goal Converter (Upgrade 4). Customer moves their full accumulated
 * balance (and any accrued bonus) from one goal to another with no penalty.
 * The installment is recalculated against the remaining time to the (possibly
 * new) target end date. Allowed from Active or AtRisk (Upgrade 6) plans.
 */
function convertGoalCategory(token, planId, data) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var plan = findOne('Plans', function (p) { return p.PlanID === planId && p.CustomerID === session.UserID; });
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (plan.Status !== PLAN_STATUS.ACTIVE && plan.Status !== PLAN_STATUS.AT_RISK) {
      return fail('শুধুমাত্র সক্রিয় প্ল্যানের লক্ষ্য পরিবর্তন করা যাবে।');
    }
    if (!data || !data.categoryType || !data.itemOrGoalName || !data.targetAmount) {
      return fail('নতুন ক্যাটাগরি, লক্ষ্যের নাম ও টাকার পরিমাণ দিন।');
    }

    var newTargetAmount = Math.round(Number(data.targetAmount));
    var newFrequency = data.savingFrequency || plan.SavingFrequency;
    var newEndDate = data.targetEndDate ? new Date(data.targetEndDate) : new Date(plan.TargetEndDate);

    var wasFlexible = !(Number(plan.InstallmentAmount) > 0);
    var nowFlexible = (data.flexibleAmount === undefined || data.flexibleAmount === null || data.flexibleAmount === '')
      ? wasFlexible
      : (data.flexibleAmount === true || data.flexibleAmount === 'true' || data.flexibleAmount === 1 || data.flexibleAmount === '1');
    var calc = calculateInstallment(newTargetAmount, newFrequency, newEndDate.toISOString(), nowFlexible);
    if (!calc.ok) return calc;

    var alreadySaved = Number(plan.AccumulatedSavings) + Number(plan.AccruedSavingsBonus || 0);
    var updates = {
      CategoryType: data.categoryType,
      ProductID: data.productId || '',
      ItemOrGoalName: cleanText(data.itemOrGoalName),
      SeasonKey: '', // converting to a new goal ends the link to the old seasonal template
      TargetAmount: newTargetAmount,
      SavingFrequency: newFrequency,
      InstallmentAmount: calc.data.installmentAmount,
      TargetEndDate: newEndDate.toISOString()
    };
    if (alreadySaved >= newTargetAmount) {
      updates.Status = PLAN_STATUS.COMPLETED;
    } else if (plan.Status === PLAN_STATUS.AT_RISK) {
      // Converting the goal is treated as re-engagement — give the plan a clean slate.
      updates.Status = PLAN_STATUS.ACTIVE;
      updates.MissedIntervalCount = 0;
      updates.LastDepositDate = new Date().toISOString();
    }
    updateRow('Plans', plan._row, updates);

    logAudit(session.UserID, 'GOAL_CONVERTED',
      plan.ItemOrGoalName + ' → ' + data.itemOrGoalName + ' (প্ল্যান ' + planId + ')');

    return ok({
      planId: planId,
      newInstallmentAmount: calc.data.installmentAmount,
      completed: !!updates.Status && updates.Status === PLAN_STATUS.COMPLETED
    });
  } catch (err) {
    Logger.log('Error in convertGoalCategory: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 11. PAYMENTS (LOCK-PROTECTED) + SMS receipt + confirmation flow — Upgrade 2
//     + missed-installment reset (Upgrade 6) + streak/badge/referral bonus (Upgrade 8)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// GPS VISIT VERIFICATION (v55)
// When a Manager logs a collection, the phone's position at that moment is sent along and stored on the
// transaction (GeoLat/GeoLng/GeoAccuracyM). It is a single reading at the tap of "জমা লগ করুন" — there is NO
// continuous tracking. Only the Admin can see these coordinates. Each customer gets a reference spot
// (CustomerProfiles.HomeLat/HomeLng) from the first precise reading; later collections are compared with it:
//   GeoFlag 'Ok'    — within CONFIG.GEO_FAR_METERS of the reference spot
//   GeoFlag 'Far'   — further away (the Manager may not really have visited)
//   GeoFlag 'Ref'   — this collection created the reference spot
//   GeoFlag 'NoRef' — position known, but no reference spot yet (reading too imprecise to set one)
//   GeoFlag 'NoGps' — the phone gave no position (permission denied / no signal): collection is still accepted
// A phone with a GPS-spoofing app can fake a position — the flags are evidence for review, not proof.
// ---------------------------------------------------------------------------

/** Validates what the browser sent. Returns {lat,lng,acc} (lat/lng rounded to ~1 m) or null. */
function sanitizeGeo(geo) {
  if (!geo || typeof geo !== 'object') return null;
  var lat = Number(geo.lat), lng = Number(geo.lng), acc = Number(geo.accuracy);
  if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;
  if (lat === 0 && lng === 0) return null;
  if (isNaN(acc) || acc < 0) acc = 9999;
  return { lat: Math.round(lat * 100000) / 100000, lng: Math.round(lng * 100000) / 100000, acc: Math.min(Math.round(acc), 9999) };
}

/** Great-circle distance in metres (haversine). */
function geoDistanceMeters(lat1, lng1, lat2, lng2) {
  var R = 6371000, rad = Math.PI / 180;
  var dLat = (lat2 - lat1) * rad, dLng = (lng2 - lng1) * rad;
  var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return Math.round(2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

/**
 * Decides the Geo* fields of a new collection. Needs the script lock (it may create the reference spot).
 * Never throws and never blocks the collection: any problem just means no geo data.
 */
function buildGeoFields(customerId, geoInput) {
  var out = { GeoLat: '', GeoLng: '', GeoAccuracyM: '', GeoDistanceM: '', GeoFlag: 'NoGps' };
  try {
    var g = sanitizeGeo(geoInput);
    if (!g) return out;
    out.GeoLat = g.lat; out.GeoLng = g.lng; out.GeoAccuracyM = g.acc; out.GeoFlag = 'NoRef';
    var profile = findOneBy('CustomerProfiles', 'UserID', customerId);
    var hasRef = profile && profile.HomeLat !== '' && profile.HomeLng !== '' &&
                 !isNaN(Number(profile.HomeLat)) && !isNaN(Number(profile.HomeLng));
    if (hasRef) {
      var d = geoDistanceMeters(Number(profile.HomeLat), Number(profile.HomeLng), g.lat, g.lng);
      out.GeoDistanceM = d;
      // An imprecise reading can't be judged against a 300 m rule: allow its own error margin.
      out.GeoFlag = (d - Math.min(g.acc, 500) > CONFIG.GEO_FAR_METERS) ? 'Far' : 'Ok';
    } else if (g.acc <= CONFIG.GEO_MAX_ACCURACY_M) {
      var nowIso = new Date().toISOString();
      if (profile) {
        updateRow('CustomerProfiles', profile._row, { HomeLat: g.lat, HomeLng: g.lng, HomeLocSetAt: nowIso });
      } else {
        appendRow('CustomerProfiles', { UserID: customerId, HomeLat: g.lat, HomeLng: g.lng, HomeLocSetAt: nowIso, UpdatedAt: nowIso });
      }
      out.GeoFlag = 'Ref';
    }
  } catch (err) {
    Logger.log('buildGeoFields failed: ' + err);
  }
  return out;
}

/** Admin: forget a customer's reference spot (e.g. it was set from a wrong place). The next precise collection sets a new one. */
function clearCustomerHomeLocation(token, userId) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var profile = findOneBy('CustomerProfiles', 'UserID', userId);
    if (!profile) return fail('গ্রাহকের প্রোফাইল পাওয়া যায়নি।');
    updateRow('CustomerProfiles', profile._row, { HomeLat: '', HomeLng: '', HomeLocSetAt: '' });
    logAudit(session.UserID, 'CUSTOMER_HOME_LOCATION_CLEARED', userId);
    return ok('গ্রাহকের রেফারেন্স লোকেশন মুছে ফেলা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin report: collections of the last N days (default 7, max 60) with their GPS result.
 * Returns per-manager totals plus the list that needs a look (Far, and optionally NoGps), newest first.
 */
function getVisitVerification(token, days) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    days = Math.max(1, Math.min(60, Number(days) || 7));
    var since = new Date().getTime() - days * DAY_MS;
    var users = {};
    readSheet('Users').forEach(function (u) { users[u.UserID] = u; });
    var perManager = {}, flagged = [];
    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || !t.VerifiedByManagerID) return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var ms = new Date(t.Timestamp).getTime();
      if (isNaN(ms) || ms < since) return;
      var mgr = users[t.VerifiedByManagerID];
      if (!mgr || mgr.Role !== ROLES.MANAGER) return; // an Admin collecting in person is not audited here
      var m = perManager[mgr.UserID] = perManager[mgr.UserID] || { managerId: mgr.UserID, managerName: mgr.Name, total: 0, ok: 0, far: 0, noGps: 0, noRef: 0, ref: 0 };
      var flag = t.GeoFlag;
      if (!flag) return; // rows from before v55 (or not collected by a Manager) carry no GPS result
      m.total++;
      if (flag === 'Ok') m.ok++; else if (flag === 'Far') m.far++; else if (flag === 'Ref') m.ref++; else if (flag === 'NoRef') m.noRef++; else m.noGps++;
      if (flag === 'Far' || flag === 'NoGps') {
        var cust = users[t.CustomerID];
        flagged.push({
          txnId: t.TxnID, flag: flag, managerName: mgr.Name, customerId: t.CustomerID, customerName: cust ? cust.Name : '',
          amount: Number(t.Amount), timestamp: t.Timestamp,
          lat: t.GeoLat === '' ? null : Number(t.GeoLat), lng: t.GeoLng === '' ? null : Number(t.GeoLng),
          accuracyM: t.GeoAccuracyM === '' ? null : Number(t.GeoAccuracyM), distanceM: t.GeoDistanceM === '' ? null : Number(t.GeoDistanceM), _ms: ms
        });
      }
    });
    flagged.sort(function (a, b) { return b._ms - a._ms; });
    flagged.forEach(function (f) { delete f._ms; });
    var managers = Object.keys(perManager).map(function (k) { return perManager[k]; })
      .sort(function (a, b) { return (b.far - a.far) || (b.noGps - a.noGps) || (b.total - a.total); });
    return ok({ days: days, farMeters: CONFIG.GEO_FAR_METERS, managers: managers, flagged: flagged.slice(0, 100), flaggedTotal: flagged.length });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * clientRefId and occurredAt are optional and only sent by the manager's
 * offline queue (Upgrade 11): clientRefId makes re-sending the same deposit
 * harmless (it is recognised and not booked twice), and occurredAt is the time
 * the money was actually taken.
 */
function logPayment(token, planId, amount, paymentMethod, trxIdReceipt, clientRefId, occurredAt, geo, quick) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);

    amount = Math.round(Number(amount));
    paymentMethod = paymentMethod || 'Cash';
    if (!planId || !amount || amount <= 0) {
      return fail('প্ল্যান ও সঠিক জমার পরিমাণ দিন।');
    }
    if ((paymentMethod === 'bKash' || paymentMethod === 'Nagad') && !trxIdReceipt) {
      return fail('bKash/Nagad-এর জন্য ট্রানজেকশন আইডি দিন।');
    }
    if (trxIdReceipt) {   // v82: আইডি পরিষ্কার করে নেওয়া (স্পেস/ছোট হাতের অক্ষর/বাংলা সংখ্যা)
      var trxCheck = normalizeTrxId_(trxIdReceipt);
      if (!trxCheck.ok) return fail(trxCheck.message);
      trxIdReceipt = trxCheck.id;
    }

    waitLockFresh(lock, 30000);

    // Upgrade 11: the same offline entry arriving twice (e.g. the reply was lost
    // on a weak connection) is answered from the record already stored.
    clientRefId = cleanText(clientRefId);
    if (clientRefId) {
      var earlier = findOneBy('Transactions', 'ClientRefID', clientRefId);
      if (earlier) {
        var earlierPlan = findOneBy('Plans', 'PlanID', earlier.PlanID);
        var earlierSaved = earlierPlan ? Number(earlierPlan.AccumulatedSavings || 0) : 0;
        var earlierBonus = earlierPlan ? Number(earlierPlan.AccruedSavingsBonus || 0) : 0;
        var earlierTarget = earlierPlan ? Number(earlierPlan.TargetAmount) : 0;
        return ok({
          newBalance: earlierSaved,
          target: earlierTarget,
          progressPercent: earlierTarget > 0 ? Math.min(100, Math.round(((earlierSaved + earlierBonus) / earlierTarget) * 100)) : 0,
          completed: !!earlierPlan && earlierPlan.Status === PLAN_STATUS.COMPLETED,
          needsCustomerConfirmation: earlier.CustomerConfirmed === 'Pending',
          alreadySynced: true
        });
      }
    }

    // Duplicate receipt guard (Upgrade 1)

    var plan = findOneBy('Plans', 'PlanID', planId);
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    assertManagerCanServe_(session, plan.CustomerID);   // v81: শুধু নিজের শাখার গ্রাহক
    if (trxIdReceipt) {   // v82: একই TrxID দ্বিতীয়বার নয় (এই গ্রাহকের আগের বাতিল দাবি ছাড়া)
      var trxDupe = blockDuplicateTrxId_(session, trxIdReceipt, plan.CustomerID, '');
      if (trxDupe) return trxDupe;
    }
    if (plan.Status !== PLAN_STATUS.ACTIVE && plan.Status !== PLAN_STATUS.AT_RISK) {
      return fail('এই প্ল্যানটি সক্রিয় নেই।');
    }

    // Cash deposits logged by a Manager need the customer's own PIN
    // confirmation later; digital payments already carry a receipt ID as proof.
    // v74: কুইক কালেকশনে গ্রাহকের নিশ্চিতকরণ লাগে না — টাকা সরাসরি অ্যাকাউন্টে যোগ হয়; অ্যাডমিন পরে হিসাব মিলিয়ে নেন
    // (ম্যানেজারের ক্যাশ সেটেলমেন্ট ও অডিট লগে এন্ট্রিটি "কুইক" চিহ্নিত থাকে)।
    var isQuick = (quick === true || quick === 'true') && (session.Role === ROLES.MANAGER || session.Role === ROLES.ADMIN);
    // v89: অ্যাডমিন/ম্যানেজারের নেওয়া প্রতিটি জমা (কুইক হোক বা সাধারণ ফর্ম) সঙ্গে সঙ্গে অনুমোদিত —
    // গ্রাহকের কাছে কোনো নিশ্চিতকরণ চাওয়া হয় না। গ্রাহকের নিজের পাঠানো পেমেন্ট আলাদা পথে
    // (submitOnlinePaymentClaim) যায় এবং অ্যাডমিন/ম্যানেজার অনুমোদন না করা পর্যন্ত ব্যালেন্সে ওঠে না।
    var needsConfirmation = false;

    // Was this the customer's very first-ever deposit (any plan)? Used for the
    // Upgrade 8 referral bonus, checked BEFORE we append the current transaction.
    var priorCustomerDeposits = findAll('Transactions', function (t) {
      return t.CustomerID === plan.CustomerID && t.TxnType === 'Deposit';
    });
    var isFirstDepositEver = priorCustomerDeposits.length === 0;

    var txnTime = resolveTransactionTime(occurredAt, session.UserID);
    guardManagerDayOpen_(session, dhakaDateStr(new Date(txnTime.iso)), !!clientRefId);   // v83: বন্ধ দিনে নতুন এন্ট্রি নয়

    var txn = {
      TxnID: generateId('TXN'),
      PlanID: planId,
      CustomerID: plan.CustomerID,
      Amount: amount,
      PaymentMethod: paymentMethod,
      TrxID_Receipt: trxIdReceipt || '',
      VerifiedByManagerID: session.UserID,
      CustomerConfirmed: needsConfirmation ? 'Pending' : 'Yes',
      TxnType: 'Deposit',
      Timestamp: txnTime.iso,
      SettledInSettlementID: '',
      ClientRefID: clientRefId,
      SyncedAt: txnTime.honored ? new Date().toISOString() : ''
    };
    // v55: where the Manager was at the moment of collection (see GPS VISIT VERIFICATION)
    var geoFields = buildGeoFields(plan.CustomerID, geo);
    Object.keys(geoFields).forEach(function (k) { txn[k] = geoFields[k]; });
    appendRow('Transactions', txn);

    // Upgrade 15: the shared applyDepositEffects() helper does everything this
    // block used to do inline — it is also used when an online bKash/Nagad
    // payment claim is approved, so both paths follow identical rules.
    var effects = applyDepositEffects(plan, amount, txnTime.iso, isFirstDepositEver);

    logAudit(session.UserID, 'PAYMENT_LOGGED', amount + ' টাকা জমা, প্ল্যান ' + planId +
      (isQuick ? ' [কুইক কালেকশন — গ্রাহকের নিশ্চিতকরণ ছাড়া]' : '') + (txnTime.honored ? ' (অফলাইনে নেওয়া, পরে সিঙ্ক হয়েছে)' : '') + ' [GPS: ' + geoFields.GeoFlag + ']');

    return ok({
      newBalance: effects.newTotal,
      target: Number(plan.TargetAmount),
      progressPercent: effects.progressPercent,
      completed: effects.justCompleted,
      needsCustomerConfirmation: needsConfirmation,
      alreadySynced: false
    });
  } catch (err) {
    Logger.log('Error in logPayment: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * Customer confirms a manager-logged cash deposit by re-entering their PIN.
 */
function confirmDeposit(token, txnId, pin) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var txn = findOne('Transactions', function (t) {
      return t.TxnID === txnId && t.CustomerID === session.UserID;
    });
    if (!txn) return fail('জমার তথ্য খুঁজে পাওয়া যায়নি।');
    if (txn.CustomerConfirmed !== 'Pending') return fail('এই জমাটি ইতিমধ্যে নিষ্পত্তি হয়ে গেছে।');

    var user = findOneBy('Users', 'UserID', session.UserID);
    if (!user || String(user.PIN) !== String(pin || '').trim()) {
      return fail('ভুল PIN দেওয়া হয়েছে।');
    }

    updateRow('Transactions', txn._row, { CustomerConfirmed: 'Yes' });
    logAudit(session.UserID, 'DEPOSIT_CONFIRMED', txnId);
    return ok('জমা নিশ্চিত করা হয়েছে। ধন্যবাদ!');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Customer disputes a manager-logged cash deposit (they say they didn't pay
 * this, or the amount is wrong). Flags it for Admin review.
 */
function disputeDeposit(token, txnId, reason) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var txn = findOne('Transactions', function (t) {
      return t.TxnID === txnId && t.CustomerID === session.UserID;
    });
    if (!txn) return fail('জমার তথ্য খুঁজে পাওয়া যায়নি।');
    if (txn.CustomerConfirmed !== 'Pending') return fail('এই জমাটি ইতিমধ্যে নিষ্পত্তি হয়ে গেছে।');

    updateRow('Transactions', txn._row, { CustomerConfirmed: 'No' });
    logAudit(session.UserID, 'DEPOSIT_DISPUTED', txnId + ' — কারণ: ' + (reason || 'উল্লেখ করা হয়নি'));
    return ok('আপত্তি জানানো হয়েছে। অ্যাডমিন শীঘ্রই বিষয়টি দেখবেন।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 12. SAVINGS PROFIT — v51 DAILY ACCRUAL / LEDGER METHOD
//   profit of one transaction = effective_amount × (annual_rate / 100) × elapsed_days ÷ 365
//   elapsed_days = calc_date − txn_date (calendar days, Asia/Dhaka). Deposits are +, withdrawals/refunds are −.
//   total profit = sum over all transactions. A transaction made today has elapsed_days = 0, so a
//   withdrawal never earns (or costs) anything on the day it is made.
//   Profit is ALWAYS derived from the Transactions ledger, so it can never drift from the passbook.
//   The month-based logic of v50 is gone.
// ---------------------------------------------------------------------------

var BN_MONTH_NAMES = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
var PROFIT_ENGINE_ID = 'DAILY_LEDGER_V51';

// ---- Dhaka calendar helpers (also used by the monthly e-mail report) ----
function profitYm(date) { return Utilities.formatDate(date, CONFIG.TIMEZONE, 'yyyy-MM'); }
function profitDay(date) { return Utilities.formatDate(date, CONFIG.TIMEZONE, 'yyyy-MM-dd'); }
function ymAdd(ym, n) {
  var p = ym.split('-'); var idx = Number(p[0]) * 12 + (Number(p[1]) - 1) + n;
  var y = Math.floor(idx / 12), m = (idx % 12) + 1;
  return y + '-' + (m < 10 ? '0' : '') + m;
}
function ymDays(ym) { var p = ym.split('-'); return new Date(Number(p[0]), Number(p[1]), 0).getDate(); }
function profitMonthLabel(ym) { var p = String(ym).split('-'); return (BN_MONTH_NAMES[Number(p[1]) - 1] || '') + ' ' + p[0]; }

function round2(n) { return Math.round((Number(n) + 1e-9 * (n >= 0 ? 1 : -1)) * 100) / 100; }

/** Any date-like value (Date, ISO text, 'YYYY-MM-DD') -> 'YYYY-MM-DD' on the Dhaka calendar, or '' if invalid. */
function toDhakaDay(value) {
  if (value === null || value === undefined || value === '') return '';
  if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  var d = value instanceof Date ? value : new Date(value);
  if (isNaN(d.getTime())) return '';
  return profitDay(d);
}

/** 'YYYY-MM-DD' -> whole day number (timezone-free, so differences are exact calendar days). */
function dayNumber(dayStr) {
  var p = String(dayStr).split('-');
  return Math.round(Date.UTC(Number(p[0]), Number(p[1]) - 1, Number(p[2])) / 86400000);
}

/**
 * PURE (no sheet access) — the daily accrual / ledger engine.
 * transactions: [{deposit_id, type:'Deposit'|'Withdrawal'|'Refund', amount, date}]  (amount sign is ignored; type decides)
 * annualRate:   percent per year (12 means 12%)
 * calcDate:     optional; default = today in Asia/Dhaka
 * Returns { total_principal, total_interest, total_balance, breakdown:[{id,type,amount,elapsed_days,accrued_interest}], annual_rate, calc_date }
 * Rules: chronological order; same-day deposits are applied before same-day withdrawals; a withdrawal can never take more
 * than the principal at that moment (so principal never goes below 0); refund = withdraw everything; interest never below 0;
 * transactions dated after calcDate are ignored; results rounded to 2 decimals at the very end.
 * v56: missedDays = ['YYYY-MM-DD', ...] — days on which an installment was due and missed. A missed day earns NO profit:
 * that one day's profit (principal held going into that day x rate / 365) is taken out. Missed days after calcDate are ignored.
 */
function computeDailyAccrual(transactions, annualRate, calcDate, missedDays) {
  var rate = Number(annualRate);
  if (isNaN(rate) || rate < 0) rate = 0;
  if (rate > 100) rate = 100;
  var calcDay = toDhakaDay(calcDate || new Date());
  if (!calcDay) throw new Error('ভুল হিসাবের তারিখ।');
  var calcNum = dayNumber(calcDay);

  var rows = [];
  (Array.isArray(transactions) ? transactions : []).forEach(function (t, idx) {
    if (!t) return;
    var day = toDhakaDay(t.date);
    var amt = Math.abs(Number(t.amount));
    var type = String(t.type || 'Deposit');
    if (!day || isNaN(amt) || amt === 0) return;
    if (['Deposit', 'Withdrawal', 'Refund'].indexOf(type) === -1) return;
    var num = dayNumber(day);
    if (num > calcNum) return; // future-dated: not earning yet
    rows.push({ id: t.deposit_id === undefined ? '' : t.deposit_id, type: type, amt: amt, day: day, num: num, idx: idx, order: type === 'Deposit' ? 0 : 1 });
  });
  rows.sort(function (a, b) { return (a.num - b.num) || (a.order - b.order) || (a.idx - b.idx); });

  var principal = 0, interest = 0, breakdown = [], effList = [];
  rows.forEach(function (r) {
    var eff;
    if (r.type === 'Deposit') eff = r.amt;
    else if (r.type === 'Refund') eff = -principal;
    else eff = -Math.min(r.amt, principal);
    principal += eff;
    effList.push({ num: r.num, eff: eff });
    var elapsed = calcNum - r.num;
    var accrued = eff * (rate / 100) * elapsed / 365;
    interest += accrued;
    breakdown.push({ id: r.id, type: r.type, amount: round2(eff), elapsed_days: elapsed, accrued_interest: round2(accrued) });
  });

  // v56: no profit for a day whose installment was missed (each distinct day counted once)
  var missedDeduction = 0, missedCount = 0, seenMissed = {};
  (Array.isArray(missedDays) ? missedDays : []).forEach(function (md) {
    var mDay = toDhakaDay(md);
    if (!mDay || seenMissed[mDay]) return;
    seenMissed[mDay] = true;
    var mNum = dayNumber(mDay);
    if (mNum > calcNum) return; // not reached yet
    var heldGoingIn = 0;
    effList.forEach(function (e) { if (e.num <= mNum - 1) heldGoingIn += e.eff; });
    if (heldGoingIn <= 0) return;
    missedDeduction += heldGoingIn * (rate / 100) / 365;
    missedCount++;
  });
  interest -= missedDeduction;

  var totalPrincipal = round2(Math.max(principal, 0));
  var totalInterest = round2(Math.max(interest, 0));
  return {
    missed_days_count: missedCount,
    missed_days_deduction: round2(missedDeduction),
    total_principal: totalPrincipal,
    total_interest: totalInterest,
    total_balance: round2(totalPrincipal + totalInterest),
    breakdown: breakdown,
    annual_rate: rate,
    calc_date: calcDay
  };
}

// ---- Admin-controlled rates: one global yearly % + an optional per-customer override (Users.ProfitRatePercent) ----
function getGlobalProfitRate() {
  var raw = PropertiesService.getScriptProperties().getProperty('PROFIT_ANNUAL_RATE');
  var n = (raw === null || raw === '') ? NaN : Number(raw);
  return isNaN(n) ? (Number(CONFIG.SAVINGS_BONUS_ANNUAL_PERCENT) || 0) : n;
}

/** The yearly % that applies to one customer row. */
function getCustomerProfitRate(user, globalRate) {
  var g = (globalRate === undefined) ? getGlobalProfitRate() : globalRate;
  if (user && user.ProfitRatePercent !== '' && user.ProfitRatePercent !== null && user.ProfitRatePercent !== undefined) {
    var n = Number(user.ProfitRatePercent);
    if (!isNaN(n) && n >= 0 && n <= 100) return { rate: n, custom: true };
  }
  return { rate: g, custom: false };
}

function getProfitSettings() {
  var props = PropertiesService.getScriptProperties();
  var customCount = 0;
  try {
    customCount = readSheet('Users').filter(function (u) { return u.Role === ROLES.CUSTOMER && getCustomerProfitRate(u, 0).custom; }).length;
  } catch (e) { /* settings must never break the page */ }
  return {
    method: 'DAILY',
    percent: getGlobalProfitRate(),
    customRateCount: customCount,
    lastSyncAt: props.getProperty('PROFIT_LAST_SYNC_AT') || ''
  };
}

/** v56: Plans.MissedDays ('2026-01-05,2026-01-06') -> clean array of 'YYYY-MM-DD'. */
function parseMissedDays(value) {
  if (!value) return [];
  return String(value).split(',').map(function (x) { return x.trim(); }).filter(function (x) { return /^\d{4}-\d{2}-\d{2}$/.test(x); });
}

/** v56: 'YYYY-MM-DD' for a whole day number (inverse of dayNumber). */
function dayFromNumber(num) { return new Date(num * 86400000).toISOString().slice(0, 10); }

/**
 * PURE (v56) — which installment due-days were missed, strictly after afterDay and before todayDay.
 * Interval k runs startDay + k*I .. startDay + (k+1)*I - 1 (I = 1 / 7 / 30 days); its installment is due on the LAST day of
 * that interval. If no deposit was made inside the interval, that due-day is missed (the day must be fully over: due-day < today).
 * depositDays: ['YYYY-MM-DD', ...] of the plan's deposits.  endDay (optional): no installments are due after the target end date.
 * afterDay '' = look at every interval from the start.
 */
function computeMissedDueDays(startDay, intervalDays, depositDays, todayDay, afterDay, endDay) {
  var out = [];
  if (!startDay || !intervalDays || !todayDay) return out;
  var startNum = dayNumber(startDay), todayNum = dayNumber(todayDay);
  var afterNum = afterDay ? dayNumber(afterDay) : -Infinity;
  var endNum = endDay ? dayNumber(endDay) : Infinity;
  var depNums = (depositDays || []).map(dayNumber);
  for (var k = 0; k < 5000; k++) {
    var from = startNum + k * intervalDays, due = from + intervalDays - 1;
    if (due >= todayNum || due > endNum) break;
    if (due <= afterNum) continue;
    var paid = depNums.some(function (n) { return n >= from && n <= due; });
    if (!paid) out.push(dayFromNumber(due));
  }
  return out;
}

/** Ledger rows of one plan in the shape computeDailyAccrual expects (unverified / rejected online claims never earn). */
function accrualTxnsFromRows(rows) {
  var out = [];
  rows.forEach(function (t) {
    if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
    out.push({ deposit_id: t.TxnID, type: t.TxnType || 'Deposit', amount: Number(t.Amount), date: t.Timestamp });
  });
  return out;
}

function groupTxnsByPlan(allTxns) {
  var map = {};
  allTxns.forEach(function (t) { (map[t.PlanID] = map[t.PlanID] || []).push(t); });
  return map;
}

/** Live profit for a plan right now. Returns the engine result plus the bonus balance to show (profit + referral/streak extras). */
function livePlanProfit(plan, planTxnRows, rate, calcDate) {
  var acc = computeDailyAccrual(accrualTxnsFromRows(planTxnRows || []), rate, calcDate, parseMissedDays(plan.MissedDays));
  var stored = Number(plan.AccruedSavingsBonus || 0);
  var snapshot = Number(plan.ProfitAccrued || 0);
  acc.extra_bonus = round2(Math.max(stored - snapshot, 0));
  acc.bonus_balance = round2(acc.extra_bonus + acc.total_interest);
  return acc;
}

/**
 * Writes today's profit into the plan: AccruedSavingsBonus moves by the CHANGE since the last snapshot
 * (so referral/streak bonuses added by other code are never touched) and ProfitAccrued holds the snapshot.
 * MUST be called while holding the script lock. Returns the engine result.
 */
function syncPlanProfit(plan, planTxnRows, rate) {
  var acc = computeDailyAccrual(accrualTxnsFromRows(planTxnRows || []), rate, undefined, parseMissedDays(plan.MissedDays));
  var snapshot = Number(plan.ProfitAccrued || 0);
  var delta = round2(acc.total_interest - snapshot);
  if (delta !== 0) {
    var newBonus = round2(Math.max(Number(plan.AccruedSavingsBonus || 0) + delta, 0));
    updateRow('Plans', plan._row, { AccruedSavingsBonus: newBonus, ProfitAccrued: acc.total_interest });
    plan.AccruedSavingsBonus = newBonus;
    plan.ProfitAccrued = acc.total_interest;
  }
  acc.extra_bonus = round2(Math.max(Number(plan.AccruedSavingsBonus || 0) - acc.total_interest, 0));
  acc.bonus_balance = round2(acc.extra_bonus + acc.total_interest);
  return acc;
}

/** Convenience for single-plan operations (withdrawal, refund): re-reads the ledger and the customer's rate, then syncs. Lock required. */
function syncPlanProfitFresh(plan) {
  var rows = findAllBy('Transactions', 'PlanID', plan.PlanID);
  var user = findOneBy('Users', 'UserID', plan.CustomerID);
  return syncPlanProfit(plan, rows, getCustomerProfitRate(user).rate);
}

/** Daily job (trigger name kept: accrueAllBonuses). Brings every open plan's stored profit up to today. Safe to run any number of times. */
function syncAllPlanProfits() {
  var lock = LockService.getScriptLock();
  try {
    waitLockFresh(lock, 30000);
    return syncAllPlanProfitsCore();
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Same as syncAllPlanProfits but the CALLER already holds the script lock (e.g. the schema upgrade). */
function syncAllPlanProfitsCore() {
  {
    var eligible = [PLAN_STATUS.ACTIVE, PLAN_STATUS.AT_RISK, PLAN_STATUS.PAUSED, PLAN_STATUS.REFUND_REQUESTED, PLAN_STATUS.PAUSE_REQUESTED, PLAN_STATUS.COMPLETED];
    var byPlan = groupTxnsByPlan(readSheet('Transactions'));
    var users = {};
    readSheet('Users').forEach(function (u) { users[u.UserID] = u; });
    var globalRate = getGlobalProfitRate(), updated = 0;
    readSheet('Plans').forEach(function (plan) {
      if (eligible.indexOf(plan.Status) === -1) return;
      var before = Number(plan.ProfitAccrued || 0);
      var acc = syncPlanProfit(plan, byPlan[plan.PlanID] || [], getCustomerProfitRate(users[plan.CustomerID], globalRate).rate);
      if (acc.total_interest !== before) updated++;
    });
    PropertiesService.getScriptProperties().setProperty('PROFIT_LAST_SYNC_AT', new Date().toISOString());
    invalidateAdminReportCache(); // bonus totals just moved
    return { updated: updated };
  }
}

/** The existing daily trigger calls this name. */
function accrueAllBonuses() {
  try { syncAllPlanProfits(); } catch (e) { Logger.log('accrueAllBonuses failed: ' + e); }
}

/**
 * One-time v51 switch-over (idempotent, run by setupDatabase). v50 credited month-end profit straight into
 * AccruedSavingsBonus (and logged it in ProfitLogs). The daily ledger recomputes profit from the very first
 * deposit, so those credited amounts are removed from the bonus once to avoid paying twice.
 * Referral / streak bonuses are untouched.
 */
function migrateToDailyProfit() {
  var props = PropertiesService.getScriptProperties();
  if (props.getProperty('PROFIT_ENGINE') === PROFIT_ENGINE_ID) return;
  var legacy = {};
  try {
    readSheet('ProfitLogs').forEach(function (l) { legacy[l.PlanID] = (legacy[l.PlanID] || 0) + Number(l.Amount || 0); });
  } catch (e) { /* sheet missing: nothing to migrate */ }
  readSheet('Plans').forEach(function (plan) {
    var cut = legacy[plan.PlanID] || 0;
    if (cut > 0) updateRow('Plans', plan._row, { AccruedSavingsBonus: Math.max(round2(Number(plan.AccruedSavingsBonus || 0) - cut), 0), ProfitAccrued: 0 });
  });
  props.setProperty('PROFIT_ENGINE', PROFIT_ENGINE_ID);
  try { syncAllPlanProfitsCore(); } catch (e) { Logger.log('first daily sync failed: ' + e); }
}

/** Admin: set the default yearly profit % (used for every customer without a personal rate). */
function setProfitRate(token, percent) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    percent = Number(percent);
    if (isNaN(percent) || percent < 0 || percent > 100) return fail('মুনাফার হার ০ থেকে ১০০ এর মধ্যে দিন।');
    percent = round2(percent);
    PropertiesService.getScriptProperties().setProperty('PROFIT_ANNUAL_RATE', String(percent));
    syncAllPlanProfits();
    logAudit(session.UserID, 'PROFIT_RATE_SET', 'ডিফল্ট বার্ষিক হার ' + percent + '% (দিনভিত্তিক হিসাব)');
    return ok(getProfitSettings());
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin: set (or clear, with a blank value) ONE customer's personal yearly profit %. */
function setCustomerProfitRate(token, userId, percent) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var user = findOne('Users', function (u) { return u.UserID === userId && u.Role === ROLES.CUSTOMER; });
    if (!user) return fail('গ্রাহক খুঁজে পাওয়া যায়নি।');
    var clear = (percent === '' || percent === null || percent === undefined);
    var value = '';
    if (!clear) {
      value = Number(percent);
      if (isNaN(value) || value < 0 || value > 100) return fail('মুনাফার হার ০ থেকে ১০০ এর মধ্যে দিন।');
      value = round2(value);
    }
    updateRow('Users', user._row, { ProfitRatePercent: value });
    syncAllPlanProfits();
    logAudit(session.UserID, 'CUSTOMER_PROFIT_RATE_SET', userId + ' → ' + (clear ? 'ডিফল্ট হার' : value + '%'));
    return ok({ userId: userId, ratePercent: value, defaultPercent: getGlobalProfitRate() });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin: recompute and store everyone's profit right now. */
function runDailyProfitNow(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var r = syncAllPlanProfits();
    return ok({ updated: r.updated, settings: getProfitSettings() });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Public ledger query (any role; customers only for their own plan):
 * returns the exact output block — total_principal, total_interest, total_balance, breakdown.
 * calcDate is optional ('YYYY-MM-DD', default today in Dhaka).
 */
function getPlanProfitBreakdown(token, planId, calcDate) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    var plan = findOneBy('Plans', 'PlanID', planId);
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (session.Role === ROLES.CUSTOMER && plan.CustomerID !== session.UserID) return fail('এই প্ল্যানটি আপনার নয়।');
    assertManagerCanServe_(session, plan.CustomerID);   // v81
    if (calcDate && !/^\d{4}-\d{2}-\d{2}$/.test(String(calcDate))) return fail('তারিখ YYYY-MM-DD ফরম্যাটে দিন।');
    var user = findOneBy('Users', 'UserID', plan.CustomerID);
    var rows = findAllBy('Transactions', 'PlanID', planId);
    var r = getCustomerProfitRate(user);
    var acc = computeDailyAccrual(accrualTxnsFromRows(rows), r.rate, calcDate || undefined, parseMissedDays(plan.MissedDays));
    acc.rate_is_custom = r.custom;
    return ok(acc);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 13. CUSTOMER DASHBOARD
// ---------------------------------------------------------------------------

function getMyDashboard(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var plans = findAllBy('Plans', 'CustomerID', session.UserID);
    var allTxns = findAllBy('Transactions', 'CustomerID', session.UserID); // v72: this customer's rows only (every Transactions row carries its plan owner's CustomerID)

    var pendingConfirmations = allTxns
      .filter(function (t) { return t.CustomerID === session.UserID && t.CustomerConfirmed === 'Pending'; })
      .map(function (t) {
        var plan = plans.filter(function (p) { return p.PlanID === t.PlanID; })[0];
        return {
          txnId: t.TxnID,
          planName: plan ? plan.ItemOrGoalName : '',
          amount: Number(t.Amount),
          timestamp: t.Timestamp
        };
      });

    var dashUser = findOneBy('Users', 'UserID', session.UserID);
    var dashRate = getCustomerProfitRate(dashUser);
    var result = plans.map(function (p) {
      var live = livePlanProfit(p, allTxns.filter(function (t) { return t.PlanID === p.PlanID; }), dashRate.rate);
      var txns = allTxns
        .filter(function (t) { return t.PlanID === p.PlanID && t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected'; })
        .map(function (t) {
          return {
            amount: Number(t.Amount),
            method: t.PaymentMethod,
            txnType: t.TxnType,
            confirmed: t.CustomerConfirmed,
            timestamp: t.Timestamp
          };
        })
        .sort(function (a, b) { return new Date(b.timestamp) - new Date(a.timestamp); });

      var target = Number(p.TargetAmount);
      var accumulated = Number(p.AccumulatedSavings);
      var bonus = live.bonus_balance;
      return {
        planId: p.PlanID,
        categoryType: p.CategoryType,
        itemOrGoalName: p.ItemOrGoalName,
        targetAmount: target,
        accumulatedSavings: accumulated,
        accruedSavingsBonus: bonus,
        accruedProfit: live.total_interest,
        installmentAmount: Number(p.InstallmentAmount),
        savingFrequency: p.SavingFrequency,
        status: p.Status,
        startDate: p.StartDate,
        targetEndDate: p.TargetEndDate,
        missedIntervalCount: Number(p.MissedIntervalCount || 0),
        groupId: p.GroupID || '',
        seasonKey: p.SeasonKey || '',
        archived: !!p.ArchivedAt,
        progressPercent: Math.min(100, Math.round(((accumulated + bonus) / target) * 100)),
        transactions: txns
      };
    });

    // Upgrade 8: badge/streak/referral profile info for the dashboard header.
    var fullUser = findOneBy('Users', 'UserID', session.UserID);
    var profile = fullUser ? {
      badge: fullUser.Badge || '',
      streakCount: Number(fullUser.StreakCount || 0),
      referralCode: fullUser.ReferralCode || ''
    } : { badge: '', streakCount: 0, referralCode: '' };

    // Upgrade 15: self-reported bKash/Nagad payments still waiting on (or turned down by) a Manager/Admin
    var onlineClaims = allTxns
      .filter(function (t) { return t.CustomerID === session.UserID && (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected'); })
      .map(function (t) {
        var plan = plans.filter(function (p) { return p.PlanID === t.PlanID; })[0];
        return {
          txnId: t.TxnID,
          planName: plan ? plan.ItemOrGoalName : '',
          amount: Number(t.Amount),
          paymentMethod: t.PaymentMethod,
          trxIdReceipt: t.TrxID_Receipt,
          status: t.ClaimStatus,
          note: t.VerificationNote || '',
          paidToNumber: t.PaidToNumber || '',
          claimedAt: t.ClaimedAt || t.Timestamp
        };
      })
      .sort(function (a, b) { return new Date(b.claimedAt) - new Date(a.claimedAt); });

    var decidedSince = new Date().getTime() - 14 * 24 * 3600 * 1000;
    var decidedClaims = allTxns
      .filter(function (t) {
        return t.CustomerID === session.UserID && t.DecidedAt && (t.ClaimStatus === 'Approved' || t.ClaimStatus === 'Rejected') &&
               new Date(t.DecidedAt).getTime() >= decidedSince;
      })
      .map(function (t) {
        var plan = plans.filter(function (p) { return p.PlanID === t.PlanID; })[0];
        return { txnId: t.TxnID, planId: t.PlanID, planName: plan ? plan.ItemOrGoalName : '', amount: Number(t.Amount),
                 paymentMethod: t.PaymentMethod, trxIdReceipt: t.TrxID_Receipt, status: t.ClaimStatus,
                 note: t.VerificationNote || '', decidedAt: t.DecidedAt };
      })
      .sort(function (a, b) { return new Date(b.decidedAt) - new Date(a.decidedAt); });

    var myProfileRow = findOneBy('CustomerProfiles', 'UserID', session.UserID);
    var withdrawalRequests = findAllBy('WithdrawalRequests', 'CustomerID', session.UserID)
      .map(function (r) {
        return { requestId: r.RequestID, planId: r.PlanID, amount: Number(r.Amount), paymentMethod: r.PaymentMethod, reason: r.Reason || '',
                 status: r.Status, requestedAt: r.RequestedAt, decidedAt: r.DecidedAt || '', adminNote: r.AdminNote || '' };
      })
      .sort(function (a, b) { return new Date(b.requestedAt) - new Date(a.requestedAt); })
      .slice(0, 50);
    return ok({ user: session, photoUrl: myProfileRow ? (myProfileRow.PhotoUrl || '') : '', profile: profile, plans: result, pendingConfirmations: pendingConfirmations, onlineClaims: onlineClaims, decidedClaims: decidedClaims, withdrawalRequests: withdrawalRequests, profitRatePercent: dashRate.rate, profitRateIsCustom: dashRate.custom, profitCalcDate: profitDay(new Date()) });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 14. EMERGENCY REFUND / PAUSE — Upgrade 3
// ---------------------------------------------------------------------------

/**
 * Customer requests either a full penalty-free refund or a temporary pause.
 * Both go into an Admin approval queue. actionType must be "Refund" or "Pause".
 * Allowed from Active or AtRisk (Upgrade 6) plans.
 */
function requestPlanAction(token, planId, actionType, reason) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    if (actionType !== 'Refund' && actionType !== 'Pause') {
      return fail('সঠিক আবেদনের ধরন দিন (Refund/Pause)।');
    }
    var plan = findOne('Plans', function (p) { return p.PlanID === planId && p.CustomerID === session.UserID; });
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (plan.Status !== PLAN_STATUS.ACTIVE && plan.Status !== PLAN_STATUS.AT_RISK) {
      return fail('শুধুমাত্র সক্রিয় প্ল্যানের জন্য আবেদন করা যাবে।');
    }

    var newStatus = actionType === 'Refund' ? PLAN_STATUS.REFUND_REQUESTED : PLAN_STATUS.PAUSE_REQUESTED;
    updateRow('Plans', plan._row, {
      PreviousStatus: plan.Status,
      PendingAction: actionType,
      PendingActionReason: cleanText(reason),
      Status: newStatus
    });
    logAudit(session.UserID, actionType === 'Refund' ? 'REFUND_REQUESTED' : 'PAUSE_REQUESTED', planId + ' — ' + (reason || ''));
    return ok('আপনার আবেদন জমা হয়েছে। অ্যাডমিনের অনুমোদনের অপেক্ষায় আছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Customer resumes a plan that was already Paused — including a plan the
 * system auto-paused after 5 missed installments (Upgrade 6). Self-service,
 * no approval needed and never any penalty.
 */
function resumePlan(token, planId) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var plan = findOne('Plans', function (p) { return p.PlanID === planId && p.CustomerID === session.UserID; });
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (plan.Status !== PLAN_STATUS.PAUSED) return fail('শুধুমাত্র বন্ধ থাকা প্ল্যান আবার শুরু করা যায়।');

    updateRow('Plans', plan._row, {
      Status: PLAN_STATUS.ACTIVE,
      PreviousStatus: '',
      MissedIntervalCount: 0,
      LastDepositDate: new Date().toISOString(),
      MissedCheckedDay: dayFromNumber(dayNumber(profitDay(new Date())) - 1) // v56: days while paused are never counted as missed
    });
    logAudit(session.UserID, 'PLAN_RESUMED', planId);
    return ok('আপনার প্ল্যান আবার সক্রিয় করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin view of every plan waiting on a Refund or Pause approval.
 */
function getPendingPlanActions(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var plans = findAll('Plans', function (p) {
      return p.Status === PLAN_STATUS.REFUND_REQUESTED || p.Status === PLAN_STATUS.PAUSE_REQUESTED;
    });
    var users = readSheet('Users');
    var result = plans.map(function (p) {
      var customer = users.filter(function (u) { return u.UserID === p.CustomerID; })[0];
      return {
        planId: p.PlanID,
        itemOrGoalName: p.ItemOrGoalName,
        accumulatedSavings: Number(p.AccumulatedSavings),
        accruedSavingsBonus: Number(p.AccruedSavingsBonus || 0),
        pendingAction: p.PendingAction,
        pendingActionReason: p.PendingActionReason,
        customerId: customer ? customer.UserID : '',
        customerName: customer ? customer.Name : '',
        customerPhone: customer ? customer.Phone : ''
      };
    });
    return ok(result);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Partial withdrawal while a plan is still running. Manager/Admin records the money
 * the customer takes out.
 *  - Savings drop by the amount; the plan stays open.
 *  - v51 daily ledger: profit already earned stays; the withdrawn money stops earning from tomorrow
 *    (no profit for the withdrawal day). No proportional bonus cut any more.
 *  - Written as a NEGATIVE 'Withdrawal' transaction so the passbook ledger stays exact.
 */
function logWithdrawal(token, planId, amount, paymentMethod) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);

    amount = Math.round(Number(amount));
    paymentMethod = paymentMethod || 'Cash';
    if (['Cash', 'bKash', 'Nagad'].indexOf(paymentMethod) === -1) return fail('ভুল পেমেন্ট মাধ্যম।');
    if (!planId || !amount || amount <= 0) return fail('প্ল্যান ও সঠিক উত্তোলনের পরিমাণ দিন।');

    waitLockFresh(lock, 30000);

    var plan = findOneBy('Plans', 'PlanID', planId);
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    assertManagerCanServe_(session, plan.CustomerID);   // v81: শুধু নিজের শাখার গ্রাহক
    guardManagerDayOpen_(session, dhakaDateStr(new Date()), false);   // v83
    return applyWithdrawalCore(plan, amount, paymentMethod, session.UserID, 'WITHDRAWAL_LOGGED');
  } catch (err) {
    Logger.log('Error in logWithdrawal: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * The ONE place a partial withdrawal touches the books (used by the Manager/Admin
 * direct entry AND by an approved customer request). MUST be called while holding the script lock.
 * Re-reads nothing: pass the freshly-read plan row.
 * Returns ok({newBalance,newBonus,bonusCut,totalBalance,txnId}) or fail(...).
 */
function applyWithdrawalCore(plan, amount, paymentMethod, actorUserId, auditAction) {
  var allowed = [PLAN_STATUS.ACTIVE, PLAN_STATUS.AT_RISK, PLAN_STATUS.PAUSED];
  if (allowed.indexOf(plan.Status) === -1) {
    return fail('এই প্ল্যান থেকে এখন টাকা উত্তোলন করা যাবে না (শুধু চলমান বা সাময়িক বন্ধ প্ল্যান থেকে করা যায়)।');
  }

  var balance = Math.round(Number(plan.AccumulatedSavings || 0));
  if (amount > balance) return fail('জমার চেয়ে বেশি উত্তোলন করা যাবে না। বর্তমান জমা: ৳' + balance);

  var nowIso = new Date().toISOString();
  // Daily ledger: profit up to today is settled first; a withdrawal made today earns/costs nothing today
  // (elapsed_days = 0) and simply stops the withdrawn money from earning from tomorrow on.
  syncPlanProfitFresh(plan);
  var bonus = Number(plan.AccruedSavingsBonus || 0);
  var newBalance = balance - amount;

  var txnId = generateId('TXN');
  appendRow('Transactions', {
    TxnID: txnId,
    PlanID: plan.PlanID,
    CustomerID: plan.CustomerID,
    Amount: -amount,
    PaymentMethod: paymentMethod,
    TrxID_Receipt: '',
    VerifiedByManagerID: actorUserId,
    CustomerConfirmed: 'Yes',
    TxnType: 'Withdrawal',
    Timestamp: nowIso,
    SettledInSettlementID: '',
    ClientRefID: '',
    SyncedAt: nowIso,
    ClaimStatus: '',
    ClaimedAt: '',
    VerificationNote: ''
  });
  updateRow('Plans', plan._row, { AccumulatedSavings: newBalance });
  plan.AccumulatedSavings = newBalance;
  syncPlanProfitFresh(plan);
  var newBonus = Number(plan.AccruedSavingsBonus || 0);

  var customer = findOneBy('Users', 'UserID', plan.CustomerID);
  if (customer) {
    logSms(customer.Phone, 'AmarSonchoy: আপনার "' + plan.ItemOrGoalName + '" প্ল্যান থেকে ৳' + amount +
      ' উত্তোলন হয়েছে। বর্তমান জমা ৳' + newBalance + ', অর্জিত মুনাফা ৳' + newBonus + '।');
  }
  logAudit(actorUserId, auditAction || 'WITHDRAWAL_LOGGED', 'প্ল্যান ' + plan.PlanID + ' — ৳' + amount + ' উত্তোলন (' + paymentMethod +
    '), জমা ' + balance + '→' + newBalance + ', মুনাফা/বোনাস ' + bonus + '→' + newBonus);

  return ok({ newBalance: newBalance, newBonus: newBonus, bonusCut: 0, totalBalance: round2(newBalance + newBonus), txnId: txnId });
}

// ---------------------------------------------------------------------------
// 14b. CUSTOMER-REQUESTED PARTIAL WITHDRAWAL — Upgrade 27
//   Customer applies -> Admin approves/rejects. NOTHING moves until approval; approval runs the
//   very same applyWithdrawalCore() as the Manager/Admin direct entry, so savings, the
//   proportional bonus cut and the passbook ledger can never disagree.
// ---------------------------------------------------------------------------

function requestWithdrawal(token, planId, amount, paymentMethod, reason) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    amount = Math.round(Number(amount));
    paymentMethod = paymentMethod || 'Cash';
    if (['Cash', 'bKash', 'Nagad'].indexOf(paymentMethod) === -1) return fail('ভুল পেমেন্ট মাধ্যম।');
    if (!planId || !amount || amount <= 0) return fail('সঠিক উত্তোলনের পরিমাণ দিন।');

    waitLockFresh(lock, 30000);

    var plan = findOne('Plans', function (p) { return p.PlanID === planId && p.CustomerID === session.UserID; });
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    var allowed = [PLAN_STATUS.ACTIVE, PLAN_STATUS.AT_RISK, PLAN_STATUS.PAUSED];
    if (allowed.indexOf(plan.Status) === -1) return fail('এই প্ল্যান থেকে এখন উত্তোলনের আবেদন করা যাবে না।');

    var already = findOne('WithdrawalRequests', function (r) { return r.PlanID === planId && r.Status === 'Pending'; });
    if (already) return fail('এই প্ল্যানে আগের একটি উত্তোলনের আবেদন এখনো অপেক্ষায় আছে। সেটি বাতিল করুন অথবা সিদ্ধান্তের অপেক্ষা করুন।');

    var balance = Math.round(Number(plan.AccumulatedSavings || 0));
    if (balance <= 0) return fail('এই প্ল্যানে উত্তোলনের মতো জমা নেই।');
    if (amount >= balance) {
      return fail('পুরো ৳' + balance + ' তুলতে চাইলে "রিফান্ড আবেদন" ব্যবহার করুন। আংশিক উত্তোলনে জমার চেয়ে কম টাকা দিন।');
    }

    var requestId = generateId('WDR');
    appendRow('WithdrawalRequests', {
      RequestID: requestId,
      PlanID: planId,
      CustomerID: session.UserID,
      Amount: amount,
      PaymentMethod: paymentMethod,
      Reason: cleanText(reason),
      Status: 'Pending',
      RequestedAt: new Date().toISOString(),
      DecidedAt: '',
      DecidedByUserID: '',
      AdminNote: '',
      TxnID: ''
    });
    logAudit(session.UserID, 'WITHDRAWAL_REQUESTED', planId + ' — ৳' + amount + ' (' + paymentMethod + ') ' + (reason || ''));
    return ok('আপনার উত্তোলনের আবেদন জমা হয়েছে। অ্যাডমিনের অনুমোদনের পর টাকা পাবেন।');
  } catch (err) {
    Logger.log('Error in requestWithdrawal: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Customer withdraws their own still-pending request. */
function cancelWithdrawalRequest(token, requestId) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    waitLockFresh(lock, 30000);
    var req = findOne('WithdrawalRequests', function (r) { return r.RequestID === requestId && r.CustomerID === session.UserID; });
    if (!req) return fail('আবেদন খুঁজে পাওয়া যায়নি।');
    if (req.Status !== 'Pending') return fail('এই আবেদনের সিদ্ধান্ত ইতিমধ্যে হয়ে গেছে।');
    updateRow('WithdrawalRequests', req._row, { Status: 'Cancelled', DecidedAt: new Date().toISOString(), AdminNote: 'গ্রাহক নিজে বাতিল করেছেন' });
    logAudit(session.UserID, 'WITHDRAWAL_REQUEST_CANCELLED', requestId);
    return ok('আবেদন বাতিল করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Admin queue: every pending partial-withdrawal request, with the numbers needed to decide. */
function getPendingWithdrawalRequests(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var reqs = findAll('WithdrawalRequests', function (r) { return r.Status === 'Pending'; });
    var nowIso = new Date().toISOString();
    var rows = reqs.map(function (r) {
      var plan = findOneBy('Plans', 'PlanID', r.PlanID);
      var customer = findOneBy('Users', 'UserID', r.CustomerID);
      var balance = plan ? Math.round(Number(plan.AccumulatedSavings || 0)) : 0;
      var bonus = 0;
      if (plan) {
        var pUser = findOneBy('Users', 'UserID', plan.CustomerID);
        var pRows = findAllBy('Transactions', 'PlanID', plan.PlanID);
        bonus = livePlanProfit(plan, pRows, getCustomerProfitRate(pUser).rate).bonus_balance;
      }
      var amount = Number(r.Amount);
      var newBalance = balance - amount;
      var newBonus = bonus; // no cut: earned profit stays
      return {
        requestId: r.RequestID,
        planId: r.PlanID,
        itemOrGoalName: plan ? plan.ItemOrGoalName : '',
        planStatus: plan ? plan.Status : '',
        customerId: customer ? customer.UserID : '',
        customerName: customer ? customer.Name : '',
        customerPhone: customer ? customer.Phone : '',
        amount: amount,
        paymentMethod: r.PaymentMethod,
        reason: r.Reason || '',
        requestedAt: r.RequestedAt,
        balance: balance,
        bonus: bonus,
        newBalance: newBalance,
        newBonus: newBonus,
        bonusCut: 0
      };
    }).sort(function (a, b) { return new Date(a.requestedAt) - new Date(b.requestedAt); });
    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin approves (money is booked right now) or rejects a pending partial-withdrawal request. */
function decideWithdrawalRequest(token, requestId, approve, adminNote) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);

    var req = findOneBy('WithdrawalRequests', 'RequestID', requestId);
    if (!req) return fail('আবেদন খুঁজে পাওয়া যায়নি।');
    if (req.Status !== 'Pending') return fail('এই আবেদনের সিদ্ধান্ত ইতিমধ্যে হয়ে গেছে।');
    var plan = findOneBy('Plans', 'PlanID', req.PlanID);
    var customer = findOneBy('Users', 'UserID', req.CustomerID);
    var nowIso = new Date().toISOString();
    adminNote = cleanText(adminNote);

    if (!approve) {
      updateRow('WithdrawalRequests', req._row, { Status: 'Rejected', DecidedAt: nowIso, DecidedByUserID: session.UserID, AdminNote: adminNote });
      if (customer) logSms(customer.Phone, 'AmarSonchoy: আপনার ৳' + req.Amount + ' উত্তোলনের আবেদনটি গ্রহণ করা হয়নি।' + (adminNote ? ' কারণ: ' + adminNote : ''));
      logAudit(session.UserID, 'WITHDRAWAL_REQUEST_REJECTED', requestId + ' — ' + adminNote);
      return ok('আবেদনটি বাতিল করা হয়েছে।');
    }

    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    var result = applyWithdrawalCore(plan, Math.round(Number(req.Amount)), req.PaymentMethod, session.UserID, 'WITHDRAWAL_REQUEST_APPROVED');
    if (!result.ok) return result; // e.g. balance dropped or plan status changed since the request — Admin can reject it instead
    updateRow('WithdrawalRequests', req._row, { Status: 'Approved', DecidedAt: nowIso, DecidedByUserID: session.UserID, AdminNote: adminNote, TxnID: result.data.txnId });
    return ok(result.data);
  } catch (err) {
    Logger.log('Error in decideWithdrawalRequest: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** A full refund closes the plan, so any partial-withdrawal request still waiting on it is cancelled. Call while holding the lock. */
function cancelPendingWithdrawalsForPlan(planId, note) {
  try {
    findAll('WithdrawalRequests', function (r) { return r.PlanID === planId && r.Status === 'Pending'; }).forEach(function (r) {
      updateRow('WithdrawalRequests', r._row, { Status: 'Cancelled', DecidedAt: new Date().toISOString(), AdminNote: note || '' });
    });
  } catch (e) { Logger.log('cancelPendingWithdrawalsForPlan failed: ' + e); }
}

/**
 * Admin approves or rejects a pending Refund/Pause request.
 * Approved refunds write a negative Transaction row (including any accrued
 * bonus, since that is the customer's earned money) so the ledger stays accurate.
 */
function approvePlanAction(token, planId, approve, adminNote) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);

    var plan = findOneBy('Plans', 'PlanID', planId);
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (!plan.PendingAction) return fail('এই প্ল্যানে কোনো অপেক্ষমাণ আবেদন নেই।');

    if (!approve) {
      updateRow('Plans', plan._row, {
        Status: plan.PreviousStatus || PLAN_STATUS.ACTIVE,
        PendingAction: '',
        PendingActionReason: ''
      });
      logAudit(session.UserID, 'PLAN_ACTION_REJECTED', planId + ' — ' + (adminNote || ''));
      return ok('আবেদনটি বাতিল করা হয়েছে।');
    }

    if (plan.PendingAction === 'Refund') {
      syncPlanProfitFresh(plan); // bring the daily profit up to today before paying out
      var refundAmount = Math.round(Number(plan.AccumulatedSavings) + Number(plan.AccruedSavingsBonus || 0));
      appendRow('Transactions', {
        TxnID: generateId('TXN'),
        PlanID: planId,
        CustomerID: plan.CustomerID,
        Amount: -refundAmount,
        PaymentMethod: 'Refund',
        TrxID_Receipt: '',
        VerifiedByManagerID: session.UserID,
        CustomerConfirmed: 'Yes',
        TxnType: 'Refund',
        Timestamp: new Date().toISOString(),
        SettledInSettlementID: ''
      });
      updateRow('Plans', plan._row, {
        Status: PLAN_STATUS.REFUNDED,
        PendingAction: '',
        PendingActionReason: ''
      });
      cancelPendingWithdrawalsForPlan(planId, 'প্ল্যানের সম্পূর্ণ ফেরত অনুমোদিত হয়েছে');
      var customer = findOneBy('Users', 'UserID', plan.CustomerID);
      if (customer) {
        logSms(customer.Phone, 'AmarSonchoy: আপনার "' + plan.ItemOrGoalName + '" প্ল্যানের ' + refundAmount + ' টাকা (বোনাসসহ) ফেরত অনুমোদিত হয়েছে।');
      }
      logAudit(session.UserID, 'REFUND_APPROVED', planId + ' — ' + refundAmount + ' টাকা');
      return ok('রিফান্ড অনুমোদন করা হয়েছে ও লেনদেনে লেখা হয়েছে।');
    }

    if (plan.PendingAction === 'Pause') {
      updateRow('Plans', plan._row, {
        Status: PLAN_STATUS.PAUSED,
        PendingAction: '',
        PendingActionReason: ''
      });
      logAudit(session.UserID, 'PAUSE_APPROVED', planId);
      return ok('প্ল্যান সাময়িক বন্ধ অনুমোদন করা হয়েছে।');
    }

    return fail('অজানা আবেদনের ধরন।');
  } catch (err) {
    Logger.log('Error in approvePlanAction: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// 15. MANAGER FUNCTIONS
// ---------------------------------------------------------------------------

function getAllCustomers(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var scope = managerScope_(session);   // v81
    var customers = findAllBy('Users', 'Role', ROLES.CUSTOMER).filter(function (u) { return inManagerScope_(scope, u); });
    var photos = getCustomerPhotoMap();
    customers.forEach(function (c) { delete c.PIN; delete c._row; c.PhotoUrl = photos[c.UserID] || ''; });
    return ok(customers);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function searchCustomer(token, phone) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    phone = String(phone || '').trim();
    var customer = findOne('Users', function (u) {
      return u.Phone === phone && u.Role === ROLES.CUSTOMER;
    });
    if (!customer || !inManagerScope_(managerScope_(session), customer)) return fail('এই নম্বরে আপনার শাখায় কোনো গ্রাহক পাওয়া যায়নি।');   // v81
    return ok(customerSearchResult(customer));
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** The {customer, plans} block the Manager screen shows (PIN and sheet row never leave the server). Shared by phone search and QR scan. */
function customerSearchResult(customer) {
  delete customer.PIN;
  delete customer._row;
  var searchedProfile = findOneBy('CustomerProfiles', 'UserID', customer.UserID);
  customer.PhotoUrl = searchedProfile ? (searchedProfile.PhotoUrl || '') : '';
  var plans = findAllBy('Plans', 'CustomerID', customer.UserID);
  return { customer: customer, plans: plans };
}

// ---------------------------------------------------------------------------
// QR CUSTOMER CARD (v52) — customer shows a QR, Manager scans it and lands straight on that customer's payment entry.
// The QR holds only  AS1.<UserID>.<signature>  — never a phone number or PIN. The signature is an HMAC with a secret
// that lives in Script Properties, so nobody can invent a valid code for another customer. A QR only ever opens the
// customer's screen for a signed-in Manager/Admin; it can't move money by itself.
// ---------------------------------------------------------------------------
function qrSecret() {
  var props = PropertiesService.getScriptProperties();
  var secret = props.getProperty('QR_SECRET');
  if (!secret) {
    secret = Utilities.getUuid() + Utilities.getUuid();
    props.setProperty('QR_SECRET', secret);
  }
  return secret;
}

function qrSignature(userId) {
  var bytes = Utilities.computeHmacSha256Signature('QR1|' + userId, qrSecret());
  return bytes.slice(0, 8).map(function (b) { var v = (b < 0 ? b + 256 : b).toString(16); return v.length < 2 ? '0' + v : v; }).join('');
}

function makeQrPayload(userId) { return 'AS1.' + userId + '.' + qrSignature(userId); }

/** Returns the userId if the scanned text is a genuine card code, otherwise ''. Constant-time signature compare. */
function parseQrPayload(text) {
  text = String(text || '').trim();
  if (text.length > 120 || text.indexOf('AS1.') !== 0) return '';
  var rest = text.substring(4), cut = rest.lastIndexOf('.');
  if (cut < 1) return '';
  var userId = rest.substring(0, cut), sig = rest.substring(cut + 1);
  var expected = qrSignature(userId);
  if (sig.length !== expected.length) return '';
  var diff = 0;
  for (var i = 0; i < sig.length; i++) diff |= sig.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0 ? userId : '';
}

/** Customer: the code to draw as a QR on their phone. */
function getMyQrCard(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var me = findOneBy('Users', 'UserID', session.UserID);
    if (!me) return fail('অ্যাকাউন্ট খুঁজে পাওয়া যায়নি।');
    return ok({ payload: makeQrPayload(me.UserID), name: me.Name, phone: me.Phone });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Manager/Admin: scanned QR text -> the same customer + plans block as the phone search. */
function lookupCustomerByQr(token, payload) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var userId = parseQrPayload(payload);
    if (!userId) return fail('এই QR কোডটি সঠিক গ্রাহক কার্ডের নয়।');
    var customer = findOne('Users', function (u) { return u.UserID === userId && u.Role === ROLES.CUSTOMER; });
    if (!customer) return fail('এই কার্ডের গ্রাহক খুঁজে পাওয়া যায়নি।');
    if (!inManagerScope_(managerScope_(session), customer)) return fail('এই গ্রাহক আপনার শাখা/গ্রামের নন।');   // v81
    return ok(customerSearchResult(customer));
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Manager onboarding a new, possibly unbanked walk-in customer.
 * Reuses the same validation and PIN rules as self-registration.
 */
function managerRegisterCustomer(token, name, phone, pin, termsAccepted, branch) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    name = cleanText(name);
    phone = String(phone || '').trim();
    pin = String(pin || '').trim();

    if (!name) return fail('গ্রাহকের নাম লিখুন।');
    var validation = validatePhoneAndPin(phone, pin);
    if (!validation.ok) return validation;
    if (!isTermsAccepted(termsAccepted)) return fail('গ্রাহকের শর্তাবলীতে সম্মতির ঘরে টিক দিন।');

    // No branch chosen → the customer joins the manager's own branch.
    var creator = findOneBy('Users', 'UserID', session.UserID);
    var customerBranch = normalizeBranch((session.Role === ROLES.MANAGER ? '' : branch) || (creator && creator.Branch) || '', true);   // v81: ম্যানেজার শুধু নিজের শাখায় যোগ করে
    if (customerBranch === null) return fail('শাখা সঠিক নয়।');

    var existing = findOneBy('Users', 'Phone', phone);
    if (existing) return fail('এই মোবাইল নম্বর দিয়ে আগে থেকেই একটি অ্যাকাউন্ট আছে।');

    var newUser = {
      UserID: generateId('USR'),
      Name: name,
      Phone: phone,
      PIN: pin,
      Role: ROLES.CUSTOMER,
      Status: 'Active',
      FailedLoginAttempts: 0,
      LockedUntil: '',
      CreatedAt: new Date().toISOString(),
      Badge: '',
      StreakCount: 0,
      ReferralCode: generateUniqueReferralCode(phone),
      ReferredByUserID: '',
      ReferralBonusAwarded: 'No',
      Branch: customerBranch,
      TermsAcceptedAt: new Date().toISOString()
    };
    appendRow('Users', newUser);
    logAudit(session.UserID, 'CUSTOMER_ONBOARDED', name + ' (' + phone + ', শাখা: ' + customerBranch + ', শর্তাবলীতে সম্মত)');
    syncCustomersSheet();
    return ok({ UserID: newUser.UserID, Name: newUser.Name, Phone: newUser.Phone });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function getTodaysCollections(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var todayStr = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');
    var txns = findAll('Transactions', function (t) {
      var txnDate = Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'yyyy-MM-dd');
      var matchesManager = session.Role === ROLES.ADMIN || t.VerifiedByManagerID === session.UserID;
      return txnDate === todayStr && matchesManager && t.TxnType !== 'Refund' && t.TxnType !== 'Withdrawal';
    });
    var total = txns.reduce(function (sum, t) { return sum + Number(t.Amount); }, 0);
    return ok({ transactions: txns, total: total, count: txns.length });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * "আজকের কালেকশন শেয়ার": everything the manager's one-tap end-of-day summary
 * (WhatsApp text / printable PDF) needs, in one call — each deposit with the
 * customer + plan name, per-method totals, and today's cash-settlement status.
 * Admin sees all managers' deposits; a Manager sees only their own.
 */
function getDailyCollectionReport(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var todayStr = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');
    var txns = findAll('Transactions', function (t) {
      var txnDate = Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'yyyy-MM-dd');
      var matchesManager = session.Role === ROLES.ADMIN || t.VerifiedByManagerID === session.UserID;
      return txnDate === todayStr && matchesManager && t.TxnType === 'Deposit';
    });
    txns.sort(function (a, b) { return new Date(a.Timestamp) - new Date(b.Timestamp); });

    var usersById = {};
    readSheet('Users').forEach(function (u) { usersById[u.UserID] = u; });
    var plansById = {};
    readSheet('Plans').forEach(function (p) { plansById[p.PlanID] = p; });

    var byMethod = {};
    var total = 0;
    var rows = txns.map(function (t) {
      var amount = Number(t.Amount) || 0;
      var method = t.PaymentMethod || 'Cash';
      byMethod[method] = (byMethod[method] || 0) + amount;
      total += amount;
      var customer = usersById[t.CustomerID];
      var plan = plansById[t.PlanID];
      return {
        time: Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'hh:mm a'),
        customerName: customer ? customer.Name : '—',
        planName: plan ? plan.ItemOrGoalName : '',
        method: method,
        amount: amount
      };
    });

    var manager = usersById[session.UserID];
    var settlement = null;
    if (session.Role === ROLES.MANAGER) {
      var s = findOne('ManagerCashSettlements', function (x) {
        return x.ManagerID === session.UserID && x.SettlementDate === todayStr && x.Status !== 'Rejected';
      });
      if (s) settlement = { declared: Number(s.DeclaredCashAmount), system: Number(s.SystemLoggedCashAmount),
                            discrepancy: Number(s.Discrepancy), status: s.Status };
    }

    return ok({
      dateStr: todayStr,
      managerName: manager ? manager.Name : '',
      branch: manager ? normalizeBranch(manager.Branch) : '',
      isAdminView: session.Role === ROLES.ADMIN,
      rows: rows,
      count: rows.length,
      total: total,
      byMethod: byMethod,
      settlement: settlement
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 16. ADMIN FUNCTIONS
// ---------------------------------------------------------------------------

function getAdminStatsCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var users = readSheet('Users');
    var plans = readSheet('Plans');
    var txns = readSheet('Transactions');

    var totalCustomers = users.filter(function (u) { return u.Role === ROLES.CUSTOMER; }).length;
    var totalManagers = users.filter(function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; }).length;
    var activePlans = plans.filter(function (p) { return p.Status === PLAN_STATUS.ACTIVE; }).length;
    var atRiskPlans = plans.filter(function (p) { return p.Status === PLAN_STATUS.AT_RISK; }).length;
    var completedPlans = plans.filter(function (p) { return p.Status === PLAN_STATUS.COMPLETED; }).length;
    var totalCollected = txns
      .filter(function (t) { return t.TxnType !== 'Refund' && t.TxnType !== 'Withdrawal' && t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected'; })
      .reduce(function (sum, t) { return sum + Number(t.Amount || 0); }, 0);
    var pendingOnlineClaims = txns.filter(function (t) { return t.ClaimStatus === 'PendingVerification'; }).length;
    var totalBonusAccrued = plans.reduce(function (sum, p) { return sum + Number(p.AccruedSavingsBonus || 0); }, 0);
    var pendingSettlements = readSheet('ManagerCashSettlements').filter(function (s) { return s.Status === 'Pending'; }).length;

    // Upgrade 14: finished plans that are old enough to archive / already archived
    var archiveCutoff = new Date().getTime() - CONFIG.ARCHIVE_AFTER_DAYS * DAY_MS;
    var archivableCount = plans.filter(function (p) {
      var ref = planClosedReferenceMs(p);
      return !p.ArchivedAt && isArchivableStatus(p.Status) && ref > 0 && ref <= archiveCutoff;
    }).length;
    var archivedCount = plans.filter(function (p) { return !!p.ArchivedAt; }).length;

    return ok({
      totalCustomers: totalCustomers,
      totalManagers: totalManagers,
      activePlans: activePlans,
      atRiskPlans: atRiskPlans,
      completedPlans: completedPlans,
      totalCollected: totalCollected,
      totalBonusAccrued: totalBonusAccrued,
      pendingSettlements: pendingSettlements,
      archivableCount: archivableCount,
      archivedCount: archivedCount,
      pendingOnlineClaims: pendingOnlineClaims
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// ADMIN REPORT CACHE (v53) — the heavy analytics below re-read whole sheets on every Admin page load.
// Their result is now kept for ONE HOUR in CacheService. The Admin role is checked BEFORE the cache is
// consulted, so a cached answer is never handed to anyone else. The cache is also cleared at once when
// something it depends on changes (profit rate, profitability costs, archiving, the daily profit job),
// or by the Admin's "এখনই হালনাগাদ" button. Answers too big for CacheService (100 KB) are simply not cached.
// ---------------------------------------------------------------------------
var ADMIN_REPORT_TTL_SECONDS = 3600;

function adminReportGeneration_() {
  return PropertiesService.getScriptProperties().getProperty('ADMIN_REPORT_GEN') || '0';
}

/** Throws away every cached admin report (they are rebuilt on next use). */
function invalidateAdminReportCache() {
  try { PropertiesService.getScriptProperties().setProperty('ADMIN_REPORT_GEN', String(new Date().getTime())); } catch (e) { /* cache is only an optimisation */ }
}

function cachedAdminReport_(name, token, args, compute) {
  try { requireRole(token, [ROLES.ADMIN]); } catch (err) { return fail(err.message.replace('AUTH: ', '')); }
  var cache = null, key = '';
  try {
    cache = CacheService.getScriptCache();
    key = 'ADMRPT_' + name + '_' + args.join('_') + '_' + adminReportGeneration_();
    var hit = cache.get(key);
    if (hit) {
      var parsed = JSON.parse(hit);
      parsed.cached = true;
      return parsed;
    }
  } catch (e) { cache = null; }
  var res = compute.apply(null, [token].concat(args));
  if (cache && res && res.ok) {
    res.cachedAt = new Date().toISOString();
    try {
      var json = JSON.stringify(res);
      if (Utilities.newBlob(json).getBytes().length < 95000) cache.put(key, json, ADMIN_REPORT_TTL_SECONDS);
    } catch (e) { /* too large or cache unavailable: just serve the fresh answer */ }
  }
  return res;
}

function getAdminStats(token) { return cachedAdminReport_('stats', token, [], getAdminStatsCompute_); }
function getCohortAnalysis(token) { return cachedAdminReport_('cohort', token, [], getCohortAnalysisCompute_); }
function getBranchComparisonStats(token) { return cachedAdminReport_('branch', token, [], getBranchComparisonStatsCompute_); }
function getMonthForecast(token) { return cachedAdminReport_('forecast', token, [], getMonthForecastCompute_); }
function getCollectionHeatmap(token, days) { return cachedAdminReport_('heatmap', token, [Math.max(28, Math.min(120, Number(days) || 90))], getCollectionHeatmapCompute_); }
function getFunnelData(token) { return cachedAdminReport_('funnel', token, [], getFunnelDataCompute_); }
function getProfitabilityEstimate(token) { return cachedAdminReport_('profitability', token, [], getProfitabilityEstimateCompute_); }
function getAdminChartData(token) { return cachedAdminReport_('chart', token, [], getAdminChartDataCompute_); }

/** Admin: drop the one-hour cache so the next dashboard load recalculates everything. */
function refreshAdminReports(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    invalidateAdminReportCache();
    return ok('হিসাব হালনাগাদ করা হবে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function getAllUsers(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var users = readSheet('Users');
    var photos = getCustomerPhotoMap();
    users.forEach(function (u) { delete u.PIN; delete u._row; u.PhotoUrl = photos[u.UserID] || ''; });
    return ok(users);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function updateUserStatus(token, userId, newStatus) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var user = findOneBy('Users', 'UserID', userId);
    if (!user) return fail('ইউজার খুঁজে পাওয়া যায়নি।');
    updateRow('Users', user._row, { Status: newStatus });
    logAudit(session.UserID, 'USER_STATUS_CHANGED', userId + ' → ' + newStatus);
    if (user.Role === ROLES.CUSTOMER) syncCustomersSheet();
    return ok('স্ট্যাটাস আপডেট হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// PIN RESET (controlled) — forgotten PIN. Admin → Manager/Customer, Manager → Customer only.
// The helper sees a one-time temporary PIN; the owner must replace it at first login.
// ---------------------------------------------------------------------------
var PIN_RESET_MAX_PER_TARGET_PER_DAY = 2;
var PIN_RESET_MAX_PER_MANAGER_PER_DAY = 15;

function isWeakPin_(pin) {
  return /^(\d)\1{3}$/.test(pin) || ['0123', '1234', '2345', '3456', '4567', '5678', '6789', '3210', '4321', '5432', '6543', '7654', '8765', '9876', '1122', '1212', '2580'].indexOf(pin) !== -1;
}

function generateTempPin_() {
  var pin;
  do { pin = ('000' + Math.floor(Math.random() * 10000)).slice(-4); } while (isWeakPin_(pin));
  return pin;
}

/** Signs the user out everywhere (cache + stored session copies). */
function revokeUserSessions_(userId) {
  var props = PropertiesService.getScriptProperties();
  var cache = CacheService.getScriptCache();
  var all = props.getProperties();
  Object.keys(all).forEach(function (key) {
    if (key.indexOf('SESSION_') !== 0 || key.indexOf('SESSION_EXPIRES_') === 0) return;
    try {
      if (JSON.parse(all[key]).UserID !== userId) return;
    } catch (e) { return; }
    var token = key.substring('SESSION_'.length);
    cache.remove(token);
    props.deleteProperty(key);
    props.deleteProperty('SESSION_EXPIRES_' + token);
  });
}

function resetUserPin(token, targetUserId, reason, identityVerified) {
  try {
    var session = requireRole(token, [ROLES.ADMIN, ROLES.MANAGER]);
    reason = cleanText(reason);
    if (identityVerified !== true) return fail('আগে গ্রাহকের পরিচয় যাচাই করে নিশ্চিত করুন।');
    if (reason.length < 5) return fail('রিসেটের কারণ লিখুন (অন্তত ৫ অক্ষর)।');

    var target = findOneBy('Users', 'UserID', targetUserId);
    if (!target) return fail('ইউজার খুঁজে পাওয়া যায়নি।');
    if (target.UserID === session.UserID) return fail('নিজের PIN এই পথে রিসেট করা যায় না।');
    if (target.Role === ROLES.ADMIN) return fail('অ্যাডমিনের PIN এই পথে রিসেট করা যায় না।');
    if (session.Role === ROLES.MANAGER && target.Role !== ROLES.CUSTOMER) return fail('ম্যানেজার শুধু গ্রাহকের PIN রিসেট করতে পারেন।');
    if (session.Role === ROLES.MANAGER) assertManagerCanServe_(session, target);   // v81
    if (target.Status !== 'Active') return fail('অ্যাকাউন্টটি সক্রিয় নেই, আগে সক্রিয় করুন।');
    if (!('MustChangePIN' in target)) return fail('ডাটাবেস হালনাগাদ হয়নি — Apps Script-এ setupDatabase একবার চালান।');

    var since = new Date().getTime() - 24 * 3600 * 1000;
    var recent = readSheet('AuditLogs').filter(function (l) {
      return l.Action === 'PIN_RESET' && new Date(l.Timestamp).getTime() >= since;
    });
    var forTarget = recent.filter(function (l) { return String(l.Details).indexOf(target.UserID + ' ') === 0; }).length;
    if (forTarget >= PIN_RESET_MAX_PER_TARGET_PER_DAY) return fail('এই অ্যাকাউন্টে আজ আর রিসেট করা যাবে না। অ্যাডমিনের সাথে যোগাযোগ করুন।');
    if (session.Role === ROLES.MANAGER) {
      var byActor = recent.filter(function (l) { return l.UserID === session.UserID; }).length;
      if (byActor >= PIN_RESET_MAX_PER_MANAGER_PER_DAY) return fail('আজকের রিসেটের সীমা শেষ। অ্যাডমিনের সাথে যোগাযোগ করুন।');
    }

    var tempPin = generateTempPin_();
    updateRow('Users', target._row, { PIN: tempPin, MustChangePIN: 'Yes', FailedLoginAttempts: 0, LockedUntil: '' });
    revokeUserSessions_(target.UserID);
    // The temporary PIN is never written to the log.
    logAudit(session.UserID, 'PIN_RESET', target.UserID + ' (' + target.Name + ', ' + target.Role + ') — কারণ: ' + reason);
    logSms(target.Phone, 'আপনার PIN রিসেট করা হয়েছে। আপনি না চেয়ে থাকলে এখনই অফিসে জানান।');
    return ok({ tempPin: tempPin, name: target.Name, phone: target.Phone });
  } catch (err) {
    Logger.log('Error in resetUserPin: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Own PIN change. Also the only call allowed while a temporary PIN is still active. */
function changeOwnPin(token, currentPin, newPin) {
  try {
    var session = getSession(token);
    if (!session) return fail('আপনার সেশনের মেয়াদ শেষ হয়ে গেছে, আবার লগইন করুন।');
    currentPin = String(currentPin || '').trim();
    newPin = String(newPin || '').trim();
    var user = findOneBy('Users', 'UserID', session.UserID);
    if (!user || user.Status !== 'Active') return fail('অ্যাকাউন্টটি সক্রিয় নেই।');
    if (!/^[0-9]{4}$/.test(newPin)) return fail('নতুন PIN অবশ্যই ৪ ডিজিটের হতে হবে।');
    if (isWeakPin_(newPin)) return fail('এই PIN সহজে অনুমান করা যায় (যেমন 1234, 1111)। অন্য PIN বেছে নিন।');
    if (newPin === currentPin) return fail('নতুন PIN আগেরটির থেকে আলাদা হতে হবে।');

    if (String(user.PIN) !== currentPin) {
      var attempts = Number(user.FailedLoginAttempts || 0) + 1;
      var upd = { FailedLoginAttempts: attempts };
      if (attempts >= CONFIG.MAX_FAILED_LOGINS) {
        upd.FailedLoginAttempts = 0;
        upd.LockedUntil = new Date(new Date().getTime() + CONFIG.LOCKOUT_MINUTES * 60000).toISOString();
        revokeUserSessions_(user.UserID);
      }
      updateRow('Users', user._row, upd);
      logAudit(user.UserID, 'LOGIN_FAILED', 'PIN বদলের সময় ভুল বর্তমান PIN');
      return fail('বর্তমান PIN ভুল।');
    }

    updateRow('Users', user._row, { PIN: newPin, MustChangePIN: '', FailedLoginAttempts: 0, LockedUntil: '' });
    revokeUserSessions_(user.UserID);
    logAudit(user.UserID, 'PIN_CHANGED', session.MustChangePin ? 'অস্থায়ী PIN বদলে নতুন PIN সেট' : 'নিজে PIN বদলেছেন');
    var fresh = findOneBy('Users', 'UserID', user.UserID);
    return ok({ token: createSession(fresh), user: { UserID: fresh.UserID, Name: fresh.Name, Phone: fresh.Phone, Role: fresh.Role } });
  } catch (err) {
    Logger.log('Error in changeOwnPin: ' + err);
    return fail('PIN বদলাতে সমস্যা হয়েছে, আবার চেষ্টা করুন।');
  }
}

function createManager(token, name, phone, pin, branch) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    name = cleanText(name);
    phone = String(phone || '').trim();
    pin = String(pin || '').trim();

    if (!name) return fail('নাম লিখুন।');
    var validation = validatePhoneAndPin(phone, pin);
    if (!validation.ok) return validation;
    var managerBranch = normalizeBranch(branch, true);
    if (managerBranch === null) return fail('শাখা সঠিক নয়।');

    var existing = findOneBy('Users', 'Phone', phone);
    if (existing) return fail('এই মোবাইল নম্বর দিয়ে আগে থেকেই একটি অ্যাকাউন্ট আছে।');

    appendRow('Users', {
      UserID: generateId('USR'),
      Name: name,
      Phone: phone,
      PIN: pin,
      Role: ROLES.MANAGER,
      Status: 'Active',
      FailedLoginAttempts: 0,
      LockedUntil: '',
      CreatedAt: new Date().toISOString(),
      Badge: '',
      StreakCount: 0,
      ReferralCode: generateUniqueReferralCode(phone),
      ReferredByUserID: '',
      ReferralBonusAwarded: 'No',
      Branch: managerBranch,
      TermsAcceptedAt: ''
    });
    logAudit(session.UserID, 'MANAGER_CREATED', name + ' (' + phone + ', শাখা: ' + managerBranch + ')');
    return ok('ম্যানেজার তৈরি হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}


// ---------------------------------------------------------------------------
// v80. REAL-TIME MONITORING FOR ADMINS
//      Transactions + security events in one live feed, with automatic alerts.
//      The browser polls this every ~20 seconds while the monitor page is open
//      (Apps Script cannot push), so nothing here changes any data.
// ---------------------------------------------------------------------------
var MONITOR_DEFAULT_LARGE_AMOUNT = 20000;   // ৳ — a single entry at/above this is flagged
var MONITOR_FEED_HOURS = 48;
var MONITOR_FEED_LIMIT = 80;

function getMonitorLargeAmount_() {
  var v = Number(PropertiesService.getScriptProperties().getProperty('MONITOR_LARGE_AMOUNT'));
  return v > 0 ? v : MONITOR_DEFAULT_LARGE_AMOUNT;
}

/** Admin-only. Sets the "large transaction" alert limit. */
function setMonitorThreshold(token, amount) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var n = Math.round(Number(amount));
    if (!(n >= 100)) return fail('সীমা কমপক্ষে ১০০ টাকা হতে হবে।');
    PropertiesService.getScriptProperties().setProperty('MONITOR_LARGE_AMOUNT', String(n));
    try { CacheService.getScriptCache().remove('MONITOR_FEED_V1'); } catch (e) { /* cache is optional */ }
    logAudit(session.UserID, 'MONITOR_SETTINGS_UPDATED', 'বড় লেনদেনের সীমা: ' + n + ' টাকা');
    return ok({ largeAmount: n });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin-only. Lifts a login lockout early (e.g. a real customer who forgot the PIN and was locked out). */
function unlockUserAccount(token, userId) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var user = findOneBy('Users', 'UserID', String(userId || ''));
    if (!user) return fail('ব্যবহারকারী পাওয়া যায়নি।');
    updateRow('Users', user._row, { FailedLoginAttempts: 0, LockedUntil: '' });
    logAudit(session.UserID, 'ACCOUNT_UNLOCKED', user.Name + ' (' + user.Phone + ') এর লগইন লক খোলা হয়েছে');
    try { CacheService.getScriptCache().remove('MONITOR_FEED_V1'); } catch (e) { /* cache is optional */ }
    return ok({ userId: user.UserID });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

var MONITOR_DANGER_ACTIONS = /^(DAY_REOPENED|LOGIN_LOCKED|LOGIN_BLOCKED|DEPOSIT_DISPUTED|PAYMENT_SETTINGS_UPDATED|PAYMENT_QR_UPLOADED|INITIAL_ADMIN_SETUP|PROFIT_RATE_SET|PROFITABILITY_SETTINGS_UPDATED)/;
var MONITOR_ACTION_LABELS = {
  LOGIN_FAILED: 'ভুল PIN দিয়ে লগইন চেষ্টা', LOGIN_LOCKED: 'অ্যাকাউন্ট লক হয়েছে', LOGIN_BLOCKED: 'লক অবস্থায় লগইন চেষ্টা',
  LOGIN_SUCCESS: 'সফল লগইন', PIN_RESET: 'PIN রিসেট', PIN_CHANGED: 'PIN পরিবর্তন', USER_STATUS_CHANGED: 'অ্যাকাউন্টের অবস্থা পরিবর্তন',
  USER_BRANCH_CHANGED: 'শাখা পরিবর্তন', MANAGER_CREATED: 'নতুন ম্যানেজার তৈরি', REFUND_APPROVED: 'রিফান্ড অনুমোদন',
  DEPOSIT_DISPUTED: 'গ্রাহক জমায় আপত্তি জানিয়েছেন', PROFIT_RATE_SET: 'মুনাফার হার পরিবর্তন', PAYMENT_SETTINGS_UPDATED: 'পেমেন্ট সেটিংস পরিবর্তন',
  PAYMENT_QR_UPLOADED: 'পেমেন্ট QR পরিবর্তন', INITIAL_ADMIN_SETUP: 'প্রাথমিক অ্যাডমিন সেটআপ', ACCOUNT_UNLOCKED: 'অ্যাকাউন্ট আনলক',
  BRANCH_ACCESS_DENIED: 'অন্য শাখার গ্রাহকে প্রবেশের চেষ্টা (বাধা দেওয়া হয়েছে)', DUPLICATE_TRXID_BLOCKED: 'একই TrxID আবার ব্যবহারের চেষ্টা (আটকানো হয়েছে)', DAY_CLOSED: 'দিনের হিসাব বন্ধ', DAY_REOPENED: 'বন্ধ দিন পুনরায় খোলা হয়েছে', LATE_ENTRY_AFTER_CLOSE: 'বন্ধ দিনে দেরিতে সিঙ্ক হওয়া এন্ট্রি', PROFITABILITY_SETTINGS_UPDATED: 'মুনাফা সেটিংস পরিবর্তন', MONITOR_SETTINGS_UPDATED: 'মনিটর সেটিংস পরিবর্তন'
};

/**
 * Admin-only. One call = everything the monitor screen shows:
 *   stats, automatic alerts (anomalies), an hourly activity series, currently locked accounts,
 *   and a unified newest-first feed of transactions + security events from the last 48 hours.
 * Cached for 10 seconds so several open monitors never hammer the sheets.
 */
function getRealtimeMonitor(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var cache = null, cached = null;
    try { cache = CacheService.getScriptCache(); cached = cache.get('MONITOR_FEED_V1'); } catch (e) { cache = null; }
    if (cached) { try { return ok(JSON.parse(cached)); } catch (e) { /* recompute */ } }

    var nowMs = new Date().getTime();
    var hourMs = 3600 * 1000;
    var sinceMs = nowMs - MONITOR_FEED_HOURS * hourMs;
    var largeAmount = getMonitorLargeAmount_();
    var todayStr = dhakaDateStr(new Date());

    var users = readSheet('Users'), usersById = {};
    users.forEach(function (u) { usersById[u.UserID] = u; });
    var plansById = {};
    readSheet('Plans').forEach(function (p) { plansById[p.PlanID] = p; });
    function who(id) { var u = usersById[id]; return u ? u.Name : (id || 'সিস্টেম'); }
    function whoFull(id) { var u = usersById[id]; return u ? (u.Name + ' (' + u.Phone + ')') : (id || 'সিস্টেম'); }
    function dhakaHour(ms) { return Number(Utilities.formatDate(new Date(ms), CONFIG.TIMEZONE, 'H')); }

    var events = [];
    var todayTxnCount = 0, todayDepositTotal = 0, todayCash = 0, todayOnline = 0, lastHourCount = 0, pendingClaims = 0;
    var hourly = []; for (var h = 23; h >= 0; h--) hourly.push({ startMs: nowMs - h * hourMs, total: 0, count: 0 });

    var byManager = {};      // manager -> timestamps of recent cash entries
    var dupMap = {};         // customer|plan|amount -> [timestamps]
    var alerts = [];
    var trxSeen = {};        // normalized TrxID -> active rows (finds duplicates that already exist in old data)

    readSheet('Transactions').forEach(function (t) {
      if (t.TrxID_Receipt && t.ClaimStatus !== 'Rejected') {
        var nt = normalizeTrxId_(t.TrxID_Receipt);
        if (nt.ok) (trxSeen[nt.id] = trxSeen[nt.id] || []).push({ ms: new Date(t.Timestamp).getTime() || 0 });
      }
      var tsMs = new Date(t.ClaimedAt && t.ClaimStatus === 'PendingVerification' ? t.ClaimedAt : t.Timestamp).getTime();
      if (!tsMs || isNaN(tsMs)) return;
      var amount = Number(t.Amount || 0);
      var absAmt = Math.abs(amount);
      var isOut = t.TxnType === 'Withdrawal' || t.TxnType === 'Refund' || amount < 0;
      var claimStatus = t.ClaimStatus || '';
      if (claimStatus === 'PendingVerification') pendingClaims++;
      var counted = claimStatus !== 'PendingVerification' && claimStatus !== 'Rejected';

      if (tsMs >= nowMs - 24 * hourMs && counted && !isOut) {
        var idx = Math.min(23, Math.floor((tsMs - (nowMs - 24 * hourMs)) / hourMs));
        hourly[idx].total += absAmt; hourly[idx].count++;
      }
      if (counted && !isOut && dhakaDateStr(new Date(tsMs)) === todayStr) {
        todayTxnCount++; todayDepositTotal += absAmt;
        if (t.PaymentMethod === 'Cash') todayCash += absAmt; else todayOnline += absAmt;
      }
      if (tsMs >= nowMs - hourMs && counted) lastHourCount++;
      if (tsMs < sinceMs) return;

      var severity = 'info', notes = [];
      if (absAmt >= largeAmount) { severity = 'warn'; notes.push('বড় অঙ্ক'); }
      if (isOut) { severity = 'warn'; notes.push(t.TxnType === 'Refund' ? 'রিফান্ড' : 'উত্তোলন'); }
      if (claimStatus === 'Rejected') { severity = 'warn'; notes.push('দাবি বাতিল'); }
      if (claimStatus === 'PendingVerification') notes.push('যাচাইয়ের অপেক্ষায়');
      if (t.CustomerConfirmed === 'No') { severity = 'danger'; notes.push('গ্রাহক আপত্তি জানিয়েছেন'); }
      if (t.GeoFlag && t.GeoFlag !== 'OK' && t.GeoFlag !== 'NoGps') { severity = severity === 'danger' ? 'danger' : 'warn'; notes.push('লোকেশন সন্দেহজনক'); }
      var hr = dhakaHour(tsMs);
      if (!isOut && counted && hr >= 0 && hr < 5) { if (severity === 'info') severity = 'warn'; notes.push('রাতের লেনদেন'); }

      var plan = plansById[t.PlanID];
      var method = t.PaymentMethod === 'Cash' ? 'নগদ' : (t.PaymentMethod || '');
      events.push({
        id: 'T' + t.TxnID, ts: new Date(tsMs).toISOString(), kind: 'txn', severity: severity,
        title: (isOut ? (t.TxnType === 'Refund' ? 'রিফান্ড' : 'উত্তোলন') : 'জমা') + ' — ' + who(t.CustomerID),
        detail: [plan ? plan.ItemOrGoalName : '', method, t.VerifiedByManagerID ? ('ম্যানেজার: ' + who(t.VerifiedByManagerID)) : '', notes.join(' · ')].filter(Boolean).join(' · '),
        amount: absAmt, out: isOut
      });

      if (!isOut && counted) {
        if (t.PaymentMethod === 'Cash' && t.VerifiedByManagerID && tsMs >= nowMs - 10 * 60000) {
          (byManager[t.VerifiedByManagerID] = byManager[t.VerifiedByManagerID] || []).push(tsMs);
        }
        if (tsMs >= nowMs - 3 * 60000) {
          var dk = t.CustomerID + '|' + t.PlanID + '|' + absAmt;
          (dupMap[dk] = dupMap[dk] || []).push({ ms: tsMs, cust: t.CustomerID, amt: absAmt });
        }
      }
    });

    // Security / sensitive audit entries (risk-flagged ones, plus logins that failed)
    var failedByUser = {}, failedTotal15 = 0, failedToday = 0, dupTrxByUser = {};
    readSheet('AuditLogs').forEach(function (l) {
      var tsMs = new Date(l.Timestamp).getTime();
      if (!tsMs || isNaN(tsMs)) return;
      var action = String(l.Action || '');
      if (action === 'LOGIN_FAILED' || action === 'LOGIN_LOCKED' || action === 'LOGIN_BLOCKED') {
        if (dhakaDateStr(new Date(tsMs)) === todayStr && action === 'LOGIN_FAILED') failedToday++;
        if (tsMs >= nowMs - 15 * 60000) { failedTotal15++; failedByUser[l.UserID] = (failedByUser[l.UserID] || 0) + 1; }
      }
      if (action === 'DUPLICATE_TRXID_BLOCKED' && tsMs >= nowMs - 24 * hourMs) dupTrxByUser[l.UserID] = (dupTrxByUser[l.UserID] || 0) + 1;
      if (tsMs < sinceMs) return;
      var info = auditInfo_(action);
      if (!info.risk && action !== 'ACCOUNT_UNLOCKED') return;
      events.push({
        id: 'A' + l.LogID, ts: new Date(tsMs).toISOString(), kind: 'sec',
        severity: MONITOR_DANGER_ACTIONS.test(action) ? 'danger' : 'warn',
        title: (MONITOR_ACTION_LABELS[action] || action) + ' — ' + who(l.UserID),
        detail: String(l.Details || ''), amount: 0, out: false
      });
    });

    // Automatic alerts
    var nowIso = new Date(nowMs).toISOString();
    Object.keys(failedByUser).forEach(function (uid) {
      if (failedByUser[uid] >= 3) alerts.push({ severity: 'danger', title: 'বারবার ভুল PIN', detail: whoFull(uid) + ' — গত ১৫ মিনিটে ' + failedByUser[uid] + 'বার', ts: nowIso });
    });
    Object.keys(dupTrxByUser).forEach(function (uid) {
      if (dupTrxByUser[uid] >= 3) alerts.push({ severity: 'danger', title: 'বারবার একই TrxID ব্যবহারের চেষ্টা', detail: whoFull(uid) + ' — গত ২৪ ঘণ্টায় ' + dupTrxByUser[uid] + 'বার আটকানো হয়েছে', ts: nowIso });
    });
    Object.keys(trxSeen).forEach(function (k) {
      var rows = trxSeen[k];
      if (rows.length >= 2 && rows.some(function (r) { return r.ms >= sinceMs; })) alerts.push({ severity: 'warn', title: 'একই TrxID একাধিক লেনদেনে পাওয়া গেছে', detail: 'TrxID ' + k + ' — ' + rows.length + 'টি এন্ট্রি (পুরনো ডেটা, যাচাই করুন)', ts: nowIso });
    });
    if (failedTotal15 >= 6) alerts.push({ severity: 'danger', title: 'সম্ভাব্য PIN অনুমান (ব্রুট-ফোর্স) চেষ্টা', detail: 'গত ১৫ মিনিটে মোট ' + failedTotal15 + 'টি ব্যর্থ লগইন', ts: nowIso });
    Object.keys(byManager).forEach(function (mid) {
      if (byManager[mid].length >= 8) alerts.push({ severity: 'warn', title: 'অস্বাভাবিক দ্রুত নগদ এন্ট্রি', detail: who(mid) + ' — গত ১০ মিনিটে ' + byManager[mid].length + 'টি নগদ জমা', ts: nowIso });
    });
    Object.keys(dupMap).forEach(function (k) {
      if (dupMap[k].length >= 2) alerts.push({ severity: 'warn', title: 'সম্ভাব্য ডুপ্লিকেট জমা', detail: who(dupMap[k][0].cust) + ' — একই প্ল্যানে ' + dupMap[k][0].amt + ' টাকা ৩ মিনিটে ' + dupMap[k].length + 'বার', ts: nowIso });
    });

    var locked = users.filter(function (u) { return u.LockedUntil && new Date(u.LockedUntil).getTime() > nowMs; }).map(function (u) {
      return { userId: u.UserID, name: u.Name, phone: u.Phone, role: u.Role, minutesLeft: Math.ceil((new Date(u.LockedUntil).getTime() - nowMs) / 60000) };
    });
    if (locked.length > 0) alerts.push({ severity: 'warn', title: 'লক হয়ে আছে এমন অ্যাকাউন্ট', detail: locked.length + 'টি অ্যাকাউন্ট এখন লগইন লকে', ts: nowIso });

    // Danger/warn events from the last hour also count toward the overall level
    var recentDanger = events.filter(function (e) { return e.severity === 'danger' && new Date(e.ts).getTime() >= nowMs - hourMs; }).length;
    var recentWarn = events.filter(function (e) { return e.severity === 'warn' && new Date(e.ts).getTime() >= nowMs - hourMs; }).length;
    var level = 'ok', levelText = 'সব স্বাভাবিক — গত ১ ঘণ্টায় কোনো সন্দেহজনক ঘটনা নেই।';
    if (alerts.some(function (a) { return a.severity === 'danger'; }) || recentDanger > 0) { level = 'danger'; levelText = 'সতর্কতা: নিরাপত্তা-ঝুঁকির ঘটনা ঘটেছে — নিচের তালিকা দেখুন।'; }
    else if (alerts.length > 0 || recentWarn > 0) { level = 'warn'; levelText = 'কিছু বিষয় খেয়াল রাখা দরকার।'; }

    events.sort(function (a, b) { return new Date(b.ts) - new Date(a.ts); });
    alerts.sort(function (a, b) { return (a.severity === 'danger' ? 0 : 1) - (b.severity === 'danger' ? 0 : 1); });

    var result = {
      serverTime: nowIso, largeAmount: largeAmount, level: level, levelText: levelText,
      stats: { todayTxnCount: todayTxnCount, todayDepositTotal: todayDepositTotal, todayCash: todayCash, todayOnline: todayOnline,
               lastHourCount: lastHourCount, failedLoginsToday: failedToday, lockedCount: locked.length, pendingClaims: pendingClaims },
      alerts: alerts, locked: locked,
      hourly: hourly.map(function (x) { return { hour: dhakaHour(x.startMs), total: x.total, count: x.count }; }),
      events: events.slice(0, MONITOR_FEED_LIMIT)
    };
    if (cache) { try { cache.put('MONITOR_FEED_V1', JSON.stringify(result), 10); } catch (e) { /* too big or unavailable */ } }
    return ok(result);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin view of deposits that need attention: disputed by the customer,
 * or still Pending confirmation after CONFIG.STALE_CONFIRMATION_HOURS.
 */
function getFlaggedTransactions(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var txns = readSheet('Transactions');
    var users = readSheet('Users');
    var now = new Date().getTime();
    var staleMs = CONFIG.STALE_CONFIRMATION_HOURS * 3600 * 1000;

    function withCustomerName(t) {
      var customer = users.filter(function (u) { return u.UserID === t.CustomerID; })[0];
      return {
        txnId: t.TxnID,
        planId: t.PlanID,
        amount: Number(t.Amount),
        customerId: customer ? customer.UserID : '',
        customerName: customer ? customer.Name : '',
        customerPhone: customer ? customer.Phone : '',
        timestamp: t.Timestamp
      };
    }

    var disputed = txns.filter(function (t) { return t.CustomerConfirmed === 'No'; }).map(withCustomerName);
    var stalePending = txns.filter(function (t) {
      // An offline-queued deposit is judged from when it reached the server, not when it was taken.
      return t.CustomerConfirmed === 'Pending' && (now - new Date(t.SyncedAt || t.Timestamp).getTime()) > staleMs;
    }).map(withCustomerName);

    return ok({ disputed: disputed, stalePending: stalePending });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// v87: ADMIN "লেনদেন" PAGE — every financial entry (deposits, withdrawals, refunds)
// with date / type / status / customer filters, a page-by-page list and a CSV export.
// ---------------------------------------------------------------------------

/** One status key per Transactions row. Withdrawals and refunds are always final. */
function txnStatusKey_(t) {
  if (t.TxnType === 'Withdrawal' || t.TxnType === 'Refund') return 'confirmed';
  if (t.ClaimStatus === 'PendingVerification') return 'pending';
  if (t.ClaimStatus === 'Rejected') return 'rejected';
  if (t.CustomerConfirmed === 'No') return 'disputed';
  if (t.CustomerConfirmed === 'Pending') return 'awaiting';
  return 'confirmed';
}

/**
 * Filters: { from:'yyyy-MM-dd', to:'yyyy-MM-dd', type:'Deposit'|'Withdrawal'|'Refund'|'',
 *            status:'confirmed'|'awaiting'|'pending'|'rejected'|'disputed'|'', customer:'name / phone / id' }
 * Returns every matching row (newest first) plus the totals for exactly those rows.
 * Dates are Dhaka calendar days (Bangladesh has no daylight saving, so a fixed +06:00 is exact).
 */
function adminTxnQuery_(f) {
  f = f || {};
  var dayRe = /^\d{4}-\d{2}-\d{2}$/;
  var from = dayRe.test(String(f.from || '')) ? String(f.from) : '';
  var to = dayRe.test(String(f.to || '')) ? String(f.to) : '';
  if (from && to && from > to) { var sw = from; from = to; to = sw; }
  var fromMs = from ? Date.parse(from + 'T00:00:00+06:00') : null;
  var toMs = to ? Date.parse(to + 'T23:59:59.999+06:00') : null;
  var type = ['Deposit', 'Withdrawal', 'Refund'].indexOf(f.type) > -1 ? f.type : '';
  var status = ['confirmed', 'awaiting', 'pending', 'rejected', 'disputed'].indexOf(f.status) > -1 ? f.status : '';
  var q = cleanText(f.customer || '').toLowerCase();

  var usersById = {};
  var matchIds = q ? {} : null;
  readSheet('Users').forEach(function (u) {
    usersById[u.UserID] = u;
    if (!q || u.Role === ROLES.MANAGER || u.Role === ROLES.ADMIN) return;
    var id = String(u.UserID || '').toLowerCase();
    if (id === q || id.indexOf(q) > -1 || String(u.Name || '').toLowerCase().indexOf(q) > -1 || String(u.Phone || '').indexOf(q) > -1) {
      matchIds[u.UserID] = true;
    }
  });
  var planNames = {};
  readSheet('Plans').forEach(function (p) { planNames[p.PlanID] = p.ItemOrGoalName || ''; });

  var rows = [];
  var sum = {
    count: 0, depositCount: 0, withdrawalCount: 0, refundCount: 0,
    depositTotal: 0, withdrawalTotal: 0, refundTotal: 0,
    pendingCount: 0, pendingAmount: 0, rejectedCount: 0, disputedCount: 0, awaitingCount: 0
  };
  readSheet('Transactions').forEach(function (t) {
    if (type && t.TxnType !== type) return;
    if (matchIds && !matchIds[t.CustomerID]) return;
    var ms = Date.parse(t.Timestamp);
    if (fromMs !== null || toMs !== null) {
      if (isNaN(ms)) return;
      if (fromMs !== null && ms < fromMs) return;
      if (toMs !== null && ms > toMs) return;
    }
    var key = txnStatusKey_(t);
    if (status && key !== status) return;

    var amt = Math.abs(Number(t.Amount) || 0);
    sum.count++;
    // Money totals follow the rest of the app: waiting-for-verification, rejected and disputed deposits are not counted as collected.
    var counts = key === 'confirmed' || key === 'awaiting';
    if (t.TxnType === 'Withdrawal') { sum.withdrawalCount++; sum.withdrawalTotal += amt; }
    else if (t.TxnType === 'Refund') { sum.refundCount++; sum.refundTotal += amt; }
    else {
      sum.depositCount++;
      if (counts) sum.depositTotal += amt;
    }
    if (key === 'pending') { sum.pendingCount++; sum.pendingAmount += amt; }
    else if (key === 'rejected') sum.rejectedCount++;
    else if (key === 'disputed') sum.disputedCount++;
    else if (key === 'awaiting') sum.awaitingCount++;

    var cust = usersById[t.CustomerID];
    var mgr = t.VerifiedByManagerID ? usersById[t.VerifiedByManagerID] : null;
    rows.push({
      txnId: t.TxnID,
      ts: t.Timestamp,
      ms: isNaN(ms) ? 0 : ms,
      type: t.TxnType || 'Deposit',
      amount: amt,
      method: t.PaymentMethod || '',
      trxId: t.TrxID_Receipt || '',
      status: key,
      customerId: t.CustomerID || '',
      customerName: cust ? cust.Name : '',
      customerPhone: cust ? cust.Phone : '',
      planId: t.PlanID || '',
      planName: planNames[t.PlanID] || '',
      byName: mgr ? mgr.Name : '',
      note: t.VerificationNote || ''
    });
  });
  rows.sort(function (a, b) { return b.ms - a.ms; });
  sum.net = sum.depositTotal - sum.withdrawalTotal - sum.refundTotal;
  return { rows: rows, summary: sum };
}

/** Admin-only. One page of the filtered list + totals for the whole filtered set. */
function getAdminTransactions(token, filters, offset, limit) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var r = adminTxnQuery_(filters);
    var off = Math.max(0, parseInt(offset, 10) || 0);
    var lim = Math.min(200, Math.max(1, parseInt(limit, 10) || 50));
    var page = r.rows.slice(off, off + lim).map(function (x) { delete x.ms; return x; });
    return ok({ rows: page, total: r.rows.length, offset: off, summary: r.summary });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin-only. The whole filtered list as CSV text (capped so one download stays quick). */
function exportAdminTransactions(token, filters) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var CAP = 20000;
    var r = adminTxnQuery_(filters);
    var typeBn = { Deposit: 'জমা', Withdrawal: 'উত্তোলন', Refund: 'রিফান্ড' };
    var statusBn = { confirmed: 'নিশ্চিত', awaiting: 'গ্রাহকের নিশ্চিতকরণ বাকি', pending: 'যাচাই অপেক্ষমাণ', rejected: 'বাতিল', disputed: 'বিতর্কিত' };
    var methodBn = { Cash: 'নগদ টাকা', bKash: 'বিকাশ', Nagad: 'নগদ (Nagad)', Refund: 'রিফান্ড' };
    var list = r.rows.slice(0, CAP);
    var csvRows = list.map(function (x) {
      return [
        x.ts ? Utilities.formatDate(new Date(x.ts), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm') : '',
        x.txnId, typeBn[x.type] || x.type, x.amount, methodBn[x.method] || x.method, statusBn[x.status] || x.status,
        x.customerName, x.customerPhone, x.customerId, x.planName, x.planId, x.trxId, x.byName, x.note
      ];
    });
    var csv = buildCsv(
      ['তারিখ ও সময়', 'লেনদেন আইডি', 'ধরন', 'টাকা', 'মাধ্যম', 'অবস্থা', 'গ্রাহক', 'মোবাইল', 'গ্রাহক আইডি', 'প্ল্যান', 'প্ল্যান আইডি', 'TrxID', 'নিয়েছেন (ম্যানেজার)', 'নোট'],
      csvRows
    );
    logAudit(session.UserID, 'TXN_EXPORT', csvRows.length + 'টি লেনদেন CSV হিসেবে নামানো হয়েছে');
    return ok({
      filename: 'amarsonchoy_transactions_' + dhakaDateStr(new Date()) + '.csv',
      csv: csv, rowCount: csvRows.length, totalMatching: r.rows.length, truncated: r.rows.length > CAP
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * v89 — ONE-TIME CLEAN-UP (run by hand from the Apps Script editor, never automatic).
 * Cash deposits taken by a Manager before v89 may still say "waiting for the customer's PIN".
 * The money is already in the balance; this marks those old rows as confirmed so customers
 * stop being asked and they leave the "flagged" list. Disputed ('No') rows are left alone.
 */
function approveOldPendingConfirmations() {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    var rows = findAll('Transactions', function (t) {
      return t.TxnType === 'Deposit' && t.CustomerConfirmed === 'Pending' && t.ClaimStatus !== 'PendingVerification';
    });
    rows.forEach(function (t) { updateRow('Transactions', t._row, { CustomerConfirmed: 'Yes' }); });
    logAudit('SYSTEM', 'OLD_PENDING_CONFIRMATIONS_CLEARED', rows.length + 'টি পুরনো জমা নিশ্চিত হিসেবে চিহ্নিত হয়েছে');
    Logger.log(rows.length + 'টি পুরনো "অপেক্ষমাণ" জমা নিশ্চিত করা হয়েছে।');
    return rows.length;
  } finally {
    try { lock.releaseLock(); } catch (e) { /* ignore */ }
  }
}

// ---------------------------------------------------------------------------
// 17. MISSED INSTALLMENT FOLLOW-UP — Upgrade 6
// ---------------------------------------------------------------------------

/**
 * Time-driven trigger target (installed by setupMissedInstallmentTrigger).
 * For every Active/AtRisk plan, works out how many full saving intervals have
 * passed since the last deposit (or since the plan started, if never
 * deposited into) with no payment. Whenever that count grows past what was
 * last recorded:
 *   - any new miss   → simulated SMS reminder
 *   - reaches 3      → Status becomes AtRisk (shows up in the manager's follow-up list)
 *   - reaches 5      → plan is auto-paused, no penalty, customer notified they
 *                       can resume any time (via resumePlan)
 * Safe to run daily — plans that already have no new miss since the last run
 * are left untouched.
 */
function runMissedInstallmentCheck() {
  var lock = LockService.getScriptLock();
  try {
    try { waitLockFresh(lock, 30000); } catch (lockErr) { /* proceed best-effort */ }

    var plans = readSheet('Plans');
    var now = new Date();
    var eligibleStatuses = [PLAN_STATUS.ACTIVE, PLAN_STATUS.AT_RISK];
    var changedCount = 0;

    // v56: missed installment day => no profit for that day. Record newly missed due-days on each plan first.
    var todayDay = profitDay(now);
    var yesterdayDay = dayFromNumber(dayNumber(todayDay) - 1);
    var txnsByPlan = groupTxnsByPlan(readSheet('Transactions'));
    var missedDaysAdded = 0;
    plans.forEach(function (plan) {
      if (eligibleStatuses.indexOf(plan.Status) === -1) return;
      var iDays = FREQUENCY_DAYS[plan.SavingFrequency];
      var startDay = toDhakaDay(plan.StartDate);
      if (!iDays || !startDay) return;
      var depDays = accrualTxnsFromRows(txnsByPlan[plan.PlanID] || []).filter(function (t) { return t.type === 'Deposit'; })
        .map(function (t) { return toDhakaDay(t.date); }).filter(Boolean);
      var found = computeMissedDueDays(startDay, iDays, depDays, todayDay, toDhakaDay(plan.MissedCheckedDay), toDhakaDay(plan.TargetEndDate));
      var upd = { MissedCheckedDay: yesterdayDay };
      if (found.length) {
        var all = parseMissedDays(plan.MissedDays);
        found.forEach(function (d) { if (all.indexOf(d) === -1) all.push(d); });
        all.sort();
        upd.MissedDays = all.join(',');
        missedDaysAdded += found.length;
        logAudit('', 'PROFIT_MISSED_DAYS', plan.PlanID + ' — ' + found.length + 'টি মিস-দিনে মুনাফা বাদ');
        plan.MissedDays = upd.MissedDays;
      }
      updateRow('Plans', plan._row, upd);
      plan.MissedCheckedDay = yesterdayDay;
    });
    if (missedDaysAdded) { try { syncAllPlanProfitsCore(); } catch (e) { Logger.log('missed-day profit sync failed: ' + e); } }

    plans.forEach(function (plan) {
      if (eligibleStatuses.indexOf(plan.Status) === -1) return;
      var intervalDays = FREQUENCY_DAYS[plan.SavingFrequency];
      if (!intervalDays) return;

      var referenceDateStr = plan.LastDepositDate || plan.StartDate;
      if (!referenceDateStr) return;

      var daysSince = Math.floor((now.getTime() - new Date(referenceDateStr).getTime()) / (1000 * 60 * 60 * 24));
      var missedCount = Math.max(0, Math.floor(daysSince / intervalDays));
      var prevMissed = Number(plan.MissedIntervalCount || 0);
      if (missedCount <= prevMissed) return; // nothing new since the last check

      var customer = findOneBy('Users', 'UserID', plan.CustomerID);
      var updates = { MissedIntervalCount: missedCount };

      if (missedCount >= CONFIG.MISSED_AUTO_PAUSE_THRESHOLD) {
        updates.Status = PLAN_STATUS.PAUSED;
        updates.PreviousStatus = plan.Status;
        if (customer) {
          logSms(customer.Phone, 'AmarSonchoy: আপনার "' + plan.ItemOrGoalName +
            '" প্ল্যানটি টানা কিস্তি মিসের কারণে সাময়িক বন্ধ করা হয়েছে। কোনো জরিমানা নেই — ' +
            'আপনি যেকোনো সময় লগইন করে আবার শুরু করতে পারবেন।');
        }
        logAudit('', 'PLAN_AUTO_PAUSED', plan.PlanID + ' — ' + missedCount + ' বার কিস্তি মিস');
      } else if (missedCount >= CONFIG.MISSED_AT_RISK_THRESHOLD) {
        updates.Status = PLAN_STATUS.AT_RISK;
        if (customer) {
          logSms(customer.Phone, 'AmarSonchoy: আপনার "' + plan.ItemOrGoalName +
            '" প্ল্যানে টানা কিস্তি মিস হচ্ছে। দ্রুত জমা দিন, নাহলে প্ল্যানটি সাময়িক বন্ধ হয়ে যেতে পারে।');
        }
        logAudit('', 'PLAN_AT_RISK', plan.PlanID + ' — ' + missedCount + ' বার কিস্তি মিস');
      } else {
        if (customer) {
          logSms(customer.Phone, 'AmarSonchoy: আপনার "' + plan.ItemOrGoalName +
            '" প্ল্যানের কিস্তি জমা দিতে ভুলে গেছেন বলে মনে হচ্ছে। অনুগ্রহ করে দ্রুত জমা দিন।');
        }
        logAudit('', 'PLAN_MISSED_REMINDER', plan.PlanID + ' — ' + missedCount + ' বার কিস্তি মিস');
      }

      updateRow('Plans', plan._row, updates);
      changedCount++;
    });

    logAudit('', 'DAILY_MISSED_CHECK', changedCount + 'টি প্ল্যানে পরিবর্তন হয়েছে');
  } catch (err) {
    Logger.log('Error in runMissedInstallmentCheck: ' + err);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * Every active Manager's "today's collection-to-be list" — customers in
 * their branch whose next installment is due today or overdue, and the sum
 * they're expected to collect. Upgrade 22.
 */
function computeManagerDueToday(managerBranch) {
  var plans = findAll('Plans', function (p) { return p.Status === PLAN_STATUS.ACTIVE || p.Status === PLAN_STATUS.AT_RISK; });
  var users = readSheet('Users');
  var usersById = {};
  users.forEach(function (u) { usersById[u.UserID] = u; });
  var now = new Date();
  var photos = getCustomerPhotoMap();

  var rows = [];
  plans.forEach(function (plan) {
    var customer = usersById[plan.CustomerID];
    if (!customer) return;
    if (managerBranch && normalizeBranch(customer.Branch) !== managerBranch) return;
    var intervalDays = FREQUENCY_DAYS[plan.SavingFrequency];
    if (!intervalDays) return;
    var referenceDateStr = plan.LastDepositDate || plan.StartDate;
    if (!referenceDateStr) return;
    var daysSince = Math.floor((now.getTime() - new Date(referenceDateStr).getTime()) / DAY_MS);
    if (daysSince < intervalDays) return; // not due yet
    // v84: how many installments have fallen due since the last deposit, and what that adds up to.
    // A "যেকোনো পরিমাণ" plan (InstallmentAmount 0) has no fixed amount, so its owed amount stays 0.
    var dueCount = Math.max(1, Math.floor(daysSince / intervalDays));
    var instAmt = Number(plan.InstallmentAmount) || 0;
    rows.push({
      dueCount: dueCount,
      dueAmount: instAmt > 0 ? instAmt * dueCount : 0,
      customerId: customer.UserID,
      photoUrl: photos[customer.UserID] || '',
      customerName: customer.Name,
      customerPhone: customer.Phone,
      planName: plan.ItemOrGoalName,
      installmentAmount: Number(plan.InstallmentAmount),
      daysOverdue: daysSince - intervalDays
    });
  });
  rows.sort(function (a, b) { return b.daysOverdue - a.daysOverdue; });
  return rows;
}

function getManagerDueTodayList(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var manager = findOneBy('Users', 'UserID', session.UserID);
    var branch = manager ? normalizeBranch(manager.Branch) : '';
    var rows = computeManagerDueToday(session.Role === ROLES.MANAGER ? branch : '');
    var totalDue = rows.reduce(function (s, r) { return s + r.installmentAmount; }, 0);
    return ok({ rows: rows.slice(0, 50), totalDue: totalDue, count: rows.length });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * "আজকের ভিজিট রুট": the customers this manager should visit today — every
 * installment due today or overdue (same rule as the due-today list) — grouped
 * by area so one trip covers one neighbourhood. Area is the customer's
 * "এলাকা" profile field; customers without one fall into a last group, sorted
 * by their address text so similar addresses still sit next to each other.
 */
function getManagerVisitRoute(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var manager = findOneBy('Users', 'UserID', session.UserID);
    var branch = manager ? normalizeBranch(manager.Branch) : '';
    var due = computeManagerDueToday(session.Role === ROLES.MANAGER ? branch : '');

    var profiles = {};
    readSheet('CustomerProfiles').forEach(function (p) { profiles[p.UserID] = p; });

    var NO_AREA = 'এলাকা দেওয়া নেই';
    var groups = {};
    due.forEach(function (r) {
      var pr = profiles[r.customerId] || {};
      var area = cleanText(pr.Area) || NO_AREA;
      var key = area.toLowerCase();
      if (!groups[key]) groups[key] = { area: area, unassigned: area === NO_AREA, visits: [], totalDue: 0, totalOwed: 0 };
      groups[key].visits.push({
        customerId: r.customerId,
        customerName: r.customerName,
        customerPhone: r.customerPhone,
        altPhone: pr.AltPhone || '',
        photoUrl: r.photoUrl,
        address: pr.Address || '',
        shopName: pr.ShopName || '',
        homeLat: (pr.HomeLat !== '' && pr.HomeLat !== undefined) ? Number(pr.HomeLat) : null,
        homeLng: (pr.HomeLng !== '' && pr.HomeLng !== undefined) ? Number(pr.HomeLng) : null,
        planName: r.planName,
        installmentAmount: r.installmentAmount,
        dueCount: r.dueCount,
        dueAmount: r.dueAmount,
        daysOverdue: r.daysOverdue
      });
      groups[key].totalDue += r.installmentAmount;
      groups[key].totalOwed += r.dueAmount;
    });

    var list = Object.keys(groups).map(function (k) { return groups[k]; });
    list.forEach(function (g) {
      g.visits.sort(function (a, b) {
        var byAddr = String(a.address).localeCompare(String(b.address), 'bn');
        return byAddr !== 0 ? byAddr : b.daysOverdue - a.daysOverdue;
      });
    });
    list.sort(function (a, b) {
      if (a.unassigned !== b.unassigned) return a.unassigned ? 1 : -1;
      return String(a.area).localeCompare(String(b.area), 'bn');
    });

    var totalDue = due.reduce(function (s, r) { return s + r.installmentAmount; }, 0);
    var totalOwed = due.reduce(function (s, r) { return s + r.dueAmount; }, 0);   // v84
    return ok({ groups: list, count: due.length, totalDue: totalDue, totalOwed: totalOwed, areaCount: list.filter(function (g) { return !g.unassigned; }).length });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Time-driven (see setupManagerDailyTargetTrigger): logs each Manager's due-today count/amount as an SMS-style message. */
function runManagerDailyTargetReminder() {
  try {
    var managers = findAll('Users', function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; });
    managers.forEach(function (m) {
      var rows = computeManagerDueToday(normalizeBranch(m.Branch));
      var totalDue = rows.reduce(function (s, r) { return s + r.installmentAmount; }, 0);
      if (rows.length === 0) return;
      logSms(m.Phone, 'AmarSonchoy: আজ আপনার শাখায় ' + rows.length + ' জন গ্রাহকের কিস্তি বাকি/আজকের, ' +
        'মোট প্রত্যাশিত কালেকশন প্রায় ৳' + totalDue + '। বিস্তারিত দেখতে অ্যাপে লগইন করুন।');
    });
    logAudit('', 'MANAGER_DAILY_TARGET_REMINDER_RUN', managers.length + ' জন ম্যানেজারকে পাঠানো হয়েছে (লগ)');
  } catch (err) {
    Logger.log('Error in runManagerDailyTargetReminder: ' + err);
  }
}

/**
 * Manager/Admin follow-up list: every plan currently flagged AtRisk, with
 * enough customer contact info to call/visit them.
 */
function getFollowUpList(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var scope = managerScope_(session);   // v81
    var users = readSheet('Users');
    var plans = findAllBy('Plans', 'Status', PLAN_STATUS.AT_RISK).filter(function (p) {
      return inManagerScope_(scope, users.filter(function (u) { return u.UserID === p.CustomerID; })[0]);
    });
    var photos = getCustomerPhotoMap();
    var result = plans.map(function (p) {
      var customer = users.filter(function (u) { return u.UserID === p.CustomerID; })[0];
      return {
        photoUrl: customer ? (photos[customer.UserID] || '') : '',
        planId: p.PlanID,
        itemOrGoalName: p.ItemOrGoalName,
        missedIntervalCount: Number(p.MissedIntervalCount || 0),
        installmentAmount: Number(p.InstallmentAmount),
        savingFrequency: p.SavingFrequency,
        customerId: customer ? customer.UserID : '',
        customerName: customer ? customer.Name : '',
        customerPhone: customer ? customer.Phone : ''
      };
    });
    result.sort(function (a, b) { return b.missedIntervalCount - a.missedIntervalCount; });
    return ok(result);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 18. MANAGER CASH SETTLEMENT — Upgrade 7
// ---------------------------------------------------------------------------

/**
 * Every Cash deposit a manager has logged for a given date, that has not yet
 * been folded into an approved settlement. Shared by submit + approve so the
 * two always agree on which transactions are "in scope".
 */
function getCashDepositsForManagerDate(managerId, dateStr) {
  return findAll('Transactions', function (t) {
    if (t.VerifiedByManagerID !== managerId) return false;
    if (t.PaymentMethod !== 'Cash') return false;
    if (t.TxnType !== 'Deposit') return false;
    if (t.SettledInSettlementID) return false; // already reconciled in an earlier approved settlement
    var txnDate = Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'yyyy-MM-dd');
    return txnDate === dateStr;
  });
}

/**
 * Manager declares the total cash physically in hand at day's end. The system
 * compares it against the sum of cash deposits it has logged for that manager
 * on that date and surfaces any gap for Admin review.
 */
function submitCashSettlement(token, declaredCashAmount, settlementDate) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.MANAGER]);
    declaredCashAmount = Math.round(Number(declaredCashAmount));
    if (isNaN(declaredCashAmount) || declaredCashAmount < 0) {
      return fail('সঠিক নগদের পরিমাণ দিন।');
    }
    var dateStr = settlementDate ? settlementDate : Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');

    waitLockFresh(lock, 30000);

    var alreadySubmitted = findOne('ManagerCashSettlements', function (s) {
      return s.ManagerID === session.UserID && s.SettlementDate === dateStr && s.Status !== 'Rejected';
    });
    if (alreadySubmitted) return fail('এই তারিখের হিসাব ইতিমধ্যে জমা দেওয়া হয়েছে।');

    var txns = getCashDepositsForManagerDate(session.UserID, dateStr);
    var systemAmount = txns.reduce(function (sum, t) { return sum + Number(t.Amount); }, 0);
    var discrepancy = declaredCashAmount - systemAmount;

    var settlement = {
      SettlementID: generateId('SET'),
      ManagerID: session.UserID,
      SettlementDate: dateStr,
      DeclaredCashAmount: declaredCashAmount,
      SystemLoggedCashAmount: systemAmount,
      Discrepancy: discrepancy,
      Status: 'Pending',
      AdminNote: '',
      Timestamp: new Date().toISOString()
    };
    appendRow('ManagerCashSettlements', settlement);
    logAudit(session.UserID, 'CASH_SETTLEMENT_SUBMITTED',
      dateStr + ' — ঘোষিত ৳' + declaredCashAmount + ', সিস্টেম ৳' + systemAmount + ', গরমিল ৳' + discrepancy);

    return ok(settlement);
  } catch (err) {
    Logger.log('Error in submitCashSettlement: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * Manager's own settlement history (most recent first).
 */
function getMyCashSettlements(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER]);
    var rows = findAllBy('ManagerCashSettlements', 'ManagerID', session.UserID);
    rows.forEach(function (r) { delete r._row; });
    rows.sort(function (a, b) { return new Date(b.Timestamp) - new Date(a.Timestamp); });
    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin's approval queue of every settlement still Pending.
 */
function getPendingCashSettlements(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var rows = findAll('ManagerCashSettlements', function (s) { return s.Status === 'Pending'; });
    var users = readSheet('Users');
    var result = rows.map(function (s) {
      var mgr = users.filter(function (u) { return u.UserID === s.ManagerID; })[0];
      return {
        settlementId: s.SettlementID,
        managerName: mgr ? mgr.Name : '',
        managerPhone: mgr ? mgr.Phone : '',
        settlementDate: s.SettlementDate,
        declaredCashAmount: Number(s.DeclaredCashAmount),
        systemLoggedCashAmount: Number(s.SystemLoggedCashAmount),
        discrepancy: Number(s.Discrepancy),
        timestamp: s.Timestamp
      };
    });
    result.sort(function (a, b) { return new Date(a.timestamp) - new Date(b.timestamp); });
    return ok(result);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin approves or rejects a manager's cash settlement. Approving stamps
 * every matching transaction with SettledInSettlementID so it is never
 * counted again in a future settlement for that manager/date.
 */
function approveCashSettlement(token, settlementId, approve, adminNote) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);

    var settlement = findOneBy('ManagerCashSettlements', 'SettlementID', settlementId);
    if (!settlement) return fail('হিসাব খুঁজে পাওয়া যায়নি।');
    if (settlement.Status !== 'Pending') return fail('এই হিসাব ইতিমধ্যে নিষ্পত্তি হয়ে গেছে।');

    if (!approve) {
      updateRow('ManagerCashSettlements', settlement._row, { Status: 'Rejected', AdminNote: adminNote || '' });
      logAudit(session.UserID, 'CASH_SETTLEMENT_REJECTED', settlementId);
      return ok('হিসাব প্রত্যাখ্যান করা হয়েছে। ম্যানেজার আবার জমা দিতে পারবেন।');
    }

    var closed = closeDayCore_(session, settlement, adminNote || '');   // v83: একই "বন্ধ করা" কোড
    logAudit(session.UserID, 'CASH_SETTLEMENT_APPROVED', settlementId + ' — ' + closed.count + 'টি লেনদেন নিষ্পত্তি হয়েছে');
    return ok('হিসাব অনুমোদন করা হয়েছে।');
  } catch (err) {
    Logger.log('Error in approveCashSettlement: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// 19. REWARDS & REFERRALS — Upgrade 8 (helpers; earning logic lives in
//     registerUser and logPayment above)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 40. CUSTOMERS SHEET — Upgrade 23
//     A customers-only mirror of Users (name/phone/branch/status/referral/
//     family/streak), rebuilt automatically whenever a customer is added or
//     changes family — a quick read-only list without the manager/admin rows.
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// 42. EXTENDED CUSTOMER PROFILE (KYC-style) — Upgrade 24
//     Photo, NID, spouse's name, address, shop name, an alternate phone
//     number, and a nominee's own name/photo/NID/address/phone — everything
//     optional, and the form can always be saved even completely blank.
// ---------------------------------------------------------------------------

/** UserID -> profile photo link for every customer who has one (a single sheet read). */
function getCustomerPhotoMap() {
  var map = {};
  try {
    readSheet('CustomerProfiles').forEach(function (p) { if (p.PhotoUrl) map[p.UserID] = p.PhotoUrl; });
  } catch (e) { Logger.log('getCustomerPhotoMap failed: ' + e); }
  return map;
}

function getOrCreateCustomerProfileRow(customerId) {
  var row = findOneBy('CustomerProfiles', 'UserID', customerId);
  if (row) return row;
  appendRow('CustomerProfiles', { UserID: customerId, UpdatedAt: '' });
  return findOneBy('CustomerProfiles', 'UserID', customerId);
}

/** Manager/Admin can view any customer's profile; a Customer can view only their own. */
function getCustomerProfile(token, customerId) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    if (session.Role === ROLES.CUSTOMER && session.UserID !== customerId) return fail('অনুমতি নেই।');
    assertManagerCanServe_(session, customerId);   // v81
    var customer = findOne('Users', function (u) { return u.UserID === customerId && u.Role === ROLES.CUSTOMER; });
    if (!customer) return fail('গ্রাহক খুঁজে পাওয়া যায়নি।');
    var row = findOneBy('CustomerProfiles', 'UserID', customerId);
    var blank = {
      photoUrl: '', nid: '', nidPhotoUrl: '', spouseName: '', address: '', shopName: '', altPhone: '',
      nomineeName: '', nomineeRelation: '', nomineePhone: '', nomineeNid: '', nomineeNidPhotoUrl: '',
      nomineePhotoUrl: '', nomineeAddress: '', updatedAt: '', area: ''
    };
    if (!row) return ok(blank);
    return ok({
      photoUrl: row.PhotoUrl, nid: row.NID, nidPhotoUrl: row.NIDPhotoUrl, spouseName: row.SpouseName,
      address: row.Address, shopName: row.ShopName, altPhone: row.AltPhone,
      nomineeName: row.NomineeName, nomineeRelation: row.NomineeRelation, nomineePhone: row.NomineePhone,
      nomineeNid: row.NomineeNID, nomineeNidPhotoUrl: row.NomineeNIDPhotoUrl,
      nomineePhotoUrl: row.NomineePhotoUrl, nomineeAddress: row.NomineeAddress, updatedAt: row.UpdatedAt,
      area: row.Area || ''
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Saves every text field in one go. Every field is optional — an empty
 * object is a perfectly valid save (it just clears/keeps fields blank).
 */
function updateCustomerProfile(token, customerId, data) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    if (session.Role === ROLES.CUSTOMER && session.UserID !== customerId) return fail('অনুমতি নেই।');
    assertManagerCanServe_(session, customerId);   // v81
    var customer = findOne('Users', function (u) { return u.UserID === customerId && u.Role === ROLES.CUSTOMER; });
    if (!customer) return fail('গ্রাহক খুঁজে পাওয়া যায়নি।');
    data = data || {};
    var row = getOrCreateCustomerProfileRow(customerId);
    updateRow('CustomerProfiles', row._row, {
      NID: cleanText(data.nid),
      SpouseName: cleanText(data.spouseName),
      Address: cleanText(data.address),
      ShopName: cleanText(data.shopName),
      AltPhone: cleanText(data.altPhone),
      NomineeName: cleanText(data.nomineeName),
      NomineeRelation: cleanText(data.nomineeRelation),
      NomineePhone: cleanText(data.nomineePhone),
      NomineeNID: cleanText(data.nomineeNid),
      NomineeAddress: cleanText(data.nomineeAddress),
      Area: cleanText(data.area),
      UpdatedAt: new Date().toISOString()
    });
    logAudit(session.UserID, 'CUSTOMER_PROFILE_UPDATED', customerId);
    return ok('তথ্য সংরক্ষণ করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * v63: "View Profile" — everything about one customer in a single read-only response:
 * identity (phone / branch / joined / status), badge + streak, referral code, who referred them and how many
 * they referred, a running-plans summary, and the extended profile (NID, address, nominee ...).
 * Same access rule as getCustomerProfile: a Customer sees only their own; Manager/Admin see any customer.
 */
function getCustomerViewProfile(token, customerId) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    if (session.Role === ROLES.CUSTOMER && session.UserID !== customerId) return fail('অনুমতি নেই।');
    assertManagerCanServe_(session, customerId);   // v81
    var customer = findOne('Users', function (u) { return u.UserID === customerId && u.Role === ROLES.CUSTOMER; });
    if (!customer) return fail('গ্রাহক খুঁজে পাওয়া যায়নি।');

    var prof = findOneBy('CustomerProfiles', 'UserID', customerId) || {};
    var referrer = customer.ReferredByUserID ? findOneBy('Users', 'UserID', customer.ReferredByUserID) : null;
    var referralCount = findAllBy('Users', 'ReferredByUserID', customerId).length;

    // "Running" = money still held in the plan; Completed / Refunded plans are counted but not added into the total.
    var RUNNING = [PLAN_STATUS.ACTIVE, PLAN_STATUS.AT_RISK, PLAN_STATUS.PAUSED, PLAN_STATUS.REFUND_REQUESTED, PLAN_STATUS.PAUSE_REQUESTED];
    var plans = findAllBy('Plans', 'CustomerID', customerId);
    var runningCount = 0, completedCount = 0, totalSaved = 0;
    plans.forEach(function (p) {
      if (RUNNING.indexOf(p.Status) !== -1) { runningCount++; totalSaved += Number(p.AccumulatedSavings || 0); }
      else if (p.Status === PLAN_STATUS.COMPLETED) completedCount++;
    });
    var planList = plans
      .filter(function (p) { return !p.ArchivedAt && RUNNING.indexOf(p.Status) !== -1; })
      .slice(0, 8)
      .map(function (p) {
        return {
          name: p.ItemOrGoalName, status: p.Status,
          saved: Number(p.AccumulatedSavings || 0), target: Number(p.TargetAmount || 0)
        };
      });

    return ok({
      userId: customer.UserID,
      name: customer.Name,
      phone: customer.Phone,
      status: customer.Status,
      branch: customer.Branch || '',
      joinedAt: customer.CreatedAt || '',
      badge: customer.Badge || '',
      streakCount: Number(customer.StreakCount || 0),
      referralCode: customer.ReferralCode || '',
      referredByName: referrer ? referrer.Name : '',
      referralCount: referralCount,
      plans: { running: runningCount, completed: completedCount, totalSaved: round2(totalSaved), list: planList },
      profile: {
        photoUrl: prof.PhotoUrl || '', nid: prof.NID || '', nidPhotoUrl: prof.NIDPhotoUrl || '',
        spouseName: prof.SpouseName || '', address: prof.Address || '', area: prof.Area || '',
        shopName: prof.ShopName || '', altPhone: prof.AltPhone || '',
        nomineeName: prof.NomineeName || '', nomineeRelation: prof.NomineeRelation || '',
        nomineePhone: prof.NomineePhone || '', nomineeNid: prof.NomineeNID || '',
        nomineeAddress: prof.NomineeAddress || '',
        nomineePhotoUrl: prof.NomineePhotoUrl || '', nomineeNidPhotoUrl: prof.NomineeNIDPhotoUrl || ''
      }
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function getOrCreateCustomerDocsFolder() {
  var props = PropertiesService.getScriptProperties();
  var savedId = props.getProperty('CUSTOMER_DOCS_FOLDER_ID');
  if (savedId) {
    try { return DriveApp.getFolderById(savedId); } catch (e) { /* folder was deleted, make a new one below */ }
  }
  var folder = DriveApp.createFolder(CONFIG.APP_NAME + ' - গ্রাহক ডকুমেন্টস');
  props.setProperty('CUSTOMER_DOCS_FOLDER_ID', folder.getId());
  return folder;
}

var CUSTOMER_DOC_FIELD_MAP = {
  photo: 'PhotoUrl', nidPhoto: 'NIDPhotoUrl', nomineePhoto: 'NomineePhotoUrl', nomineeNidPhoto: 'NomineeNIDPhotoUrl'
};

/**
 * Uploads one image (customer's own photo, their NID scan, the nominee's
 * photo, or the nominee's NID scan) to a private Drive folder and stores its
 * view link on the profile. base64Data has no data: prefix — the client
 * strips that before sending.
 */
function uploadCustomerDocument(token, customerId, kind, base64Data, mimeType) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    if (session.Role === ROLES.CUSTOMER && session.UserID !== customerId) return fail('অনুমতি নেই।');
    assertManagerCanServe_(session, customerId);   // v81
    if (!CUSTOMER_DOC_FIELD_MAP.hasOwnProperty(kind)) return fail('ভুল ধরনের ফাইল।');
    var customer = findOne('Users', function (u) { return u.UserID === customerId && u.Role === ROLES.CUSTOMER; });
    if (!customer) return fail('গ্রাহক খুঁজে পাওয়া যায়নি।');
    if (!base64Data) return fail('কোনো ছবি পাওয়া যায়নি।');
    if (base64Data.length > 7000000) return fail('ছবির সাইজ অনেক বড়, একটু ছোট করে আবার চেষ্টা করুন।');

    var bytes = Utilities.base64Decode(base64Data);
    var folder = getOrCreateCustomerDocsFolder();
    var blob = Utilities.newBlob(bytes, mimeType || 'image/jpeg', kind + '-' + customerId + '.jpg');
    var file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    var url = 'https://drive.google.com/uc?export=view&id=' + file.getId();

    var row = getOrCreateCustomerProfileRow(customerId);
    var update = {};
    update[CUSTOMER_DOC_FIELD_MAP[kind]] = url;
    update.UpdatedAt = new Date().toISOString();
    updateRow('CustomerProfiles', row._row, update);

    logAudit(session.UserID, 'CUSTOMER_DOC_UPLOADED', customerId + ' — ' + kind);
    return ok({ url: url });
  } catch (err) {
    Logger.log('Error in uploadCustomerDocument: ' + err);
    return fail('ছবি আপলোড করতে সমস্যা হয়েছে: ' + String(err.message).replace('AUTH: ', ''));
  }
}

/**
 * Returns one of a customer's profile images (own photo, NID scan, nominee photo / NID scan) as a data URI,
 * read straight from Drive by the app. Used when the browser cannot load the Drive link directly.
 * Same access rule as getCustomerProfile: a Customer sees only their own; Manager/Admin see any.
 */
function getCustomerDocumentImage(token, customerId, kind) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    if (session.Role === ROLES.CUSTOMER && session.UserID !== customerId) return fail('অনুমতি নেই।');
    assertManagerCanServe_(session, customerId);   // v81
    if (!CUSTOMER_DOC_FIELD_MAP.hasOwnProperty(kind)) return fail('ভুল ধরনের ফাইল।');
    var row = findOneBy('CustomerProfiles', 'UserID', customerId);
    var url = row ? row[CUSTOMER_DOC_FIELD_MAP[kind]] : '';
    if (!url) return fail('ছবি নেই।');
    var m = String(url).match(/[?&]id=([\w-]+)/) || String(url).match(/\/d\/([\w-]+)/);
    if (!m) return fail('ছবির লিংক বোঝা যায়নি।');
    var blob = DriveApp.getFileById(m[1]).getBlob();
    var mime = blob.getContentType() || 'image/jpeg';
    return ok({ dataUri: 'data:' + mime + ';base64,' + Utilities.base64Encode(blob.getBytes()) });
  } catch (err) {
    Logger.log('Error in getCustomerDocumentImage: ' + err);
    if (String(err.message).indexOf('AUTH: ') === 0) return fail(String(err.message).replace('AUTH: ', ''));
    return fail('ছবি লোড করা যায়নি।');
  }
}

function syncCustomersSheet() {
  try {
    var sheet = getSheet('Customers');
    var lastRow = sheet.getLastRow();
    if (lastRow > 1) sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).clearContent();
    invalidateSheetMemo('Customers');

    var customers = readSheet('Users').filter(function (u) { return u.Role === ROLES.CUSTOMER; });
    var rows = customers.map(function (u) {
      return {
        UserID: u.UserID, Name: u.Name, Phone: u.Phone, Branch: u.Branch, Status: u.Status,
        JoinedAt: u.CreatedAt, ReferralCode: u.ReferralCode, ReferredByUserID: u.ReferredByUserID,
        FamilyID: u.FamilyID, StreakCount: u.StreakCount, Badge: u.Badge
      };
    });
    appendRows('Customers', rows);
  } catch (err) {
    Logger.log('syncCustomersSheet failed: ' + err);
  }
}

function generateReferralCode(phone) {
  var last4 = String(phone || '').slice(-4);
  var rand = Math.floor(10 + Math.random() * 90);
  return 'AS' + last4 + rand;
}

function generateUniqueReferralCode(phone) {
  var code, attempts = 0;
  do {
    code = generateReferralCode(phone);
    attempts++;
  } while (attempts < 8 && findOneBy('Users', 'ReferralCode', code));
  return code;
}

// ---------------------------------------------------------------------------
// 20. COMMITTEE SAVINGS GROUPS — Upgrade 9
// ---------------------------------------------------------------------------

function generateGroupCode() {
  var rand = Math.floor(1000 + Math.random() * 9000);
  return 'GRP' + rand;
}

function generateUniqueGroupCode() {
  var code, attempts = 0;
  do {
    code = generateGroupCode();
    attempts++;
  } while (attempts < 8 && findOneBy('CommitteeGroups', 'GroupCode', code));
  return code;
}

/**
 * Internal: creates the caller's own Plan inside an existing committee group.
 * Each member keeps a fully separate deposit ledger (their own Plan +
 * Transactions), but every member's progress rolls up into one shared bar
 * (see buildCommitteeGroupSummary) measured against the group's TargetAmount.
 */
function joinCommitteeGroupInternal(session, groupId, data) {
  var group = findOneBy('CommitteeGroups', 'GroupID', groupId);
  if (!group) return fail('গ্রুপ খুঁজে পাওয়া যায়নি।');
  if (group.Status !== 'Active') return fail('এই গ্রুপটি সক্রিয় নেই।');

  var already = findOne('Plans', function (p) { return p.GroupID === groupId && p.CustomerID === session.UserID; });
  if (already) return fail('আপনি ইতিমধ্যে এই গ্রুপে যুক্ত আছেন।');

  var contribution = Math.round(Number(data && data.contributionAmount));
  if (!contribution || contribution <= 0) return fail('আপনার নিজের জমার লক্ষ্যমাত্রা দিন।');
  var frequency = (data && data.savingFrequency) || 'Weekly';

  var calc = calculateInstallment(contribution, frequency, group.TargetEndDate);
  if (!calc.ok) return calc;

  var newPlan = {
    PlanID: generateId('PLN'),
    CustomerID: session.UserID,
    CategoryType: 'Committee',
    ProductID: '',
    ItemOrGoalName: group.GroupName,
    TargetAmount: contribution,
    SavingFrequency: frequency,
    InstallmentAmount: calc.data.installmentAmount,
    AccumulatedSavings: 0,
    Status: PLAN_STATUS.ACTIVE,
    PreviousStatus: '',
    PendingAction: '',
    PendingActionReason: '',
    StartDate: new Date().toISOString(),
    TargetEndDate: group.TargetEndDate,
    AccruedSavingsBonus: 0,
    LastBonusAccrualDate: new Date().toISOString(),
    LastDepositDate: '',
    MissedIntervalCount: 0,
    GroupID: groupId,
    SeasonKey: '',
    ArchivedAt: ''
  };
  appendRow('Plans', newPlan);
  return ok(newPlan);
}

/**
 * Customer creates a new committee (group) savings goal — for a family or a
 * group of neighbours saving together toward one shared target. The creator
 * automatically becomes the group's first member.
 */
function createCommitteeGroup(token, data) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    if (!data || !data.groupName || !data.targetAmount || !data.targetEndDate) {
      return fail('গ্রুপের নাম, লক্ষ্যমাত্রা ও লক্ষ্য পূরণের তারিখ দিন।');
    }
    var targetAmount = Math.round(Number(data.targetAmount));
    if (!targetAmount || targetAmount <= 0) return fail('সঠিক লক্ষ্যমাত্রা দিন।');
    var endDate = new Date(data.targetEndDate);
    if (isNaN(endDate.getTime()) || endDate.getTime() <= new Date().getTime()) {
      return fail('লক্ষ্য পূরণের তারিখ ভবিষ্যতে হতে হবে।');
    }

    var groupId = generateId('GRP');
    var groupCode = generateUniqueGroupCode();

    appendRow('CommitteeGroups', {
      GroupID: groupId,
      GroupCode: groupCode,
      GroupName: cleanText(data.groupName),
      TargetAmount: targetAmount,
      CreatedByUserID: session.UserID,
      Status: 'Active',
      CreatedAt: new Date().toISOString(),
      TargetEndDate: endDate.toISOString()
    });

    var joinResult = joinCommitteeGroupInternal(session, groupId, {
      contributionAmount: data.contributionAmount,
      savingFrequency: data.savingFrequency
    });
    if (!joinResult.ok) return joinResult;

    logAudit(session.UserID, 'COMMITTEE_GROUP_CREATED', data.groupName + ' (' + groupId + ')');
    return ok({ groupId: groupId, groupCode: groupCode });
  } catch (err) {
    Logger.log('Error in createCommitteeGroup: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Customer joins an existing committee group using the short GroupCode
 * shared by whoever created it (e.g. a family member or neighbour).
 */
function joinCommitteeGroupByCode(token, groupCode, data) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    groupCode = String(groupCode || '').trim();
    if (!groupCode) return fail('গ্রুপ কোড দিন।');
    var group = findOneBy('CommitteeGroups', 'GroupCode', groupCode);
    if (!group) return fail('এই কোডে কোনো সমিতি গ্রুপ পাওয়া যায়নি।');

    var result = joinCommitteeGroupInternal(session, group.GroupID, data);
    if (result.ok) {
      logAudit(session.UserID, 'COMMITTEE_GROUP_JOINED', group.GroupName + ' (' + group.GroupID + ')');
    }
    return result;
  } catch (err) {
    Logger.log('Error in joinCommitteeGroupByCode: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Builds one group's shared summary: every member's own contribution ledger,
 * plus a single combined progress bar against the group's shared TargetAmount.
 */
function buildCommitteeGroupSummary(groupId, forUserId) {
  var group = findOneBy('CommitteeGroups', 'GroupID', groupId);
  if (!group) return null;
  var memberPlans = findAllBy('Plans', 'GroupID', groupId);
  var users = readSheet('Users');

  var totalSaved = memberPlans.reduce(function (sum, p) {
    return sum + Number(p.AccumulatedSavings || 0) + Number(p.AccruedSavingsBonus || 0);
  }, 0);
  var target = Number(group.TargetAmount);
  var progressPercent = target > 0 ? Math.min(100, Math.round((totalSaved / target) * 100)) : 0;

  var members = memberPlans.map(function (p) {
    var u = users.filter(function (x) { return x.UserID === p.CustomerID; })[0];
    return {
      name: u ? u.Name : 'অজানা',
      contributed: Number(p.AccumulatedSavings || 0) + Number(p.AccruedSavingsBonus || 0),
      contributionTarget: Number(p.TargetAmount),
      isYou: p.CustomerID === forUserId
    };
  });

  return {
    groupId: group.GroupID,
    groupCode: group.GroupCode,
    groupName: group.GroupName,
    targetAmount: target,
    totalSaved: totalSaved,
    progressPercent: progressPercent,
    targetEndDate: group.TargetEndDate,
    status: group.Status,
    members: members
  };
}

/**
 * All committee groups the logged-in customer belongs to, each with the
 * shared combined progress bar and every member's individual contribution.
 */
function getMyCommitteeGroups(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var myPlans = findAll('Plans', function (p) { return p.CustomerID === session.UserID && p.GroupID; });
    var groupIds = [];
    myPlans.forEach(function (p) {
      if (groupIds.indexOf(p.GroupID) === -1) groupIds.push(p.GroupID);
    });

    var groups = groupIds
      .map(function (gid) { return buildCommitteeGroupSummary(gid, session.UserID); })
      .filter(function (g) { return g !== null; });

    return ok(groups);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 21. PRINTABLE PASSBOOK — Upgrade 10
// ---------------------------------------------------------------------------

/**
 * Full transaction history + summary for one plan, formatted for a printable
 * A6 passbook page so customers without a smartphone can keep paper proof.
 * Customers may only fetch their own plan; Manager/Admin may fetch any.
 */
function getPlanPassbook(token, planId) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    var plan = findOneBy('Plans', 'PlanID', planId);
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (session.Role === ROLES.CUSTOMER && plan.CustomerID !== session.UserID) {
      return fail('এই প্ল্যানটি আপনার নয়।');
    }
    assertManagerCanServe_(session, plan.CustomerID);   // v81

    var customer = findOneBy('Users', 'UserID', plan.CustomerID);
    var pbRate = getCustomerProfitRate(customer);
    var pbLive = livePlanProfit(plan, findAllBy('Transactions', 'PlanID', planId), pbRate.rate);
    // Running savings balance after each row: deposits add, withdrawals subtract
    // (Amount is stored negative for those). A full refund closes the plan at 0.
    var runningBalance = 0;
    var txns = findAll('Transactions', function (t) {
        return t.PlanID === planId && t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected';
      })
      .sort(function (a, b) { return new Date(a.Timestamp) - new Date(b.Timestamp); })
      .map(function (t) {
        var amt = Number(t.Amount);
        runningBalance = (t.TxnType === 'Refund') ? 0 : runningBalance + amt;
        return {
          txnId: t.TxnID,
          amount: amt,
          method: t.PaymentMethod,
          txnType: t.TxnType,
          confirmed: t.CustomerConfirmed,
          timestamp: t.Timestamp,
          balance: runningBalance
        };
      });

    return ok({
      customerName: customer ? customer.Name : '',
      customerPhone: customer ? customer.Phone : '',
      planName: plan.ItemOrGoalName,
      categoryType: plan.CategoryType,
      targetAmount: Number(plan.TargetAmount),
      accumulatedSavings: Number(plan.AccumulatedSavings),
      accruedSavingsBonus: pbLive.bonus_balance,
      accruedProfit: pbLive.total_interest,
      installmentAmount: Number(plan.InstallmentAmount),
      savingFrequency: plan.SavingFrequency,
      startDate: plan.StartDate,
      targetEndDate: plan.TargetEndDate,
      status: plan.Status,
      transactions: txns,
      accrual: { ratePercent: pbRate.rate, rateIsCustom: pbRate.custom, calcDate: pbLive.calc_date,
                 totalPrincipal: pbLive.total_principal, totalInterest: pbLive.total_interest, totalBalance: pbLive.total_balance,
                 breakdown: pbLive.breakdown }
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 35. QR DIGITAL RECEIPTS — Upgrade 22
//     Every confirmed deposit can show a small receipt with a QR code that
//     links to a public, no-login verification page — proof the deposit is
//     genuinely on record, without exposing the customer's private data.
// ---------------------------------------------------------------------------

/** Full receipt detail for the transaction's own customer, or any Manager/Admin. */
function getReceiptDetails(token, txnId) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER, ROLES.MANAGER, ROLES.ADMIN]);
    var txn = findOneBy('Transactions', 'TxnID', txnId);
    if (!txn) return fail('রসিদ খুঁজে পাওয়া যায়নি।');
    if (session.Role === ROLES.CUSTOMER && txn.CustomerID !== session.UserID) {
      return fail('এই রসিদটি আপনার নয়।');
    }
    assertManagerCanServe_(session, txn.CustomerID);   // v81
    var customer = findOneBy('Users', 'UserID', txn.CustomerID);
    var plan = findOneBy('Plans', 'PlanID', txn.PlanID);
    var manager = txn.VerifiedByManagerID ? findOneBy('Users', 'UserID', txn.VerifiedByManagerID) : null;

    return ok({
      txnId: txn.TxnID,
      amount: Number(txn.Amount),
      method: txn.PaymentMethod,
      timestamp: txn.Timestamp,
      customerName: customer ? customer.Name : '',
      planName: plan ? plan.ItemOrGoalName : '',
      managerName: manager ? manager.Name : '',
      verified: txn.ClaimStatus !== 'PendingVerification' && txn.ClaimStatus !== 'Rejected'
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Masks the customer's name for public display, e.g. "রহিমা বেগম" -> "র*** বেগম". */
function maskName(name) {
  name = String(name || '').trim();
  if (!name) return 'গ্রাহক';
  var parts = name.split(/\s+/);
  var first = parts[0];
  var maskedFirst = first.length > 1 ? (first.charAt(0) + '***') : first;
  parts[0] = maskedFirst;
  return parts.join(' ');
}

/**
 * Public, no-login receipt verification — what a QR code on a printed/shared
 * receipt resolves to. Deliberately returns no phone number or address.
 */
function verifyReceiptPublic(txnId) {
  try {
    var txn = findOne('Transactions', function (t) { return t.TxnID === txnId && t.TxnType === 'Deposit'; });
    if (!txn) return ok({ found: false });
    var customer = findOneBy('Users', 'UserID', txn.CustomerID);
    var plan = findOneBy('Plans', 'PlanID', txn.PlanID);
    var verified = txn.ClaimStatus !== 'PendingVerification' && txn.ClaimStatus !== 'Rejected';
    return ok({
      found: true,
      verified: verified,
      amount: Number(txn.Amount),
      method: txn.PaymentMethod,
      timestamp: txn.Timestamp,
      customerNameMasked: maskName(customer ? customer.Name : ''),
      planName: plan ? plan.ItemOrGoalName : ''
    });
  } catch (err) {
    return ok({ found: false });
  }
}

// ---------------------------------------------------------------------------
// 36. FAMILY PLAN — Upgrade 22
//     Independent customer accounts (parents, adult children, siblings) can
//     link under one "family" to see their combined savings at a glance —
//     each person's own plans stay private in every other way.
// ---------------------------------------------------------------------------

function generateFamilyCode() {
  var rand = Math.floor(1000 + Math.random() * 9000);
  return 'FAM' + rand;
}

function generateUniqueFamilyCode() {
  var code, attempts = 0;
  do {
    code = generateFamilyCode();
    attempts++;
  } while (attempts < 8 && findOneBy('Families', 'FamilyCode', code));
  return code;
}

function createFamily(token, familyName) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var user = findOneBy('Users', 'UserID', session.UserID);
    if (user.FamilyID) return fail('আপনি ইতিমধ্যে একটি পরিবারে যুক্ত আছেন। আগে সেটি থেকে বের হন।');
    familyName = cleanText(familyName);
    if (!familyName) return fail('পরিবারের একটা নাম দিন।');

    var familyId = generateId('FAM');
    var code = generateUniqueFamilyCode();
    appendRow('Families', {
      FamilyID: familyId, FamilyName: familyName, FamilyCode: code,
      CreatedByUserID: session.UserID, Status: 'Active', CreatedAt: new Date().toISOString()
    });
    updateRow('Users', user._row, { FamilyID: familyId });
    logAudit(session.UserID, 'FAMILY_CREATED', familyName + ' (' + code + ')');
    syncCustomersSheet();
    return ok({ familyId: familyId, familyCode: code });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function joinFamily(token, code) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var user = findOneBy('Users', 'UserID', session.UserID);
    if (user.FamilyID) return fail('আপনি ইতিমধ্যে একটি পরিবারে যুক্ত আছেন। আগে সেটি থেকে বের হন।');
    var family = findOne('Families', function (f) { return f.FamilyCode === String(code || '').trim().toUpperCase() && f.Status === 'Active'; });
    if (!family) return fail('এই কোডের কোনো পরিবার পাওয়া যায়নি।');
    updateRow('Users', user._row, { FamilyID: family.FamilyID });
    logAudit(session.UserID, 'FAMILY_JOINED', family.FamilyName);
    syncCustomersSheet();
    return ok('পরিবারে যুক্ত হয়েছেন।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function leaveFamily(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var user = findOneBy('Users', 'UserID', session.UserID);
    if (!user.FamilyID) return fail('আপনি কোনো পরিবারে যুক্ত নেই।');
    updateRow('Users', user._row, { FamilyID: '' });
    logAudit(session.UserID, 'FAMILY_LEFT', '');
    syncCustomersSheet();
    return ok('পরিবার থেকে বের হয়েছেন।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Combined view: every member's own total saved+bonus, and the family's grand total. */
function getMyFamilyOverview(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var user = findOneBy('Users', 'UserID', session.UserID);
    if (!user.FamilyID) return ok(null);
    var family = findOneBy('Families', 'FamilyID', user.FamilyID);
    if (!family) return ok(null);

    var members = findAllBy('Users', 'FamilyID', user.FamilyID);
    var plans = readSheet('Plans');
    var totalsByMember = {};
    members.forEach(function (m) { totalsByMember[m.UserID] = 0; });
    plans.forEach(function (p) {
      if (!totalsByMember.hasOwnProperty(p.CustomerID)) return;
      if (p.Status !== 'Active' && p.Status !== 'AtRisk' && p.Status !== 'Completed') return;
      totalsByMember[p.CustomerID] += Number(p.AccumulatedSavings || 0) + Number(p.AccruedSavingsBonus || 0);
    });

    var memberRows = members.map(function (m) {
      return { userId: m.UserID, name: m.Name, isMe: m.UserID === session.UserID, totalSaved: totalsByMember[m.UserID] || 0 };
    }).sort(function (a, b) { return b.totalSaved - a.totalSaved; });

    var grandTotal = memberRows.reduce(function (s, m) { return s + m.totalSaved; }, 0);

    return ok({
      familyName: family.FamilyName,
      familyCode: family.FamilyCode,
      isCreator: family.CreatedByUserID === session.UserID,
      members: memberRows,
      grandTotal: grandTotal
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 37. REFERRAL LEADERBOARD — Upgrade 22
// ---------------------------------------------------------------------------

/** Top referrers by how many people they've successfully brought in — visible to any logged-in role. */
function getReferralLeaderboard(token) {
  try {
    requireRole(token, null);
    var users = readSheet('Users');
    var countByReferrer = {};
    users.forEach(function (u) {
      if (!u.ReferredByUserID) return;
      countByReferrer[u.ReferredByUserID] = (countByReferrer[u.ReferredByUserID] || 0) + 1;
    });
    var rows = Object.keys(countByReferrer).map(function (uid) {
      var u = findOneBy('Users', 'UserID', uid);
      return { userId: uid, name: u ? u.Name : 'অজানা', referralCount: countByReferrer[uid] };
    }).sort(function (a, b) { return b.referralCount - a.referralCount; }).slice(0, 10);
    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 38. DAILY FINANCIAL TIP & BUDGET HELPER — Upgrade 22
// ---------------------------------------------------------------------------

var DAILY_FINANCIAL_TIPS = [
  'প্রতিদিন আয়ের একটা ছোট অংশ, যেমন ৫-১০%, সঞ্চয়ে রাখার অভ্যাস করুন — শুরুতে অল্প হলেও চলবে।',
  'কেনাকাটার আগে ২৪ ঘণ্টা অপেক্ষা করুন — অপ্রয়োজনীয় খরচ অনেকটাই কমে যাবে।',
  'হাতে নগদ টাকা রাখার বদলে জমাতে থাকুন — চোখের সামনে না থাকলে খরচ করার প্রবণতা কমে।',
  'বড় খরচের আগে ছোট ছোট কিস্তিতে জমিয়ে রাখলে ঋণ করার প্রয়োজন পড়ে না।',
  'মাসের শুরুতেই সঞ্চয়ের টাকা আলাদা করে রাখুন, বাকি টাকা দিয়ে মাস চালান — উল্টোটা নয়।',
  'ছোট ছোট অভ্যাস (চা, সিগারেট, বাড়তি খরচ) হিসাব করে দেখুন — মাস শেষে অবাক হবেন।',
  'জরুরি প্রয়োজনের জন্য একটা আলাদা "ইমার্জেন্সি ফান্ড" রাখার চেষ্টা করুন।',
  'ঋণ নিয়ে কিছু কেনার বদলে সেই কিস্তির টাকাটাই আগে জমিয়ে কিনুন — সুদ বেঁচে যাবে।',
  'পরিবারের সবাইকে সঞ্চয়ের পরিকল্পনায় সম্পৃক্ত করুন — একসাথে লক্ষ্য রাখলে সফলতা বাড়ে।',
  'সঞ্চয়ের লক্ষ্য লিখে রাখুন এবং মাঝেমধ্যে দেখুন — লক্ষ্য চোখের সামনে থাকলে অনুপ্রেরণা বজায় থাকে।'
];

/** One tip per day, the same for everyone that day — rotates automatically, no admin setup needed. */
function getDailyFinancialTip() {
  var dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / DAY_MS);
  return DAILY_FINANCIAL_TIPS[dayOfYear % DAILY_FINANCIAL_TIPS.length];
}

// ---------------------------------------------------------------------------
// 38b. BUDGET PLANNER (50/30/20) — v65
//      Admin, Manager ও Customer — সবাই নিজের বাজেট সংরক্ষণ করতে পারেন।
//      একজন ব্যবহারকারীর প্রতি মাসে একটি বাজেট (একই মাসে আবার সেভ করলে আগেরটি হালনাগাদ হয়)।
//      নিজের বাজেট শুধু নিজেই দেখতে/মুছতে পারেন; Admin সব বাজেট দেখতে পারেন (getAllBudgetPlans)।
// ---------------------------------------------------------------------------

var BUDGET_RULE = { needs: 50, wants: 30, savings: 20 };
var BUDGET_MAX_AMOUNT = 1000000000;   // একটি ঘরে সর্বোচ্চ ১০০ কোটি — ভুল টাইপ ঠেকাতে
var BUDGET_MAX_ITEMS_PER_GROUP = 20;
var BUDGET_MAX_PLANS_PER_USER = 60;   // প্রায় ৫ বছরের মাসিক বাজেট

function budgetNum_(v, label) {
  var n = Number(v === '' || v === null || v === undefined ? 0 : v);
  if (isNaN(n) || !isFinite(n) || n < 0) throw new Error(label + ' সঠিক সংখ্যা দিন (০ বা তার বেশি)।');
  if (n > BUDGET_MAX_AMOUNT) throw new Error(label + ' অনেক বড় হয়ে গেছে — আবার দেখে নিন।');
  return Math.round(n * 100) / 100;
}

/** itemsIn = { needs:[{name,amount}], wants:[...], savings:[...] } → পরিষ্কার করা কপি ও প্রতিটি গ্রুপের যোগফল। */
function budgetCleanItems_(itemsIn) {
  var out = { needs: [], wants: [], savings: [] };
  var sums = { needs: 0, wants: 0, savings: 0 };
  itemsIn = itemsIn && typeof itemsIn === 'object' ? itemsIn : {};
  ['needs', 'wants', 'savings'].forEach(function (g) {
    var list = Array.isArray(itemsIn[g]) ? itemsIn[g] : [];
    list.slice(0, BUDGET_MAX_ITEMS_PER_GROUP).forEach(function (it) {
      if (!it) return;
      var name = cleanText(it.name).slice(0, 40);
      var amt = budgetNum_(it.amount, '"' + (name || 'খাত') + '"-এর পরিমাণ');
      if (!name && amt === 0) return;
      out[g].push({ name: name || 'অন্যান্য', amount: amt });
      sums[g] += amt;
    });
    sums[g] = Math.round(sums[g] * 100) / 100;
  });
  return { items: out, sums: sums };
}

/** 'yyyy-MM' — ভবিষ্যতের মাসও চলবে (আগাম পরিকল্পনা), তবে ফরম্যাট ঠিক থাকতে হবে। */
function budgetMonthOk_(m) {
  return /^20[0-9]{2}-(0[1-9]|1[0-2])$/.test(String(m || ''));
}

function budgetRowToClient_(r) {
  var items = null;
  try { items = r.ItemsJson ? JSON.parse(r.ItemsJson) : null; } catch (e) { items = null; }
  return {
    budgetId: r.BudgetID, month: r.Month, title: r.Title || '',
    income: Number(r.Income || 0),
    needsActual: Number(r.NeedsActual || 0), wantsActual: Number(r.WantsActual || 0), savingsActual: Number(r.SavingsActual || 0),
    needsTarget: Number(r.NeedsTarget || 0), wantsTarget: Number(r.WantsTarget || 0), savingsTarget: Number(r.SavingsTarget || 0),
    needsPercent: Number(r.NeedsPercent || BUDGET_RULE.needs), wantsPercent: Number(r.WantsPercent || BUDGET_RULE.wants),
    savingsPercent: Number(r.SavingsPercent || BUDGET_RULE.savings),
    note: r.Note || '', items: items, createdAt: r.CreatedAt, updatedAt: r.UpdatedAt
  };
}

/**
 * বাজেট সংরক্ষণ (নতুন বা হালনাগাদ)। data = { month, title, income, items:{needs,wants,savings}, note, percents?:{needs,wants,savings} }
 * Admin / Manager / Customer — যে কেউ লগইন করা অবস্থায়। একই মাসের আগের বাজেট থাকলে সেটিই হালনাগাদ হয়।
 */
function saveBudgetPlan(token, data) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    data = data || {};
    var month = String(data.month || '').trim();
    if (!budgetMonthOk_(month)) return fail('সঠিক মাস বেছে নিন।');
    var income = budgetNum_(data.income, 'মাসিক আয়ের');
    if (income <= 0) return fail('আগে মাসিক আয় লিখুন।');

    var cleaned = budgetCleanItems_(data.items);
    // ইউজার চাইলে ৫০/৩০/২০ বদলাতে পারে (যেমন ৬০/২০/২০); যোগফল ১০০ হতে হবে। ডিফল্ট ৫০/৩০/২০।
    var pc = data.percents || {};
    var pN = pc.needs === undefined ? BUDGET_RULE.needs : Number(pc.needs);
    var pW = pc.wants === undefined ? BUDGET_RULE.wants : Number(pc.wants);
    var pS = pc.savings === undefined ? BUDGET_RULE.savings : Number(pc.savings);
    if ([pN, pW, pS].some(function (x) { return isNaN(x) || x < 0 || x > 100; }) || Math.abs(pN + pW + pS - 100) > 0.01) {
      return fail('শতাংশের যোগফল ঠিক ১০০ হতে হবে।');
    }

    var now = new Date().toISOString();
    var userRow = findOneBy('Users', 'UserID', session.UserID);
    var rowData = {
      UserID: session.UserID,
      UserName: (userRow && userRow.Name) || session.Name || '',
      Role: session.Role,
      Branch: (userRow && userRow.Branch) || '',
      Month: month,
      Title: cleanText(data.title).slice(0, 60),
      Income: income,
      NeedsActual: cleaned.sums.needs, WantsActual: cleaned.sums.wants, SavingsActual: cleaned.sums.savings,
      NeedsTarget: Math.round(income * pN) / 100, WantsTarget: Math.round(income * pW) / 100, SavingsTarget: Math.round(income * pS) / 100,
      NeedsPercent: pN, WantsPercent: pW, SavingsPercent: pS,
      Note: cleanText(data.note).slice(0, 300),
      ItemsJson: JSON.stringify(cleaned.items),
      UpdatedAt: now
    };
    if (rowData.ItemsJson.length > 40000) return fail('খাতের সংখ্যা অনেক বেশি — কিছু কমান।');

    waitLockFresh(lock, 15000);
    locked = true;

    var mine = findAllBy('BudgetPlans', 'UserID', session.UserID);
    var existing = null;
    mine.forEach(function (r) { if (r.Month === month) existing = r; });

    var budgetId;
    if (existing) {
      budgetId = existing.BudgetID;
      updateRow('BudgetPlans', existing._row, rowData);
    } else {
      if (mine.length >= BUDGET_MAX_PLANS_PER_USER) return fail('সংরক্ষিত বাজেট অনেক হয়ে গেছে — পুরোনো কয়েকটি মুছে ফেলুন।');
      budgetId = generateId('BDG');
      rowData.BudgetID = budgetId;
      rowData.CreatedAt = now;
      appendRow('BudgetPlans', rowData);
    }
    logAudit(session.UserID, existing ? 'BUDGET_UPDATED' : 'BUDGET_SAVED', month + ' · আয় ' + income);
    return ok({ budgetId: budgetId, updated: !!existing, message: existing ? 'বাজেট হালনাগাদ হয়েছে।' : 'বাজেট সংরক্ষণ হয়েছে।' });
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

/** নিজের সংরক্ষিত সব বাজেট — নতুন মাস আগে। */
function getMyBudgetPlans(token) {
  try {
    var session = requireRole(token, null);
    var rows = findAllBy('BudgetPlans', 'UserID', session.UserID)
      .sort(function (a, b) { return a.Month < b.Month ? 1 : (a.Month > b.Month ? -1 : 0); })
      .map(budgetRowToClient_);
    return ok(rows);
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  }
}

/** নিজের একটি বাজেট মুছে ফেলা (অন্যের বাজেট কেউ মুছতে পারে না, Admin-ও না)। */
function deleteBudgetPlan(token, budgetId) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    waitLockFresh(lock, 15000);
    locked = true;
    var row = findOneBy('BudgetPlans', 'BudgetID', String(budgetId || ''));
    if (!row || row.UserID !== session.UserID) return fail('বাজেটটি খুঁজে পাওয়া যায়নি।');
    getSheet('BudgetPlans').deleteRow(row._row);
    invalidateSheetMemo('BudgetPlans');
    logAudit(session.UserID, 'BUDGET_DELETED', row.Month);
    return ok('বাজেট মুছে ফেলা হয়েছে।');
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

/** শুধু Admin: সবার বাজেটের সারসংক্ষেপ (শীটের মতোই) — month ফাঁকা হলে সব মাস। */
function getAllBudgetPlans(token, month) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var rows = readSheet('BudgetPlans');
    if (month) rows = rows.filter(function (r) { return r.Month === String(month); });
    rows.sort(function (a, b) { return a.Month < b.Month ? 1 : (a.Month > b.Month ? -1 : 0); });
    return ok(rows.slice(0, 500).map(function (r) {
      var c = budgetRowToClient_(r);
      c.userId = r.UserID; c.userName = r.UserName; c.role = r.Role; c.branch = r.Branch;
      delete c.items;
      return c;
    }));
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 38c. EXPENSE TRACKER (খরচের হিসাব) — v66
//      Admin, Manager ও Customer — প্রত্যেকে শুধু নিজের ব্যক্তিগত খরচ লিখতে ও দেখতে পারেন।
//      সব ডাটা শীটে থাকে:
//        Expenses       — প্রতিটি খরচ এক সারি (তারিখ, খাত, প্রয়োজনীয়/অপ্রয়োজনীয়, টাকা, মাধ্যম, নোট)
//        ExpenseBudgets — প্রতি মাসে একটি সারি (আয়, খরচের সীমা, সঞ্চয় লক্ষ্য, খাতওয়ারি সীমা)
//        ExpenseGoals   — সঞ্চয় লক্ষ্য (কত জমাতে চান, কত জমেছে, কবে নাগাদ)
//      অন্যের খরচ কেউ দেখতে/বদলাতে/মুছতে পারে না — Admin-ও না।
//      বিশ্লেষণ ও পরামর্শ ব্রাউজারে (Index.html) হিসাব হয়; এখানে শুধু সংরক্ষণ ও সংকলন।
// ---------------------------------------------------------------------------

var EXP_MAX_PER_USER_MONTH = 600;   // একজনের একমাসে সর্বোচ্চ ৬০০টি এন্ট্রি
var EXP_MAX_GOALS_PER_USER = 20;
var EXP_MAX_CATEGORY_LIMITS = 30;
var EXP_TREND_MONTHS = 6;           // ট্রেন্ড চার্টে কত মাস
var EXP_TYPES = ['Essential', 'NonEssential'];
var EXP_METHODS = ['Cash', 'bKash', 'Nagad', 'Card', 'Bank', 'Other'];
// পরিচিত খাতের ডিফল্ট ধরন; অচেনা খাত হলে ব্যবহারকারী নিজে ঠিক করে দেয়, না দিলে NonEssential ধরা হয়।
var EXP_DEFAULT_TYPE = {
  'খাবার ও বাজার': 'Essential', 'ঘরভাড়া': 'Essential', 'বিদ্যুৎ-গ্যাস-পানি': 'Essential', 'যাতায়াত': 'Essential',
  'চিকিৎসা': 'Essential', 'শিক্ষা': 'Essential', 'ঋণ/কিস্তি': 'Essential', 'মোবাইল ও ইন্টারনেট': 'Essential',
  'বাইরে খাওয়া': 'NonEssential', 'বিনোদন': 'NonEssential', 'শপিং ও পোশাক': 'NonEssential',
  'উৎসব ও উপহার': 'NonEssential', 'সাবস্ক্রিপশন': 'NonEssential', 'অন্যান্য': 'NonEssential'
};

/** 'yyyy-MM-dd' সত্যিকারের তারিখ কি না (যেমন ২০২৬-০২-৩০ চলবে না)। */
function expDateOk_(s) {
  s = String(s || '');
  var m = /^(20[0-9]{2})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$/.exec(s);
  if (!m) return false;
  var y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  var dt = new Date(Date.UTC(y, mo - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === mo - 1 && dt.getUTCDate() === d;
}

/** 'yyyy-MM' থেকে delta মাস আগে/পরে। */
function expMonthShift_(month, delta) {
  var p = String(month).split('-');
  var idx = Number(p[0]) * 12 + (Number(p[1]) - 1) + delta;
  var y = Math.floor(idx / 12), mo = idx % 12 + 1;
  return y + '-' + (mo < 10 ? '0' : '') + mo;
}

function expRowToClient_(r) {
  return {
    expenseId: r.ExpenseID, date: r.Date, month: r.Month, category: r.Category,
    type: r.Type === 'Essential' ? 'Essential' : 'NonEssential',
    amount: Number(r.Amount || 0), method: r.PaymentMethod || 'Cash', note: r.Note || ''
  };
}

function expGoalToClient_(r) {
  var target = Number(r.TargetAmount || 0), saved = Number(r.SavedAmount || 0);
  return {
    goalId: r.GoalID, title: r.Title, targetAmount: target, savedAmount: saved,
    targetDate: r.TargetDate || '', status: (target > 0 && saved >= target) ? 'Completed' : 'Active',
    note: r.Note || '', createdAt: r.CreatedAt, updatedAt: r.UpdatedAt
  };
}

/** একটি মাসের জন্য আয়/সীমা/লক্ষ্য ঠিক করে: সংরক্ষিত → বাজেট প্ল্যানার → আগের মাস থেকে আনা → কিছুই না। */
function expResolveSettings_(month, budgetRows, planRows) {
  var i, r, own = null, carried = null;
  for (i = 0; i < budgetRows.length; i++) {
    r = budgetRows[i];
    if (r.Month === month) own = r;
    else if (r.Month < month && (!carried || r.Month > carried.Month)) carried = r;
  }
  function fromBudget(row, source) {
    var lim = {};
    try { lim = row.CategoryLimitsJson ? JSON.parse(row.CategoryLimitsJson) : {}; } catch (e) { lim = {}; }
    return {
      source: source, from: row.Month, income: Number(row.Income || 0), budgetLimit: Number(row.BudgetLimit || 0),
      savingsGoal: Number(row.SavingsGoal || 0), categoryLimits: lim && typeof lim === 'object' ? lim : {}
    };
  }
  if (own) return fromBudget(own, 'saved');
  var plan = null;
  for (i = 0; i < planRows.length; i++) { if (planRows[i].Month === month) plan = planRows[i]; }
  if (plan) {
    var inc = Number(plan.Income || 0), sv = Number(plan.SavingsTarget || 0);
    return {
      source: 'budgetPlan', from: month, income: inc, budgetLimit: Math.max(0, Math.round((inc - sv) * 100) / 100),
      savingsGoal: sv, categoryLimits: {}
    };
  }
  if (carried) return fromBudget(carried, 'carried');
  return { source: 'none', from: '', income: 0, budgetLimit: 0, savingsGoal: 0, categoryLimits: {} };
}

/**
 * খরচের ড্যাশবোর্ডের সব ডাটা এক ডাকে: ওই মাসের এন্ট্রি, শেষ ৬ মাসের ট্রেন্ড (মোট/প্রয়োজনীয়/অপ্রয়োজনীয়/খাতওয়ারি),
 * মাসের আয়-সীমা-লক্ষ্য, সঞ্চয় লক্ষ্যগুলো এবং যেসব মাসে খরচ আছে তার তালিকা।
 */
function getExpenseOverview(token, month) {
  try {
    var session = requireRole(token, null);
    var today = dhakaDateStr(new Date());
    month = String(month || '').trim();
    if (!budgetMonthOk_(month)) month = today.slice(0, 7);

    var mine = findAllBy('Expenses', 'UserID', session.UserID);
    var budgetRows = findAllBy('ExpenseBudgets', 'UserID', session.UserID);
    var planRows = findAllBy('BudgetPlans', 'UserID', session.UserID);

    var months = [], k;
    for (k = EXP_TREND_MONTHS - 1; k >= 0; k--) months.push(expMonthShift_(month, -k));
    var agg = {};
    months.forEach(function (m) { agg[m] = { month: m, total: 0, essential: 0, nonEssential: 0, count: 0, byCategory: {} }; });
    var withData = {};
    var entries = [];
    mine.forEach(function (r) {
      var amt = Number(r.Amount || 0);
      if (!isFinite(amt)) return;
      withData[r.Month] = true;
      var a = agg[r.Month];
      if (a) {
        a.total += amt; a.count++;
        if (r.Type === 'Essential') a.essential += amt; else a.nonEssential += amt;
        a.byCategory[r.Category] = (a.byCategory[r.Category] || 0) + amt;
      }
      if (r.Month === month) entries.push(r);
    });
    entries.sort(function (a, b) {
      if (a.Date !== b.Date) return a.Date < b.Date ? 1 : -1;
      return String(a.CreatedAt) < String(b.CreatedAt) ? 1 : -1;
    });
    var trend = months.map(function (m) {
      var a = agg[m], s = expResolveSettings_(m, budgetRows, planRows);
      a.total = Math.round(a.total * 100) / 100; a.essential = Math.round(a.essential * 100) / 100; a.nonEssential = Math.round(a.nonEssential * 100) / 100;
      a.income = s.income; a.budgetLimit = s.budgetLimit; a.savingsGoal = s.savingsGoal;
      return a;
    });
    var goals = findAllBy('ExpenseGoals', 'UserID', session.UserID).map(expGoalToClient_).sort(function (a, b) {
      if (a.status !== b.status) return a.status === 'Active' ? -1 : 1;
      return String(a.targetDate || '9999') < String(b.targetDate || '9999') ? -1 : 1;
    });
    return ok({
      month: month, today: today,
      entries: entries.slice(0, EXP_MAX_PER_USER_MONTH).map(expRowToClient_),
      trend: trend,
      settings: expResolveSettings_(month, budgetRows, planRows),
      goals: goals,
      monthsWithData: Object.keys(withData).sort().reverse().slice(0, 36)
    });
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  }
}

/** খরচ যোগ বা সংশোধন। data = { expenseId?, date, category, type, amount, method, note } */
function saveExpense(token, data) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    data = data || {};
    var date = String(data.date || '').trim();
    if (!expDateOk_(date)) return fail('সঠিক তারিখ দিন।');
    var limitDate = dhakaDateStr(new Date(Date.now() + 2 * 86400000));
    if (date > limitDate) return fail('ভবিষ্যতের তারিখে খরচ লেখা যায় না — তারিখ দেখে নিন।');
    var amount = budgetNum_(data.amount, 'খরচের টাকা');
    if (amount <= 0) return fail('খরচের টাকা ০-এর বেশি হতে হবে।');
    var category = cleanText(data.category).slice(0, 30);
    if (!category) return fail('খাত বেছে নিন বা লিখুন।');
    var type = String(data.type || '');
    if (EXP_TYPES.indexOf(type) < 0) type = EXP_DEFAULT_TYPE[category] || 'NonEssential';
    var method = String(data.method || 'Cash');
    if (EXP_METHODS.indexOf(method) < 0) method = 'Other';
    var note = cleanText(data.note).slice(0, 200);
    var month = date.slice(0, 7);

    var userRow = findOneBy('Users', 'UserID', session.UserID);
    var now = new Date().toISOString();
    var rowData = {
      UserID: session.UserID, UserName: (userRow && userRow.Name) || session.Name || '', Role: session.Role,
      Branch: (userRow && userRow.Branch) || '', Date: date, Month: month, Category: category, Type: type,
      Amount: amount, PaymentMethod: method, Note: note, UpdatedAt: now
    };

    waitLockFresh(lock, 15000);
    locked = true;

    var expenseId = String(data.expenseId || '');
    if (expenseId) {
      var ex = findOneBy('Expenses', 'ExpenseID', expenseId);
      if (!ex || ex.UserID !== session.UserID) return fail('খরচটি খুঁজে পাওয়া যায়নি।');
      if (ex.Month !== month) {
        var inNew = findAllBy('Expenses', 'UserID', session.UserID).filter(function (r) { return r.Month === month; }).length;
        if (inNew >= EXP_MAX_PER_USER_MONTH) return fail('ওই মাসে এন্ট্রি অনেক হয়ে গেছে।');
      }
      updateRow('Expenses', ex._row, rowData);
      return ok({ expenseId: expenseId, updated: true, message: 'খরচ সংশোধন হয়েছে।' });
    }
    var count = findAllBy('Expenses', 'UserID', session.UserID).filter(function (r) { return r.Month === month; }).length;
    if (count >= EXP_MAX_PER_USER_MONTH) return fail('এই মাসে এন্ট্রি অনেক হয়ে গেছে (সর্বোচ্চ ' + EXP_MAX_PER_USER_MONTH + ')।');
    expenseId = generateId('EXP');
    rowData.ExpenseID = expenseId;
    rowData.CreatedAt = now;
    appendRow('Expenses', rowData);
    return ok({ expenseId: expenseId, updated: false, message: 'খরচ সংরক্ষণ হয়েছে।' });
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

/** নিজের একটি খরচ মোছা। */
function deleteExpense(token, expenseId) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    waitLockFresh(lock, 15000);
    locked = true;
    var row = findOneBy('Expenses', 'ExpenseID', String(expenseId || ''));
    if (!row || row.UserID !== session.UserID) return fail('খরচটি খুঁজে পাওয়া যায়নি।');
    getSheet('Expenses').deleteRow(row._row);
    invalidateSheetMemo('Expenses');
    return ok('খরচ মুছে ফেলা হয়েছে।');
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

/** মাসের আয়, খরচের সীমা, সঞ্চয় লক্ষ্য ও খাতওয়ারি সীমা। data = { month, income, budgetLimit, savingsGoal, categoryLimits:{খাত:টাকা} } */
function saveExpenseBudget(token, data) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    data = data || {};
    var month = String(data.month || '').trim();
    if (!budgetMonthOk_(month)) return fail('সঠিক মাস বেছে নিন।');
    var income = budgetNum_(data.income, 'মাসিক আয়ের');
    var limit = budgetNum_(data.budgetLimit, 'খরচের সীমার');
    var goal = budgetNum_(data.savingsGoal, 'সঞ্চয় লক্ষ্যের');
    var limits = {}, n = 0, src = data.categoryLimits && typeof data.categoryLimits === 'object' ? data.categoryLimits : {};
    Object.keys(src).forEach(function (c) {
      var name = cleanText(c).slice(0, 30);
      if (!name || n >= EXP_MAX_CATEGORY_LIMITS) return;
      var v = budgetNum_(src[c], '"' + name + '"-এর সীমা');
      if (v > 0) { limits[name] = v; n++; }
    });
    var userRow = findOneBy('Users', 'UserID', session.UserID);
    var rowData = {
      UserID: session.UserID, UserName: (userRow && userRow.Name) || session.Name || '', Role: session.Role,
      Month: month, Income: income, BudgetLimit: limit, SavingsGoal: goal,
      CategoryLimitsJson: JSON.stringify(limits), UpdatedAt: new Date().toISOString()
    };
    waitLockFresh(lock, 15000);
    locked = true;
    var existing = null;
    findAllBy('ExpenseBudgets', 'UserID', session.UserID).forEach(function (r) { if (r.Month === month) existing = r; });
    if (existing) {
      updateRow('ExpenseBudgets', existing._row, rowData);
    } else {
      rowData.ExpBudgetID = generateId('EBG');
      appendRow('ExpenseBudgets', rowData);
    }
    return ok({ updated: !!existing, message: 'বাজেট ও লক্ষ্য সংরক্ষণ হয়েছে।' });
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

/** সঞ্চয় লক্ষ্য তৈরি/সংশোধন। data = { goalId?, title, targetAmount, savedAmount, targetDate?, note } */
function saveExpenseGoal(token, data) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    data = data || {};
    var title = cleanText(data.title).slice(0, 60);
    if (!title) return fail('লক্ষ্যের নাম লিখুন।');
    var target = budgetNum_(data.targetAmount, 'লক্ষ্যের টাকা');
    if (target <= 0) return fail('লক্ষ্যের টাকা ০-এর বেশি হতে হবে।');
    var saved = budgetNum_(data.savedAmount, 'এ পর্যন্ত জমার');
    var targetDate = String(data.targetDate || '').trim();
    if (targetDate && !expDateOk_(targetDate)) return fail('লক্ষ্য পূরণের সঠিক তারিখ দিন।');
    var userRow = findOneBy('Users', 'UserID', session.UserID);
    var now = new Date().toISOString();
    var rowData = {
      UserID: session.UserID, UserName: (userRow && userRow.Name) || session.Name || '', Role: session.Role,
      Title: title, TargetAmount: target, SavedAmount: saved, TargetDate: targetDate,
      Status: saved >= target ? 'Completed' : 'Active', Note: cleanText(data.note).slice(0, 200), UpdatedAt: now
    };
    waitLockFresh(lock, 15000);
    locked = true;
    var goalId = String(data.goalId || '');
    if (goalId) {
      var g = findOneBy('ExpenseGoals', 'GoalID', goalId);
      if (!g || g.UserID !== session.UserID) return fail('লক্ষ্যটি খুঁজে পাওয়া যায়নি।');
      updateRow('ExpenseGoals', g._row, rowData);
      return ok({ goalId: goalId, updated: true, message: 'লক্ষ্য হালনাগাদ হয়েছে।' });
    }
    if (findAllBy('ExpenseGoals', 'UserID', session.UserID).length >= EXP_MAX_GOALS_PER_USER) {
      return fail('লক্ষ্য অনেক হয়ে গেছে — পুরোনো কয়েকটি মুছে ফেলুন।');
    }
    goalId = generateId('GOL');
    rowData.GoalID = goalId;
    rowData.CreatedAt = now;
    appendRow('ExpenseGoals', rowData);
    return ok({ goalId: goalId, updated: false, message: 'সঞ্চয় লক্ষ্য তৈরি হয়েছে।' });
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

/** লক্ষ্যে আরও টাকা জমা (যোগ)। */
function addExpenseGoalSaving(token, goalId, amount) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    var add = budgetNum_(amount, 'জমার');
    if (add <= 0) return fail('জমার টাকা ০-এর বেশি হতে হবে।');
    waitLockFresh(lock, 15000);
    locked = true;
    var g = findOneBy('ExpenseGoals', 'GoalID', String(goalId || ''));
    if (!g || g.UserID !== session.UserID) return fail('লক্ষ্যটি খুঁজে পাওয়া যায়নি।');
    var target = Number(g.TargetAmount || 0);
    var saved = Math.round((Number(g.SavedAmount || 0) + add) * 100) / 100;
    updateRow('ExpenseGoals', g._row, { SavedAmount: saved, Status: saved >= target ? 'Completed' : 'Active', UpdatedAt: new Date().toISOString() });
    return ok({ savedAmount: saved, completed: saved >= target, message: saved >= target ? 'অভিনন্দন! লক্ষ্য পূরণ হয়েছে 🎉' : 'জমা যোগ হয়েছে।' });
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

function deleteExpenseGoal(token, goalId) {
  var lock = LockService.getScriptLock();
  var locked = false;
  try {
    var session = requireRole(token, null);
    waitLockFresh(lock, 15000);
    locked = true;
    var g = findOneBy('ExpenseGoals', 'GoalID', String(goalId || ''));
    if (!g || g.UserID !== session.UserID) return fail('লক্ষ্যটি খুঁজে পাওয়া যায়নি।');
    getSheet('ExpenseGoals').deleteRow(g._row);
    invalidateSheetMemo('ExpenseGoals');
    return ok('লক্ষ্য মুছে ফেলা হয়েছে।');
  } catch (err) {
    return fail(String(err.message || err).replace('AUTH: ', ''));
  } finally {
    if (locked) { try { lock.releaseLock(); } catch (e) { /* ignore */ } }
  }
}

// ---------------------------------------------------------------------------
// 39. ADMIN ANALYTICS — Upgrade 22
//     Cohort retention, early "streak breaking" warnings, and a branch
//     comparison table — so the Admin/Manager can act before a customer
//     drops off entirely.
// ---------------------------------------------------------------------------

/**
 * Groups customers by the month they joined and shows how many are still
 * Active today — a simple retention-by-cohort view.
 */
function getCohortAnalysisCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var users = readSheet('Users').filter(function (u) { return u.Role === ROLES.CUSTOMER; });
    var now = new Date();
    var months = [];
    for (var i = 5; i >= 0; i--) {
      months.push(Utilities.formatDate(new Date(now.getFullYear(), now.getMonth() - i, 1), CONFIG.TIMEZONE, 'yyyy-MM'));
    }
    var cohorts = {};
    months.forEach(function (m) { cohorts[m] = { joined: 0, active: 0 }; });

    users.forEach(function (u) {
      var d = new Date(u.CreatedAt);
      if (isNaN(d.getTime())) return;
      var mk = Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM');
      if (!cohorts.hasOwnProperty(mk)) return;
      cohorts[mk].joined++;
      if (u.Status === 'Active') cohorts[mk].active++;
    });

    var rows = months.map(function (m) {
      var c = cohorts[m];
      return {
        month: m,
        joined: c.joined,
        active: c.active,
        retentionPercent: c.joined > 0 ? Math.round((c.active / c.joined) * 100) : null
      };
    });
    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Customers who WERE saving regularly but have gone quiet for a few days —
 * an earlier warning than the AtRisk/missed-installment threshold, so a
 * Manager can nudge them before the streak fully breaks.
 */
function getStreakRiskCustomers(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var manager = findOneBy('Users', 'UserID', session.UserID);
    var branch = session.Role === ROLES.MANAGER && manager ? normalizeBranch(manager.Branch) : null;

    var customers = readSheet('Users').filter(function (u) {
      if (u.Role !== ROLES.CUSTOMER || u.Status !== 'Active') return false;
      if (branch && normalizeBranch(u.Branch) !== branch) return false;
      return true;
    });

    var txns = readSheet('Transactions').filter(function (t) {
      return t.TxnType === 'Deposit' && t.CustomerConfirmed !== 'No' &&
        t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected';
    });
    var now = new Date();
    var thirtyDaysAgo = new Date(now.getTime() - 30 * DAY_MS);

    var byCustomer = {};
    customers.forEach(function (c) { byCustomer[c.UserID] = { lastDeposit: null, last30Count: 0 }; });
    txns.forEach(function (t) {
      var entry = byCustomer[t.CustomerID];
      if (!entry) return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      if (!entry.lastDeposit || d > entry.lastDeposit) entry.lastDeposit = d;
      if (d >= thirtyDaysAgo) entry.last30Count++;
    });

    var photoMapForRisk = getCustomerPhotoMap();
    var rows = [];
    customers.forEach(function (c) {
      var entry = byCustomer[c.UserID];
      if (!entry.lastDeposit) return;
      var daysSince = Math.floor((now.getTime() - entry.lastDeposit.getTime()) / DAY_MS);
      // Was actively saving (4+ deposits in the last 30 days) but has now gone quiet for 3+ days.
      if (entry.last30Count >= 4 && daysSince >= 3) {
        rows.push({ customerId: c.UserID, customerName: c.Name, customerPhone: c.Phone, photoUrl: photoMapForRisk[c.UserID] || '', daysSinceLastDeposit: daysSince, last30Count: entry.last30Count });
      }
    });
    rows.sort(function (a, b) { return b.daysSinceLastDeposit - a.daysSinceLastDeposit; });
    return ok(rows.slice(0, 30));
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Per-branch KPIs so the Admin can see which branch needs attention. */
function getBranchComparisonStatsCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    if (getBranchNames_().length <= 1) return ok([]);

    var users = readSheet('Users');
    var plans = readSheet('Plans');
    var branchByCustomer = {};
    users.forEach(function (u) { branchByCustomer[u.UserID] = normalizeBranch(u.Branch); });

    var stats = {};
    getBranchNames_().forEach(function (b) {
      stats[b] = { branch: b, activeCustomers: 0, totalSaved: 0, completedGoals: 0, atRiskCount: 0 };
    });
    users.forEach(function (u) {
      if (u.Role !== ROLES.CUSTOMER || u.Status !== 'Active') return;
      var b = normalizeBranch(u.Branch);
      if (stats[b]) stats[b].activeCustomers++;
    });
    plans.forEach(function (p) {
      var b = branchByCustomer[p.CustomerID];
      if (!stats[b]) return;
      stats[b].totalSaved += Number(p.AccumulatedSavings || 0) + Number(p.AccruedSavingsBonus || 0);
      if (p.Status === PLAN_STATUS.COMPLETED) stats[b].completedGoals++;
      if (p.Status === PLAN_STATUS.AT_RISK) stats[b].atRiskCount++;
    });

    var rows = getBranchNames_().map(function (b) {
      var s = stats[b];
      s.avgSavedPerCustomer = s.activeCustomers > 0 ? Math.round(s.totalSaved / s.activeCustomers) : 0;
      return s;
    }).sort(function (a, b) { return b.totalSaved - a.totalSaved; });
    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 43. ADVANCED ADMIN ANALYTICS & DECISION SUPPORT — Upgrade 25
//     Forecasting, target-vs-actual pacing, KPI threshold alerts, customer
//     segmentation, a collection heatmap, a signup funnel, a Manager
//     scorecard, a "today's priorities" widget, a profitability estimate,
//     and an audit-log viewer.
// ---------------------------------------------------------------------------

/** This month's total so far, and a simple same-pace projection for the whole month, vs last month. */
function getMonthForecastCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var now = new Date();
    var daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    var dayOfMonth = now.getDate();
    var monthKey = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yyyy-MM');
    var lastMonthKey = Utilities.formatDate(new Date(now.getFullYear(), now.getMonth() - 1, 1), CONFIG.TIMEZONE, 'yyyy-MM');

    var thisMonthTotal = 0, lastMonthTotal = 0;
    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      var mk = Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM');
      if (mk === monthKey) thisMonthTotal += Number(t.Amount || 0);
      else if (mk === lastMonthKey) lastMonthTotal += Number(t.Amount || 0);
    });

    var projected = dayOfMonth > 0 ? Math.round((thisMonthTotal / dayOfMonth) * daysInMonth) : 0;
    var vsLastMonthPercent = lastMonthTotal > 0 ? Math.round(((projected - lastMonthTotal) / lastMonthTotal) * 100) : null;

    return ok({
      dayOfMonth: dayOfMonth, daysInMonth: daysInMonth, thisMonthTotal: thisMonthTotal,
      lastMonthTotal: lastMonthTotal, projectedMonthTotal: projected, vsLastMonthPercent: vsLastMonthPercent
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Daily cumulative collection this month vs an even "pace line" toward the combined Manager target. */
function getTargetVsActualTrend(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var now = new Date();
    var daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    var dayOfMonth = now.getDate();
    var monthKey = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yyyy-MM');

    var totalTarget = readSheet('Users')
      .filter(function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; })
      .reduce(function (s, u) { return s + Number(u.MonthlyTargetAmount || 0); }, 0);

    var dayTotals = {};
    for (var d = 1; d <= dayOfMonth; d++) dayTotals[d] = 0;
    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var dt = new Date(t.Timestamp);
      if (isNaN(dt.getTime())) return;
      if (Utilities.formatDate(dt, CONFIG.TIMEZONE, 'yyyy-MM') !== monthKey) return;
      var dayNum = dt.getDate();
      if (dayTotals.hasOwnProperty(dayNum)) dayTotals[dayNum] += Number(t.Amount || 0);
    });

    var labels = [], cumulativeActual = [], cumulativePace = [];
    var running = 0;
    var pacePerDay = daysInMonth > 0 ? totalTarget / daysInMonth : 0;
    for (var day = 1; day <= dayOfMonth; day++) {
      running += dayTotals[day];
      cumulativeActual.push(Math.round(running));
      cumulativePace.push(Math.round(pacePerDay * day));
      labels.push(String(day));
    }
    return ok({ labels: labels, actual: cumulativeActual, pace: cumulativePace, totalTarget: totalTarget });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Red-badge alerts when a key number crosses a sensible threshold — so problems aren't missed. */
function getKpiAlerts(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var atRiskCount = findAllBy('Plans', 'Status', PLAN_STATUS.AT_RISK).length;
    var streakRiskRes = getStreakRiskCustomers(token);
    var streakRiskCount = streakRiskRes.ok ? streakRiskRes.data.length : 0;
    var pendingSettlements = findAll('ManagerCashSettlements', function (s) { return s.Status === 'Pending'; }).length;
    var pendingOnlineClaims = findAll('Transactions', function (t) { return t.ClaimStatus === 'PendingVerification'; }).length;

    var alerts = [];
    function check(count, threshold, label) {
      if (count > threshold) alerts.push({ label: label, count: count, severity: count > threshold * 2 ? 'high' : 'medium' });
    }
    check(atRiskCount, 3, 'ঝুঁকিপূর্ণ প্ল্যান');
    check(streakRiskCount, 3, 'সঞ্চয়ের ধারা ভাঙছে এমন গ্রাহক');
    check(pendingSettlements, 2, 'অপেক্ষমাণ ক্যাশ হিসাব');
    check(pendingOnlineClaims, 5, 'অপেক্ষমাণ অনলাইন পেমেন্ট');
    return ok(alerts);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Buckets every customer into a simple segment for quick decision-making. */
function getCustomerSegments(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var now = new Date();
    var users = readSheet('Users').filter(function (u) { return u.Role === ROLES.CUSTOMER; });
    var txns = readSheet('Transactions').filter(function (t) {
      return t.TxnType === 'Deposit' && t.CustomerConfirmed !== 'No' &&
        t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected';
    });
    var stats = {};
    users.forEach(function (u) { stats[u.UserID] = { count30: 0, lastDeposit: null, totalDeposits: 0 }; });
    var thirtyDaysAgo = new Date(now.getTime() - 30 * DAY_MS);
    txns.forEach(function (t) {
      var s = stats[t.CustomerID];
      if (!s) return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      s.totalDeposits++;
      if (!s.lastDeposit || d > s.lastDeposit) s.lastDeposit = d;
      if (d >= thirtyDaysAgo) s.count30++;
    });

    var segments = { heavy: 0, regular: 0, newcomer: 0, inactive: 0, neverDeposited: 0 };
    users.forEach(function (u) {
      var s = stats[u.UserID];
      var joinedDaysAgo = Math.floor((now.getTime() - new Date(u.CreatedAt).getTime()) / DAY_MS);
      if (s.totalDeposits === 0) { segments.neverDeposited++; return; }
      var daysSinceLast = s.lastDeposit ? Math.floor((now.getTime() - s.lastDeposit.getTime()) / DAY_MS) : 999;
      if (daysSinceLast > 14) { segments.inactive++; return; }
      if (joinedDaysAgo <= 30) { segments.newcomer++; return; }
      if (s.count30 >= 8) { segments.heavy++; return; }
      segments.regular++;
    });
    return ok(segments);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Daily collection totals for the last N days — feeds a calendar heatmap. */
function getCollectionHeatmapCompute_(token, days) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    days = Math.max(28, Math.min(120, Number(days) || 90));
    var now = new Date();
    var dayTotals = {}, dateKeys = [];
    for (var i = days - 1; i >= 0; i--) {
      var k = dhakaDateStr(new Date(now.getTime() - i * DAY_MS));
      dateKeys.push(k);
      dayTotals[k] = 0;
    }
    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      var key = dhakaDateStr(d);
      if (dayTotals.hasOwnProperty(key)) dayTotals[key] += Number(t.Amount || 0);
    });
    return ok(dateKeys.map(function (k) { return { date: k, total: dayTotals[k] }; }));
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Registration → first deposit → regular saver (5+ deposits) → goal completed. */
function getFunnelDataCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var users = readSheet('Users').filter(function (u) { return u.Role === ROLES.CUSTOMER; });
    var txns = readSheet('Transactions').filter(function (t) {
      return t.TxnType === 'Deposit' && t.CustomerConfirmed !== 'No' &&
        t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected';
    });
    var depositCountByCustomer = {};
    txns.forEach(function (t) { depositCountByCustomer[t.CustomerID] = (depositCountByCustomer[t.CustomerID] || 0) + 1; });
    var completedCustomers = {};
    readSheet('Plans').forEach(function (p) { if (p.Status === PLAN_STATUS.COMPLETED) completedCustomers[p.CustomerID] = true; });

    var registered = users.length;
    var madeFirstDeposit = users.filter(function (u) { return (depositCountByCustomer[u.UserID] || 0) >= 1; }).length;
    var regularSaver = users.filter(function (u) { return (depositCountByCustomer[u.UserID] || 0) >= 5; }).length;
    var completedGoal = users.filter(function (u) { return completedCustomers[u.UserID]; }).length;

    return ok([
      { stage: 'রেজিস্ট্রেশন', count: registered },
      { stage: 'প্রথম জমা', count: madeFirstDeposit },
      { stage: 'নিয়মিত সঞ্চয়কারী (৫+ জমা)', count: regularSaver },
      { stage: 'লক্ষ্যপূরণ', count: completedGoal }
    ]);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Ranks every Manager by target-achievement %, branch retention %, and average settlement discrepancy. */
function getManagerScorecard(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var now = new Date();
    var monthKey = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yyyy-MM');
    var managers = readSheet('Users').filter(function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; });
    var users = readSheet('Users');

    var achievedByManager = {};
    managers.forEach(function (m) { achievedByManager[m.UserID] = 0; });
    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      if (Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM') !== monthKey) return;
      if (achievedByManager.hasOwnProperty(t.VerifiedByManagerID)) achievedByManager[t.VerifiedByManagerID] += Number(t.Amount || 0);
    });

    var discrepancyByManager = {}, settlementCountByManager = {};
    managers.forEach(function (m) { discrepancyByManager[m.UserID] = 0; settlementCountByManager[m.UserID] = 0; });
    readSheet('ManagerCashSettlements').forEach(function (s) {
      if (!discrepancyByManager.hasOwnProperty(s.ManagerID)) return;
      discrepancyByManager[s.ManagerID] += Math.abs(Number(s.Discrepancy || 0));
      settlementCountByManager[s.ManagerID]++;
    });

    var rows = managers.map(function (m) {
      var branchCustomers = users.filter(function (u) { return u.Role === ROLES.CUSTOMER && normalizeBranch(u.Branch) === normalizeBranch(m.Branch); });
      var activeCustomers = branchCustomers.filter(function (u) { return u.Status === 'Active'; }).length;
      var retentionPercent = branchCustomers.length > 0 ? Math.round((activeCustomers / branchCustomers.length) * 100) : null;
      var target = Number(m.MonthlyTargetAmount || 0);
      var achieved = achievedByManager[m.UserID] || 0;
      var achievementPercent = target > 0 ? Math.round((achieved / target) * 100) : null;
      var avgDiscrepancy = settlementCountByManager[m.UserID] > 0 ? Math.round(discrepancyByManager[m.UserID] / settlementCountByManager[m.UserID]) : 0;
      return {
        managerId: m.UserID, name: m.Name, branch: m.Branch,
        achievementPercent: achievementPercent, achieved: achieved, target: target,
        retentionPercent: retentionPercent, avgDiscrepancy: avgDiscrepancy
      };
    }).sort(function (a, b) { return (b.achievementPercent === null ? -1 : b.achievementPercent) - (a.achievementPercent === null ? -1 : a.achievementPercent); });

    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Everything the Admin needs to act on today, in one place. */
function getTodayPriorities(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var pendingRequests = findAll('Plans', function (p) {
      return p.Status === PLAN_STATUS.REFUND_REQUESTED || p.Status === PLAN_STATUS.PAUSE_REQUESTED;
    }).length;
    var disputedCount = findAll('Transactions', function (t) { return t.CustomerConfirmed === 'No'; }).length;
    var pendingOnlineClaims = findAll('Transactions', function (t) { return t.ClaimStatus === 'PendingVerification'; }).length;
    var pendingSettlements = findAll('ManagerCashSettlements', function (s) { return s.Status === 'Pending'; }).length;
    var atRiskCount = findAllBy('Plans', 'Status', PLAN_STATUS.AT_RISK).length;
    var streakRiskRes = getStreakRiskCustomers(token);
    var streakRiskCount = streakRiskRes.ok ? streakRiskRes.data.length : 0;

    var items = [
      { label: 'অনুমোদনের অপেক্ষায় থাকা অনুরোধ (রিফান্ড/পজ)', count: pendingRequests, section: 'plans' },
      { label: 'আপত্তিকৃত/অনিশ্চিত জমা', count: disputedCount, section: 'flagged' },
      { label: 'অনলাইন পেমেন্ট যাচাই বাকি', count: pendingOnlineClaims, section: 'claims' },
      { label: 'ম্যানেজারের ক্যাশ হিসাব অপেক্ষমাণ', count: pendingSettlements, section: 'settlements' },
      { label: 'ঝুঁকিপূর্ণ প্ল্যান', count: atRiskCount, section: 'charts' },
      { label: 'সঞ্চয়ের ধারা ভাঙছে এমন গ্রাহক', count: streakRiskCount, section: 'streakrisk' }
    ].filter(function (i) { return i.count > 0; }).sort(function (a, b) { return b.count - a.count; });

    return ok(items);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * A simple profitability estimate: total collected this month, minus the
 * bonus paid out, minus operating-cost assumptions the Admin sets themselves
 * (there's no real payroll/rent data in this app, so these are the Admin's
 * own numbers, saved for next time).
 */
function getProfitabilitySettings() {
  var props = PropertiesService.getScriptProperties();
  return {
    monthlyStaffCost: Number(props.getProperty('PROFIT_STAFF_COST') || 0),
    monthlyOtherCost: Number(props.getProperty('PROFIT_OTHER_COST') || 0)
  };
}

function updateProfitabilitySettings(token, data) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var props = PropertiesService.getScriptProperties();
    props.setProperty('PROFIT_STAFF_COST', String(Math.max(0, Number((data && data.monthlyStaffCost) || 0))));
    props.setProperty('PROFIT_OTHER_COST', String(Math.max(0, Number((data && data.monthlyOtherCost) || 0))));
    invalidateAdminReportCache();
    logAudit(session.UserID, 'PROFITABILITY_SETTINGS_UPDATED', '');
    return ok('সংরক্ষণ করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function getProfitabilityEstimateCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var now = new Date();
    var monthKey = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yyyy-MM');
    var collected = 0, bonusPaid = 0;
    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime()) || Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM') !== monthKey) return;
      collected += Number(t.Amount || 0);
    });
    // Bonus is accrued gradually on Plans, so this month's bonus cost is estimated from
    // total accrued-so-far divided across the plan's elapsed months — kept simple on purpose.
    readSheet('Plans').forEach(function (p) {
      bonusPaid += Number(p.AccruedSavingsBonus || 0);
    });
    var costs = getProfitabilitySettings();
    var totalCost = costs.monthlyStaffCost + costs.monthlyOtherCost;
    var netThisMonth = collected - totalCost;
    return ok({
      collectedThisMonth: collected, bonusAccruedTotal: bonusPaid,
      monthlyStaffCost: costs.monthlyStaffCost, monthlyOtherCost: costs.monthlyOtherCost,
      totalCost: totalCost, netThisMonth: netThisMonth
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Audit action → category (first matching rule wins) and a "worth a second look" flag. */
var AUDIT_RULES = [
  { cat: 'লগইন ও নিরাপত্তা', re: /^(LOGIN_|BRANCH_ACCESS|PIN_|REGISTER|INITIAL_ADMIN_SETUP|USER_STATUS_CHANGED|USER_BRANCH_CHANGED|MANAGER_CREATED|CUSTOMER_ONBOARDED)/ },
  { cat: 'টাকা-পয়সা', re: /^(DAY_CLOSED|DAY_REOPENED|LATE_ENTRY_AFTER_CLOSE|DUPLICATE_TRXID|PAYMENT_LOGGED|DEPOSIT_|WITHDRAWAL|ONLINE_PAYMENT_|CASH_SETTLEMENT_|REFUND_|MONTHLY_PROFIT|PROFIT_RATE_SET|PAYMENT_SETTINGS|PAYMENT_QR)/ },
  { cat: 'প্ল্যান', re: /^(PLAN_|PAUSE_|GOAL_|PLANS_ARCHIVED)/ },
  { cat: 'রিপোর্ট ও ব্যাকআপ', re: /^(REPORT_|BACKUP_)/ },
  { cat: 'স্বয়ংক্রিয় (সিস্টেম)', re: /^(DAILY_|SEASONAL_REMINDERS|MANAGER_DAILY|DEMO_SEED)/ },
  { cat: 'সেটিংস ও কনটেন্ট', re: /(SETTINGS|PRODUCT_|CAMPAIGN|MANAGER_TARGET|CUSTOMER_|COMMITTEE_|FAMILY_)/ }
];
var AUDIT_OTHER_CATEGORY = 'অন্যান্য';
var AUDIT_RISK_RE = /^(DAY_REOPENED|LATE_ENTRY_AFTER_CLOSE|DUPLICATE_TRXID_BLOCKED|BRANCH_ACCESS_DENIED|PIN_RESET|LOGIN_FAILED|LOGIN_LOCKED|LOGIN_BLOCKED|USER_STATUS_CHANGED|USER_BRANCH_CHANGED|MANAGER_CREATED|INITIAL_ADMIN_SETUP|REFUND_APPROVED|DEPOSIT_DISPUTED|PROFIT_RATE_SET|PAYMENT_SETTINGS_UPDATED|PAYMENT_QR_UPLOADED|CASH_SETTLEMENT_REJECTED|ONLINE_PAYMENT_REJECTED|PLANS_ARCHIVED_BULK|BACKUP_FAILED|REPORT_EXPORTED)/;
var AUDIT_SYSTEM_USER = '__SYSTEM__';
var AUDIT_EXPORT_MAX_ROWS = 5000;

function auditInfo_(action) {
  var a = String(action || '');
  for (var i = 0; i < AUDIT_RULES.length; i++) {
    if (AUDIT_RULES[i].re.test(a)) return { category: AUDIT_RULES[i].cat, risk: AUDIT_RISK_RE.test(a) };
  }
  return { category: AUDIT_OTHER_CATEGORY, risk: AUDIT_RISK_RE.test(a) };
}

/**
 * Shared by the on-screen viewer and the exports. Filters: search (name/phone/action/details),
 * userId (or "__SYSTEM__" for automatic entries), category, from/to (Dhaka dates), onlyRisk.
 * Newest first. Returns { rows, total } where rows is the requested page.
 */
function queryAuditLogs_(filters, limit, offset) {
  filters = filters || {};
  var usersById = {};
  readSheet('Users').forEach(function (u) { usersById[u.UserID] = u; });

  var searchText = String(filters.search || '').trim().toLowerCase();
  var fromDate = filters.from ? new Date(filters.from + 'T00:00:00+06:00') : null;
  var toDate = filters.to ? new Date(filters.to + 'T23:59:59+06:00') : null;
  var userId = String(filters.userId || '');
  var category = String(filters.category || '');
  var onlyRisk = filters.onlyRisk === true || filters.onlyRisk === 'true';

  var matched = [];
  readSheet('AuditLogs').forEach(function (l) {
    var d = new Date(l.Timestamp);
    if (fromDate && d < fromDate) return;
    if (toDate && d > toDate) return;
    if (userId) {
      if (userId === AUDIT_SYSTEM_USER ? l.UserID : l.UserID !== userId) return;
    }
    var info = auditInfo_(l.Action);
    if (category && info.category !== category) return;
    if (onlyRisk && !info.risk) return;
    var user = usersById[l.UserID];
    if (searchText) {
      var haystack = (l.Action + ' ' + l.Details + ' ' + (user ? user.Name + ' ' + user.Phone : '')).toLowerCase();
      if (haystack.indexOf(searchText) === -1) return;
    }
    matched.push({ t: d, l: l, user: user, info: info });
  });
  matched.sort(function (a, b) { return b.t - a.t; });

  var page = matched.slice(offset, offset + limit).map(function (m) {
    return {
      timestamp: m.l.Timestamp, action: m.l.Action, details: m.l.Details,
      userName: m.user ? m.user.Name : (m.l.UserID || 'সিস্টেম'), userRole: m.user ? m.user.Role : '',
      category: m.info.category, risk: m.info.risk
    };
  });
  return { rows: page, total: matched.length };
}

/** Admin-only. One page (50) of audit entries plus the total match count. */
function getAuditLogEntries(token, filters) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    filters = filters || {};
    var offset = Math.max(0, Number(filters.offset) || 0);
    var pageSize = 50;
    var res = queryAuditLogs_(filters, pageSize, offset);
    return ok({ rows: res.rows, total: res.total, offset: offset, pageSize: pageSize });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin-only. Fills the "who" and "what" dropdowns: only people who actually appear in the log. */
function getAuditFilterOptions(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var usersById = {};
    readSheet('Users').forEach(function (u) { usersById[u.UserID] = u; });
    var seen = {}, hasSystem = false;
    readSheet('AuditLogs').forEach(function (l) {
      if (!l.UserID) hasSystem = true; else seen[l.UserID] = true;
    });
    var users = Object.keys(seen).filter(function (id) { return usersById[id]; }).map(function (id) {
      return { id: id, name: usersById[id].Name, role: usersById[id].Role };
    }).sort(function (a, b) { return String(a.name).localeCompare(String(b.name)); });
    var categories = AUDIT_RULES.map(function (r) { return r.cat; }).concat([AUDIT_OTHER_CATEGORY]);
    return ok({ users: users, categories: categories, hasSystem: hasSystem });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 22. MANAGER OFFLINE SUPPORT — Upgrade 11
//     (the offline queue itself lives in the browser; the server side only needs
//      a customer roster snapshot, safe re-sending, and honest timestamps)
// ---------------------------------------------------------------------------

/**
 * A compact snapshot of every active customer who has at least one plan that
 * can take a deposit. The manager's phone keeps this copy so a customer can
 * still be found and a deposit still be entered when there is no internet.
 * Contains no PINs.
 */
function getManagerRoster(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var scope = managerScope_(session);   // v81
    var users = readSheet('Users');
    var plans = readSheet('Plans');

    var plansByCustomer = {};
    plans.forEach(function (p) {
      if (p.Status !== PLAN_STATUS.ACTIVE && p.Status !== PLAN_STATUS.AT_RISK) return;
      if (!plansByCustomer[p.CustomerID]) plansByCustomer[p.CustomerID] = [];
      plansByCustomer[p.CustomerID].push({
        PlanID: p.PlanID,
        ItemOrGoalName: p.ItemOrGoalName,
        TargetAmount: Number(p.TargetAmount),
        AccumulatedSavings: Number(p.AccumulatedSavings || 0),
        InstallmentAmount: Number(p.InstallmentAmount),
        SavingFrequency: p.SavingFrequency,
        Status: p.Status
      });
    });

    var rosterPhotos = getCustomerPhotoMap();
    var customers = [];
    users.forEach(function (u) {
      if (u.Role !== ROLES.CUSTOMER || u.Status !== 'Active') return;
      if (!plansByCustomer[u.UserID]) return;
      if (!inManagerScope_(scope, u)) return;
      customers.push({ UserID: u.UserID, Name: u.Name, Phone: u.Phone, PhotoUrl: rosterPhotos[u.UserID] || '', plans: plansByCustomer[u.UserID] });
    });

    return ok({ generatedAt: new Date().toISOString(), customers: customers });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// v71. DYNAMIC VILLAGES / BRANCHES (গ্রাম / এলাকা / শাখা)
// The list used to be fixed in CONFIG.BRANCHES. Now the Admin edits it from inside the
// app (সেটিংস > গ্রাম / শাখা ব্যবস্থাপনা). It is stored in Script Properties (BRANCH_LIST),
// so every screen — registration, manager/customer forms, branch reports, quick collection —
// reads the same live list. CONFIG.BRANCHES is only the starting list used the very first time.
// Names are compared after Unicode (NFC) normalisation and with invisible characters and extra
// spaces ignored, so "মালদ  গাঁও" typed with a stray space still matches "মালদ গাঁও".
// ---------------------------------------------------------------------------
var BRANCH_MEMO_ = null;
var MAX_BRANCH_NAME_LEN = 40;
var MAX_BRANCHES = 200;

function branchKey_(text) {
  var s = String(text == null ? '' : text);
  try { s = s.normalize('NFC'); } catch (e) { /* very old runtime: compare as is */ }
  return s.replace(/[\u200b\u200c\u200d\u2060\ufeff]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
}

function getBranchRecords_() {
  if (BRANCH_MEMO_) return BRANCH_MEMO_;
  var list = null;
  try { list = JSON.parse(PropertiesService.getScriptProperties().getProperty('BRANCH_LIST') || 'null'); } catch (e) { list = null; }
  var out = [], seen = {};
  function push(name, active) {
    name = cleanText(name);
    var k = branchKey_(name);
    if (!name || seen[k]) return;
    seen[k] = true;
    out.push({ name: name, active: active !== false });
  }
  if (Array.isArray(list)) list.forEach(function (r) { push(r && r.name, r && r.active); });
  if (!out.length) (CONFIG.BRANCHES || []).forEach(function (n) { push(n, true); });
  BRANCH_MEMO_ = out;
  return out;
}

function saveBranchRecords_(list) {
  PropertiesService.getScriptProperties().setProperty('BRANCH_LIST', JSON.stringify(list));
  BRANCH_MEMO_ = null;
  try { invalidateAdminReportCache(); } catch (e) { /* cache is optional */ }
}

function getBranchNames_() { return getBranchRecords_().map(function (r) { return r.name; }); }
function getActiveBranchNames_() { return getBranchRecords_().filter(function (r) { return r.active; }).map(function (r) { return r.name; }); }

function findBranchRecord_(text) {
  var k = branchKey_(text);
  if (!k) return null;
  var recs = getBranchRecords_();
  for (var i = 0; i < recs.length; i++) if (branchKey_(recs[i].name) === k) return recs[i];
  return null;
}

/** Longest branch name that appears inside a free-text value such as a profile "এলাকা". */
function findBranchInText_(text) {
  var k = branchKey_(text);
  if (!k) return null;
  var best = null;
  getBranchRecords_().forEach(function (r) {
    var bk = branchKey_(r.name);
    if (bk.length >= 2 && k.indexOf(bk) !== -1 && (!best || bk.length > branchKey_(best.name).length)) best = r;
  });
  return best;
}

function isLegacyBranch_(text) {
  var k = branchKey_(text);
  return (CONFIG.LEGACY_BRANCHES || []).some(function (l) { return branchKey_(l) === k; });
}

function getDefaultBranchName_() {
  var saved = PropertiesService.getScriptProperties().getProperty('DEFAULT_BRANCH_NAME');
  var rec = saved ? findBranchRecord_(saved) : null;
  if (rec && rec.active) return rec.name;
  rec = findBranchRecord_(CONFIG.DEFAULT_BRANCH);
  if (rec && rec.active) return rec.name;
  var active = getActiveBranchNames_();
  return active.length ? active[0] : CONFIG.DEFAULT_BRANCH;
}

/**
 * The listed branch name for a value, the default branch when empty/legacy, or null when the value is
 * not a known branch. With requireActive = true a switched-off branch is refused (used when someone is
 * being assigned to a branch); reading existing records never needs it.
 */
function normalizeBranch(branch, requireActive) {
  branch = cleanText(branch);
  if (!branch) return getDefaultBranchName_();
  var rec = findBranchRecord_(branch);
  if (rec) return (requireActive && !rec.active) ? null : rec.name;
  if (isLegacyBranch_(branch)) return getDefaultBranchName_();
  return null;
}


// ---------------------------------------------------------------------------
// v81. MANAGER WORK LIMIT — a Manager only sees and works with customers of their OWN branch/village.
//      Admin is never limited. A customer counts as "in the branch" when their stored Branch matches,
//      or (for a customer left on the default branch) when their profile "এলাকা" names that village —
//      the same idea the quick-collection screen already uses.
// ---------------------------------------------------------------------------
function managerBranchName_(session) {
  if (!session || session.Role !== ROLES.MANAGER) return null;
  var me = findOneBy('Users', 'UserID', session.UserID);
  var b = me ? normalizeBranch(me.Branch) : null;
  if (!b) throw new Error('AUTH: আপনার শাখা/গ্রাম ঠিক করা নেই — অ্যাডমিনকে বলে শাখা নির্ধারণ করিয়ে নিন।');
  return b;
}

/** null for Admin/others (no limit); { branch, areaMap } for a Manager. Build once per request, reuse for every row. */
function managerScope_(session) {
  if (!session || session.Role !== ROLES.MANAGER) return null;
  var branch = managerBranchName_(session);
  var areaMap = {};
  try { readSheet('CustomerProfiles').forEach(function (p) { areaMap[p.UserID] = p.Area || ''; }); } catch (e) { /* profiles are optional */ }
  return { branch: branch, areaMap: areaMap };
}

function customerInBranch_(customer, branch, areaMap) {
  if (!customer) return false;
  var raw = normalizeBranch(customer.Branch);
  if (raw && raw === branch) return true;
  return effectiveBranchLabel_(customer.Branch, areaMap ? areaMap[customer.UserID] : '') === branch;
}

function inManagerScope_(scope, customer) {
  return !scope || customerInBranch_(customer, scope.branch, scope.areaMap);
}

/** Throws (caught by the caller's own try/catch) when a Manager touches a customer of another branch. No-op for Admin. */
function assertManagerCanServe_(session, customerOrId) {
  var scope = managerScope_(session);
  if (!scope) return;
  var customer = (customerOrId && typeof customerOrId === 'object') ? customerOrId : findOneBy('Users', 'UserID', String(customerOrId || ''));
  if (!inManagerScope_(scope, customer)) {
    logAudit(session.UserID, 'BRANCH_ACCESS_DENIED', 'অন্য শাখার গ্রাহকের তথ্য/এন্ট্রির চেষ্টা: ' +
      (customer ? (customer.Name + ' (' + customer.Phone + ', শাখা: ' + (normalizeBranch(customer.Branch) || '—') + ')') : String(customerOrId || '')));
    throw new Error('AUTH: এই গ্রাহক আপনার শাখা/গ্রামের (' + scope.branch + ') নন — শুধু নিজের শাখার গ্রাহকের কাজ করা যায়।');
  }
}

/** Rewrites the Branch column of Users in one go. decide(userObject) -> new text, or null to leave it. */
function rewriteUserBranches_(decide) {
  SHEET_MEMO = {};
  var raw = loadSheetRaw('Users');
  var ci = raw.headers.indexOf('Branch');
  if (ci === -1 || !raw.values.length) return 0;
  var changed = 0;
  var col = raw.values.map(function (row, i) {
    var nb = decide(rowToObject(raw.headers, row, i + 2));
    if (nb !== null && nb !== undefined && nb !== row[ci]) { changed++; return [nb]; }
    return [row[ci]];
  });
  if (changed) {
    getSheet('Users').getRange(2, ci + 1, col.length, 1).setValues(col);
    invalidateSheetMemo('Users');
  }
  return changed;
}

function cleanBranchName_(name) {
  name = cleanText(name);
  if (name.length < 2) return { error: 'নাম অন্তত ২ অক্ষরের দিন।' };
  if (name.length > MAX_BRANCH_NAME_LEN) return { error: 'নাম সর্বোচ্চ ' + MAX_BRANCH_NAME_LEN + ' অক্ষরের হতে পারবে।' };
  if (/[<>]/.test(name)) return { error: 'নামে < বা > চিহ্ন দেওয়া যাবে না।' };
  return { name: name };
}

/** Which branch a customer really belongs to for field work: the Branch they were given, unless that is only the
 *  automatic default / empty / unknown and their profile "এলাকা" names a listed village. */
function effectiveBranchLabel_(rawBranch, areaText) {
  var def = getDefaultBranchName_();
  var raw = cleanText(rawBranch);
  var rec = raw ? findBranchRecord_(raw) : null;
  if (!rec && raw && isLegacyBranch_(raw)) rec = findBranchRecord_(def);
  var area = cleanText(areaText);
  var areaRec = area ? (findBranchRecord_(area) || findBranchInText_(area)) : null;
  var weak = !raw || !rec || rec.name === def;
  if (areaRec && weak && (!rec || areaRec.name !== rec.name)) return areaRec.name;
  if (rec) return rec.name;
  return raw || 'শাখা দেওয়া নেই';
}

function branchUserCounts_() {
  var users = readSheet('Users');
  var def = getDefaultBranchName_();
  var counts = {};
  getBranchRecords_().forEach(function (r) { counts[branchKey_(r.name)] = { customers: 0, managers: 0 }; });
  var unmatched = {};
  users.forEach(function (u) {
    if (u.Role !== ROLES.CUSTOMER && u.Role !== ROLES.MANAGER) return;
    var raw = cleanText(u.Branch);
    var rec = raw ? findBranchRecord_(raw) : findBranchRecord_(def);
    if (!rec && raw && isLegacyBranch_(raw)) rec = findBranchRecord_(def);
    if (rec) {
      var c = counts[branchKey_(rec.name)];
      if (u.Role === ROLES.CUSTOMER) c.customers++; else c.managers++;
      return;
    }
    var key = raw || '(ফাঁকা)';
    if (!unmatched[key]) unmatched[key] = { text: raw, customers: 0, managers: 0 };
    if (u.Role === ROLES.CUSTOMER) unmatched[key].customers++; else unmatched[key].managers++;
  });
  return { counts: counts, unmatched: Object.keys(unmatched).map(function (k) { return unmatched[k]; }) };
}

/** Admin: the full branch list with member counts, plus any branch texts in the data that match no listed branch. */
function getBranchAdminList(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var info = branchUserCounts_();
    var def = getDefaultBranchName_();
    var rows = getBranchRecords_().map(function (r) {
      var c = info.counts[branchKey_(r.name)] || { customers: 0, managers: 0 };
      return { name: r.name, active: r.active, isDefault: r.name === def, customers: c.customers, managers: c.managers };
    });
    return ok({ branches: rows, unmatched: info.unmatched, defaultBranch: def });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function addBranch(token, name) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var cn = cleanBranchName_(name);
    if (cn.error) return fail(cn.error);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var recs = getBranchRecords_().slice();
    if (findBranchRecord_(cn.name)) return fail('এই নামে গ্রাম/শাখা আগে থেকেই আছে (বন্ধ থাকলে "চালু করুন" চাপুন)।');
    if (recs.length >= MAX_BRANCHES) return fail('সর্বোচ্চ ' + MAX_BRANCHES + 'টি গ্রাম/শাখা রাখা যাবে।');
    recs.push({ name: cn.name, active: true });
    saveBranchRecords_(recs);
    logAudit(session.UserID, 'BRANCH_ADDED', cn.name);
    return ok('"' + cn.name + '" যোগ হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Renames a branch everywhere: the list and every customer/manager who has it. */
function renameBranch(token, oldName, newName) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var cn = cleanBranchName_(newName);
    if (cn.error) return fail(cn.error);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var old = findBranchRecord_(oldName);
    if (!old) return fail('গ্রাম/শাখা খুঁজে পাওয়া যায়নি।');
    var clash = findBranchRecord_(cn.name);
    if (clash && branchKey_(clash.name) !== branchKey_(old.name)) return fail('এই নামে আরেকটি গ্রাম/শাখা আছে। দুটি এক করতে চাইলে সদস্যদের সরিয়ে পুরনোটি মুছুন।');
    var wasDefault = getDefaultBranchName_() === old.name;
    var oldKey = branchKey_(old.name);
    var recs = getBranchRecords_().map(function (r) { return branchKey_(r.name) === oldKey ? { name: cn.name, active: r.active } : r; });
    var moved = rewriteUserBranches_(function (u) {
      var raw = cleanText(u.Branch);
      return (raw && branchKey_(raw) === oldKey) ? cn.name : null;
    });
    saveBranchRecords_(recs);
    if (wasDefault) PropertiesService.getScriptProperties().setProperty('DEFAULT_BRANCH_NAME', cn.name);
    if (moved) syncCustomersSheet();
    logAudit(session.UserID, 'BRANCH_RENAMED', old.name + ' → ' + cn.name + ' (' + moved + ' জন)');
    return ok('নাম বদলেছে (' + moved + ' জনের শাখা হালনাগাদ হয়েছে)।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Switch a branch on/off. Off = hidden from new registrations and pickers, existing members stay. */
function setBranchActive(token, name, active) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var rec = findBranchRecord_(name);
    if (!rec) return fail('গ্রাম/শাখা খুঁজে পাওয়া যায়নি।');
    active = (active === true || active === 'true');
    if (!active) {
      if (getDefaultBranchName_() === rec.name) return fail('এটি ডিফল্ট শাখা। আগে অন্য শাখাকে ডিফল্ট করুন, তারপর এটি বন্ধ করুন।');
      if (getActiveBranchNames_().length <= 1) return fail('অন্তত একটি গ্রাম/শাখা চালু থাকতে হবে।');
    }
    var key = branchKey_(rec.name);
    saveBranchRecords_(getBranchRecords_().map(function (r) { return branchKey_(r.name) === key ? { name: r.name, active: active } : r; }));
    logAudit(session.UserID, active ? 'BRANCH_ENABLED' : 'BRANCH_DISABLED', rec.name);
    return ok(active ? 'চালু করা হয়েছে।' : 'বন্ধ করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

function setDefaultBranch(token, name) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var rec = findBranchRecord_(name);
    if (!rec) return fail('গ্রাম/শাখা খুঁজে পাওয়া যায়নি।');
    if (!rec.active) return fail('বন্ধ থাকা শাখাকে ডিফল্ট করা যায় না। আগে চালু করুন।');
    PropertiesService.getScriptProperties().setProperty('DEFAULT_BRANCH_NAME', rec.name);
    logAudit(session.UserID, 'BRANCH_DEFAULT_SET', rec.name);
    return ok('"' + rec.name + '" এখন ডিফল্ট শাখা।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

function moveBranch(token, name, direction) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var recs = getBranchRecords_().slice();
    var key = branchKey_(name), idx = -1;
    recs.forEach(function (r, i) { if (branchKey_(r.name) === key) idx = i; });
    if (idx === -1) return fail('গ্রাম/শাখা খুঁজে পাওয়া যায়নি।');
    var to = direction === 'up' ? idx - 1 : idx + 1;
    if (to < 0 || to >= recs.length) return ok('আর সরানো যাবে না।');
    var tmp = recs[idx]; recs[idx] = recs[to]; recs[to] = tmp;
    saveBranchRecords_(recs);
    logAudit(session.UserID, 'BRANCH_REORDERED', name + ' ' + direction);
    return ok('ক্রম বদলেছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Only a branch nobody belongs to can be deleted (otherwise their records would lose their village). */
function deleteBranch(token, name) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var rec = findBranchRecord_(name);
    if (!rec) return fail('গ্রাম/শাখা খুঁজে পাওয়া যায়নি।');
    if (getDefaultBranchName_() === rec.name) return fail('ডিফল্ট শাখা মোছা যায় না।');
    if (getBranchRecords_().length <= 1) return fail('অন্তত একটি গ্রাম/শাখা রাখতে হবে।');
    var c = branchUserCounts_().counts[branchKey_(rec.name)] || { customers: 0, managers: 0 };
    if (c.customers + c.managers > 0) return fail('এই শাখায় ' + c.customers + ' জন গ্রাহক ও ' + c.managers + ' জন ম্যানেজার আছেন। আগে তাদের অন্য শাখায় সরান, অথবা শুধু বন্ধ করে রাখুন।');
    var key = branchKey_(rec.name);
    saveBranchRecords_(getBranchRecords_().filter(function (r) { return branchKey_(r.name) !== key; }));
    logAudit(session.UserID, 'BRANCH_DELETED', rec.name);
    return ok('মুছে ফেলা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Moves everyone whose saved branch text is fromText (a spelling that matches no listed branch, or another branch) to toName. */
function reassignBranchUsers(token, fromText, toName) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    BRANCH_MEMO_ = null;
    var to = findBranchRecord_(toName);
    if (!to || !to.active) return fail('যে গ্রাম/শাখায় সরাবেন সেটি চালু থাকতে হবে।');
    var from = cleanText(fromText);
    var fromKey = branchKey_(from);
    if (fromKey === branchKey_(to.name)) return fail('একই শাখা বাছা হয়েছে।');
    var moved = rewriteUserBranches_(function (u) {
      if (u.Role !== ROLES.CUSTOMER && u.Role !== ROLES.MANAGER) return null;
      var raw = cleanText(u.Branch);
      if (!from) return raw ? null : to.name;      // "(ফাঁকা)" group
      return (raw && branchKey_(raw) === fromKey) ? to.name : null;
    });
    if (moved) { syncCustomersSheet(); try { invalidateAdminReportCache(); } catch (e) { /* optional */ } }
    logAudit(session.UserID, 'BRANCH_USERS_REASSIGNED', (from || '(ফাঁকা)') + ' → ' + to.name + ' (' + moved + ' জন)');
    return ok(moved + ' জনকে "' + to.name + '" শাখায় সরানো হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * Many customers were never given a branch and were silently put in the default one, while their real village sits in the
 * profile "এলাকা" field. apply=false only lists who would move; apply=true moves them.
 */
function syncBranchFromArea(token, apply) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    apply = (apply === true || apply === 'true');
    if (apply) waitLockFresh(lock, 30000);
    var profiles = {};
    readSheet('CustomerProfiles').forEach(function (p) { profiles[p.UserID] = p.Area || ''; });
    var def = getDefaultBranchName_();
    var plan = {}; // userId -> new branch
    var samples = [];
    readSheet('Users').forEach(function (u) {
      if (u.Role !== ROLES.CUSTOMER) return;
      var area = profiles[u.UserID];
      if (!area) return;
      var target = effectiveBranchLabel_(u.Branch, area);
      var current = normalizeBranch(u.Branch);
      var targetRec = findBranchRecord_(target);
      if (!targetRec || !targetRec.active) return;
      if (current !== null && current === targetRec.name) return;
      plan[u.UserID] = targetRec.name;
      if (samples.length < 15) samples.push({ name: u.Name, from: cleanText(u.Branch) || def, to: targetRec.name, area: area });
    });
    var count = Object.keys(plan).length;
    if (!apply) return ok({ count: count, samples: samples });
    var moved = count ? rewriteUserBranches_(function (u) { return plan[u.UserID] || null; }) : 0;
    if (moved) { syncCustomersSheet(); try { invalidateAdminReportCache(); } catch (e) { /* optional */ } }
    logAudit(session.UserID, 'BRANCH_SYNCED_FROM_AREA', moved + ' জন গ্রাহকের শাখা প্রোফাইলের এলাকা অনুযায়ী ঠিক করা হয়েছে');
    return ok({ count: moved, samples: [] });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * v70/v71 — কুইক সেভিংস কালেকশন: everything the "village -> customers -> amount" screen needs, in one call.
 * Only active customers who have at least one Active/AtRisk plan are listed. Each customer's village is
 * resolved with effectiveBranchLabel_() (Branch first, profile "এলাকা" when Branch is just the automatic default),
 * so nobody disappears because of a spelling/spacing difference. Deposits are saved by the existing logPayment().
 */
function getQuickCollectionData(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var me = findOneBy('Users', 'UserID', session.UserID);
    var qcScope = managerScope_(session);
    var users = readSheet('Users');
    var plans = readSheet('Plans');
    var todayStr = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd');

    var areaByUser = {};
    try { readSheet('CustomerProfiles').forEach(function (p) { areaByUser[p.UserID] = p.Area || ''; }); } catch (e) { /* profiles are optional */ }

    var plansByCustomer = {};
    plans.forEach(function (p) {
      if (p.Status !== PLAN_STATUS.ACTIVE && p.Status !== PLAN_STATUS.AT_RISK) return;
      var paidToday = false;
      if (p.LastDepositDate) {
        try { paidToday = Utilities.formatDate(new Date(p.LastDepositDate), CONFIG.TIMEZONE, 'yyyy-MM-dd') === todayStr; } catch (e) { paidToday = false; }
      }
      if (!plansByCustomer[p.CustomerID]) plansByCustomer[p.CustomerID] = [];
      plansByCustomer[p.CustomerID].push({
        PlanID: p.PlanID,
        Name: p.ItemOrGoalName,
        Installment: Number(p.InstallmentAmount) || 0,
        Frequency: p.SavingFrequency,
        Status: p.Status,
        PaidToday: paidToday
      });
    });

    var branches = getActiveBranchNames_();
    var customers = [];
    users.forEach(function (u) {
      if (u.Role !== ROLES.CUSTOMER || u.Status !== 'Active') return;
      if (!plansByCustomer[u.UserID]) return;
      if (!inManagerScope_(qcScope, u)) return;   // v81: ম্যানেজার শুধু নিজের শাখার গ্রাহক পাবে
      var branch = effectiveBranchLabel_(u.Branch, areaByUser[u.UserID]);
      if (branches.indexOf(branch) === -1) branches.push(branch); // switched-off or unknown village: still listed so nobody is lost
      customers.push({ UserID: u.UserID, Name: u.Name, Phone: u.Phone, Branch: branch, plans: plansByCustomer[u.UserID] });
    });
    customers.sort(function (a, b) { return String(a.Name).localeCompare(String(b.Name), 'bn'); });

    var myBranch = '';
    if (session.Role === ROLES.MANAGER && me) {
      var mb = normalizeBranch(me.Branch);
      myBranch = mb || '';
    }
    return ok({ generatedAt: new Date().toISOString(), branches: branches, myBranch: myBranch, customers: customers });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Decides which time a deposit is booked under. A deposit queued offline keeps
 * the time the manager actually took the money (so daily collection and cash
 * settlement land on the right day) — unless that time is in the future, older
 * than CONFIG.OFFLINE_MAX_AGE_DAYS, or falls on a day this manager has already
 * submitted a cash settlement for; then it is booked at the moment of syncing.
 */
function resolveTransactionTime(occurredAt, managerId) {
  var nowMs = new Date().getTime();
  var nowIso = new Date(nowMs).toISOString();
  if (!occurredAt) return { iso: nowIso, honored: false };

  var t = new Date(occurredAt).getTime();
  if (isNaN(t) || t > nowMs + 5 * 60000) return { iso: nowIso, honored: false };
  if (nowMs - t > CONFIG.OFFLINE_MAX_AGE_DAYS * DAY_MS) return { iso: nowIso, honored: false };

  var dateStr = dhakaDateStr(new Date(t));
  var closedDay = findOne('ManagerCashSettlements', function (s) {
    return s.ManagerID === managerId && s.SettlementDate === dateStr && s.Status !== 'Rejected';
  });
  if (closedDay) return { iso: nowIso, honored: false };

  return { iso: new Date(t).toISOString(), honored: true };
}

// ---------------------------------------------------------------------------
// 23. SEASONAL GOALS & CAMPAIGNS — Upgrade 12
// ---------------------------------------------------------------------------

function getTemplateByKey(key) {
  for (var i = 0; i < SEASONAL_TEMPLATES.length; i++) {
    if (SEASONAL_TEMPLATES[i].key === key) return SEASONAL_TEMPLATES[i];
  }
  return null;
}

/** Next date (12:00 Dhaka) on which the given month/day falls, today included. */
function nextOccurrenceOfMonthDay(month, day) {
  var year = Number(Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy'));
  var candidate = new Date(Date.UTC(year, month - 1, day, 6, 0, 0)); // 06:00 UTC = 12:00 Dhaka
  if (daysUntil(candidate) < 0) {
    candidate = new Date(Date.UTC(year + 1, month - 1, day, 6, 0, 0));
  }
  return candidate;
}

/**
 * The four seasonal goal templates for the customer's "new plan" screen.
 * If the Admin has set up a campaign for a season, its date and suggested
 * amount are used; otherwise the template's own default is shown (and Pohela
 * Boishakh, which never moves, always has a date).
 */
function getSeasonalTemplates(token) {
  try {
    requireRole(token, null);
    var campaigns = findAll('SeasonalCampaigns', function (c) { return c.Status === 'Active'; });

    var result = SEASONAL_TEMPLATES.map(function (t) {
      var upcoming = campaigns.filter(function (c) {
        var d = new Date(c.SeasonDate);
        return c.TemplateKey === t.key && !isNaN(d.getTime()) && daysUntil(d) >= 0;
      }).sort(function (a, b) {
        return new Date(a.SeasonDate) - new Date(b.SeasonDate);
      })[0];

      var seasonDate = null;
      var suggestedAmount = t.suggestedAmount;
      var title = t.label;
      var campaignId = '';

      if (upcoming) {
        seasonDate = new Date(upcoming.SeasonDate);
        suggestedAmount = Number(upcoming.SuggestedAmount) || t.suggestedAmount;
        title = upcoming.Title || t.label;
        campaignId = upcoming.CampaignID;
      } else if (t.defaultMonthDay) {
        seasonDate = nextOccurrenceOfMonthDay(t.defaultMonthDay.month, t.defaultMonthDay.day);
      }

      var daysLeft = seasonDate ? daysUntil(seasonDate) : null;
      var suggestedEndDate = '';
      if (seasonDate && daysLeft > 0) {
        // Suggest finishing a few days early so there is time to shop.
        var endMs = seasonDate.getTime() - CONFIG.SEASON_SAVE_BUFFER_DAYS * DAY_MS;
        if (endMs < new Date().getTime() + 2 * DAY_MS) endMs = seasonDate.getTime();
        suggestedEndDate = dhakaDateStr(new Date(endMs));
      }

      return {
        key: t.key,
        label: t.label,
        title: title,
        icon: t.icon,
        goalName: t.goalName,
        category: t.category,
        suggestedAmount: suggestedAmount,
        seasonDate: seasonDate ? dhakaDateStr(seasonDate) : '',
        daysLeft: daysLeft,
        suggestedEndDate: suggestedEndDate,
        campaignId: campaignId
      };
    });
    return ok(result);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Everything needed to decide who counts as an "inactive" customer, read once. */
function buildCampaignContext() {
  var users = readSheet('Users');
  var plans = readSheet('Plans');
  var txns = readSheet('Transactions');
  var reminders = readSheet('CampaignReminders');

  var lastDeposit = {};
  txns.forEach(function (t) {
    if (t.TxnType !== 'Deposit') return;
    var ts = new Date(t.Timestamp).getTime();
    if (isNaN(ts)) return;
    if (!lastDeposit[t.CustomerID] || ts > lastDeposit[t.CustomerID]) lastDeposit[t.CustomerID] = ts;
  });

  var plansByCustomer = {};
  plans.forEach(function (p) {
    if (!plansByCustomer[p.CustomerID]) plansByCustomer[p.CustomerID] = [];
    plansByCustomer[p.CustomerID].push(p);
  });

  var remindedSet = {};
  reminders.forEach(function (r) { remindedSet[r.CampaignID + '|' + r.CustomerID] = true; });

  return {
    customers: users.filter(function (u) { return u.Role === ROLES.CUSTOMER; }),
    lastDeposit: lastDeposit,
    plansByCustomer: plansByCustomer,
    remindedSet: remindedSet
  };
}

function hasOpenSeasonPlan(customerId, seasonKey, ctx) {
  var openStatuses = [PLAN_STATUS.ACTIVE, PLAN_STATUS.AT_RISK, PLAN_STATUS.PAUSED, PLAN_STATUS.PAUSE_REQUESTED];
  return (ctx.plansByCustomer[customerId] || []).some(function (p) {
    return p.SeasonKey === seasonKey && openStatuses.indexOf(p.Status) !== -1;
  });
}

function countCustomersSavingForSeason(seasonKey, ctx) {
  return ctx.customers.filter(function (u) { return hasOpenSeasonPlan(u.UserID, seasonKey, ctx); }).length;
}

/**
 * Inactive = an Active customer with no deposit for CONFIG.INACTIVE_DAYS days
 * (or, if they never deposited, registered more than that long ago), who is not
 * already saving toward this season and has not been reminded for this campaign.
 */
function getEligibleInactiveCustomers(campaign, ctx) {
  var nowMs = new Date().getTime();
  var thresholdMs = CONFIG.INACTIVE_DAYS * DAY_MS;
  return ctx.customers.filter(function (u) {
    if (u.Status !== 'Active') return false;
    if (hasOpenSeasonPlan(u.UserID, campaign.TemplateKey, ctx)) return false;
    if (ctx.remindedSet[campaign.CampaignID + '|' + u.UserID]) return false;
    var lastActivity = ctx.lastDeposit[u.UserID];
    if (!lastActivity) {
      var created = new Date(u.CreatedAt).getTime();
      lastActivity = isNaN(created) ? 0 : created;
    }
    return (nowMs - lastActivity) >= thresholdMs;
  });
}

/**
 * Admin creates a campaign for one season instance, e.g. "ঈদ 2027" on a given
 * date. Eid and Puja dates move every year, so the Admin sets them here.
 */
function createSeasonalCampaign(token, data) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    data = data || {};
    var tpl = getTemplateByKey(String(data.templateKey || ''));
    if (!tpl) return fail('মৌসুমের ধরন বেছে নিন।');

    var seasonDate = parseDateInputNoonDhaka(data.seasonDate);
    if (!seasonDate) return fail('মৌসুমের তারিখ দিন।');
    if (daysUntil(seasonDate) < 1) return fail('মৌসুমের তারিখ ভবিষ্যতে হতে হবে।');

    var amount = data.suggestedAmount ? Math.round(Number(data.suggestedAmount)) : tpl.suggestedAmount;
    if (isNaN(amount) || amount <= 0) return fail('সঠিক প্রস্তাবিত লক্ষ্যমাত্রা দিন।');

    var remindDays = data.reminderDaysBefore ? Math.round(Number(data.reminderDaysBefore)) : CONFIG.DEFAULT_REMINDER_DAYS_BEFORE;
    if (isNaN(remindDays) || remindDays < 1 || remindDays > 180) {
      return fail('রিমাইন্ডারের দিন ১ থেকে ১৮০-এর মধ্যে দিন।');
    }

    var dateStr = dhakaDateStr(seasonDate);
    var duplicate = findOne('SeasonalCampaigns', function (c) {
      var d = new Date(c.SeasonDate);
      return c.TemplateKey === tpl.key && c.Status === 'Active' && !isNaN(d.getTime()) && dhakaDateStr(d) === dateStr;
    });
    if (duplicate) return fail('এই মৌসুম ও তারিখের প্রচারণা আগেই তৈরি করা আছে।');

    var title = cleanText(data.title) || (tpl.label + ' ' + dateStr.substring(0, 4));
    var campaign = {
      CampaignID: generateId('CMP'),
      TemplateKey: tpl.key,
      Title: title,
      SeasonDate: seasonDate.toISOString(),
      SuggestedAmount: amount,
      ReminderDaysBefore: remindDays,
      Status: 'Active',
      LastReminderAt: '',
      ReminderCount: 0,
      CreatedAt: new Date().toISOString(),
      CreatedByUserID: session.UserID
    };
    appendRow('SeasonalCampaigns', campaign);
    logAudit(session.UserID, 'SEASONAL_CAMPAIGN_CREATED', title + ' — ' + dateStr);
    return ok({ campaignId: campaign.CampaignID, title: title });
  } catch (err) {
    Logger.log('Error in createSeasonalCampaign: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin's campaign list with, for each active one, how many customers a reminder would reach. */
function getSeasonalCampaigns(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var all = readSheet('SeasonalCampaigns');
    var ctx = buildCampaignContext();

    var rows = [];
    all.forEach(function (c) {
      var seasonDate = new Date(c.SeasonDate);
      if (isNaN(seasonDate.getTime())) return;
      var isActive = c.Status === 'Active';
      rows.push({
        campaignId: c.CampaignID,
        templateKey: c.TemplateKey,
        title: c.Title,
        seasonDate: dhakaDateStr(seasonDate),
        daysLeft: daysUntil(seasonDate),
        suggestedAmount: Number(c.SuggestedAmount || 0),
        reminderDaysBefore: Number(c.ReminderDaysBefore || CONFIG.DEFAULT_REMINDER_DAYS_BEFORE),
        status: c.Status,
        lastReminderAt: c.LastReminderAt || '',
        reminderCount: Number(c.ReminderCount || 0),
        eligibleCount: isActive ? getEligibleInactiveCustomers(c, ctx).length : 0,
        savingCount: isActive ? countCustomersSavingForSeason(c.TemplateKey, ctx) : 0
      });
    });

    var active = rows.filter(function (r) { return r.status === 'Active'; })
      .sort(function (a, b) { return a.seasonDate < b.seasonDate ? -1 : (a.seasonDate > b.seasonDate ? 1 : 0); });
    var closed = rows.filter(function (r) { return r.status !== 'Active'; })
      .sort(function (a, b) { return a.seasonDate < b.seasonDate ? 1 : (a.seasonDate > b.seasonDate ? -1 : 0); })
      .slice(0, 5);

    var templates = SEASONAL_TEMPLATES.map(function (t) {
      return { key: t.key, label: t.label, suggestedAmount: t.suggestedAmount };
    });
    return ok({ campaigns: active.concat(closed), templates: templates });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

function closeSeasonalCampaign(token, campaignId) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var campaign = findOneBy('SeasonalCampaigns', 'CampaignID', campaignId);
    if (!campaign) return fail('প্রচারণা খুঁজে পাওয়া যায়নি।');
    if (campaign.Status !== 'Active') return fail('এই প্রচারণা আগেই বন্ধ করা হয়েছে।');
    updateRow('SeasonalCampaigns', campaign._row, { Status: 'Closed' });
    logAudit(session.UserID, 'SEASONAL_CAMPAIGN_CLOSED', campaign.Title);
    return ok('প্রচারণা বন্ধ করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Sends the "season is coming" reminder to every eligible inactive customer of
 * one campaign. Each customer gets it at most once per campaign. Like every
 * SMS in this app it is written to SMSLogs (SentStatus "Simulated") until a
 * real gateway is connected.
 */
function sendCampaignReminders(campaign, actorId) {
  var tpl = getTemplateByKey(campaign.TemplateKey);
  var seasonDate = new Date(campaign.SeasonDate);
  var daysLeft = daysUntil(seasonDate);
  if (isNaN(seasonDate.getTime()) || daysLeft < 1) {
    return { sent: 0, expired: true };
  }

  var ctx = buildCampaignContext();
  var eligible = getEligibleInactiveCustomers(campaign, ctx);
  var nowIso = new Date().toISOString();

  var goalName = tpl ? tpl.goalName : 'আপনার লক্ষ্য';
  var label = tpl ? tpl.label : campaign.Title;
  var message = 'AmarSonchoy: ' + campaign.Title + ' আসছে, আর মাত্র ' + daysLeft + ' দিন বাকি। ' +
    goalName + ' মেটাতে এখনই অল্প অল্প জমা শুরু করুন — লগইন করে "' + label + '" টেমপ্লেট বেছে নিন।';

  var smsRows = [];
  var reminderRows = [];
  eligible.forEach(function (u) {
    smsRows.push({
      LogID: generateId('SMS'),
      CustomerPhone: u.Phone,
      MessageText: message,
      SentStatus: 'Simulated',
      Timestamp: nowIso
    });
    reminderRows.push({
      ReminderID: generateId('REM'),
      CampaignID: campaign.CampaignID,
      CustomerID: u.UserID,
      SentAt: nowIso
    });
  });
  appendRows('SMSLogs', smsRows);
  appendRows('CampaignReminders', reminderRows);

  updateRow('SeasonalCampaigns', campaign._row, {
    LastReminderAt: nowIso,
    ReminderCount: Number(campaign.ReminderCount || 0) + eligible.length
  });
  logAudit(actorId || '', 'SEASONAL_REMINDERS_SENT', campaign.Title + ' — ' + eligible.length + ' জন গ্রাহককে SMS');
  return { sent: eligible.length, expired: false };
}

/** Admin taps "রিমাইন্ডার পাঠান" on one campaign. */
function sendSeasonalReminders(token, campaignId) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    var campaign = findOneBy('SeasonalCampaigns', 'CampaignID', campaignId);
    if (!campaign) return fail('প্রচারণা খুঁজে পাওয়া যায়নি।');
    if (campaign.Status !== 'Active') return fail('এই প্রচারণা বন্ধ হয়ে গেছে।');

    var result = sendCampaignReminders(campaign, session.UserID);
    if (result.expired) return fail('মৌসুমের তারিখ পেরিয়ে গেছে, রিমাইন্ডার পাঠানো যাবে না।');
    return ok({ sent: result.sent });
  } catch (err) {
    Logger.log('Error in sendSeasonalReminders: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * Time-driven trigger target (installed by setupSeasonalReminderTrigger).
 * Once a campaign is within its ReminderDaysBefore window and no reminder has
 * gone out yet, sends it automatically. Campaigns whose date has passed are closed.
 */
function runSeasonalReminderCheck() {
  var lock = LockService.getScriptLock();
  try {
    try { waitLockFresh(lock, 30000); } catch (lockErr) { /* proceed best-effort */ }

    var campaigns = findAll('SeasonalCampaigns', function (c) { return c.Status === 'Active'; });
    var sentTotal = 0;
    campaigns.forEach(function (c) {
      var d = new Date(c.SeasonDate);
      if (isNaN(d.getTime())) return;
      var daysLeft = daysUntil(d);
      if (daysLeft < 0) {
        updateRow('SeasonalCampaigns', c._row, { Status: 'Closed' });
        return;
      }
      if (c.LastReminderAt) return;
      var windowDays = Number(c.ReminderDaysBefore || CONFIG.DEFAULT_REMINDER_DAYS_BEFORE);
      if (daysLeft >= 1 && daysLeft <= windowDays) {
        var result = sendCampaignReminders(c, '');
        sentTotal += result.sent;
      }
    });
    logAudit('', 'DAILY_SEASONAL_CHECK', campaigns.length + 'টি সক্রিয় প্রচারণা পরীক্ষা, ' + sentTotal + 'টি SMS');
  } catch (err) {
    Logger.log('Error in runSeasonalReminderCheck: ' + err);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// 24. REPORTS (CSV EXPORT) — Upgrade 13
// ---------------------------------------------------------------------------

function buildMonthlyCollectionReport() {
  var txns = readSheet('Transactions');
  var months = {};
  txns.forEach(function (t) {
    var d = new Date(t.Timestamp);
    if (isNaN(d.getTime())) return;
    var key = Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM');
    if (!months[key]) months[key] = { count: 0, total: 0, cash: 0, bkash: 0, nagad: 0, refund: 0, disputed: 0 };
    var m = months[key];
    var amount = Number(t.Amount || 0);

    if (t.TxnType === 'Refund') { m.refund += Math.abs(amount); return; }
    if (t.TxnType !== 'Deposit') return;
    if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return; // not real money yet
    if (t.CustomerConfirmed === 'No') { m.disputed += amount; return; }

    m.count += 1;
    m.total += amount;
    if (t.PaymentMethod === 'Cash') m.cash += amount;
    else if (t.PaymentMethod === 'bKash') m.bkash += amount;
    else if (t.PaymentMethod === 'Nagad') m.nagad += amount;
  });

  var rows = Object.keys(months).sort().map(function (key) {
    var m = months[key];
    return [key, m.count, m.total, m.cash, m.bkash, m.nagad, m.refund, m.total - m.refund, m.disputed];
  });
  return {
    slug: 'monthly_collection',
    headers: ['মাস', 'জমার সংখ্যা', 'মোট জমা (৳)', 'ক্যাশ/হাতে নগদ (৳)', 'বিকাশ (৳)', 'নগদ অ্যাপ (৳)',
              'ফেরত (৳)', 'নিট কালেকশন (৳)', 'আপত্তিকৃত জমা (৳)'],
    rows: rows
  };
}

function buildTopSaversReport(limit) {
  limit = Math.round(Number(limit));
  if (isNaN(limit) || limit < 1) limit = 50;
  if (limit > 1000) limit = 1000;

  var users = readSheet('Users');
  var plans = readSheet('Plans');
  var byCustomer = {};
  plans.forEach(function (p) {
    if (p.Status === PLAN_STATUS.REFUNDED) return; // money already returned
    if (!byCustomer[p.CustomerID]) byCustomer[p.CustomerID] = { saved: 0, bonus: 0, plans: 0, completed: 0 };
    var b = byCustomer[p.CustomerID];
    b.saved += Number(p.AccumulatedSavings || 0);
    b.bonus += Number(p.AccruedSavingsBonus || 0);
    b.plans += 1;
    if (p.Status === PLAN_STATUS.COMPLETED) b.completed += 1;
  });

  var list = [];
  users.forEach(function (u) {
    if (u.Role !== ROLES.CUSTOMER || !byCustomer[u.UserID]) return;
    var b = byCustomer[u.UserID];
    list.push({ user: u, b: b, total: b.saved + b.bonus });
  });
  list.sort(function (a, b) { return b.total - a.total; });

  var rows = list.slice(0, limit).map(function (item, i) {
    return [i + 1, item.user.Name, item.user.Phone, item.user.Branch || '', item.b.saved, item.b.bonus,
            item.total, item.b.plans, item.b.completed, item.user.Badge || '', Number(item.user.StreakCount || 0)];
  });
  return {
    slug: 'top_savers',
    headers: ['র‍্যাংক', 'নাম', 'মোবাইল', 'শাখা', 'মোট জমা (৳)', 'বোনাস (৳)', 'জমা+বোনাস (৳)',
              'প্ল্যান সংখ্যা', 'সম্পন্ন প্ল্যান', 'ব্যাজ', 'টানা জমা'],
    rows: rows
  };
}

/** "Risky" = flagged AtRisk, or auto-paused after missing installments. */
function buildAtRiskReport() {
  var users = readSheet('Users');
  var plans = readSheet('Plans');
  var risky = plans.filter(function (p) {
    if (p.Status === PLAN_STATUS.AT_RISK) return true;
    return p.Status === PLAN_STATUS.PAUSED && Number(p.MissedIntervalCount || 0) >= CONFIG.MISSED_AT_RISK_THRESHOLD;
  });
  risky.sort(function (a, b) { return Number(b.MissedIntervalCount || 0) - Number(a.MissedIntervalCount || 0); });

  var rows = risky.map(function (p) {
    var u = users.filter(function (x) { return x.UserID === p.CustomerID; })[0];
    var lastDeposit = p.LastDepositDate ? new Date(p.LastDepositDate) : null;
    return [
      u ? u.Name : '', u ? u.Phone : '', u ? (u.Branch || '') : '', p.ItemOrGoalName,
      p.Status === PLAN_STATUS.AT_RISK ? 'ঝুঁকিপূর্ণ' : 'কিস্তি মিসে বন্ধ',
      Number(p.InstallmentAmount), p.SavingFrequency, Number(p.MissedIntervalCount || 0),
      (lastDeposit && !isNaN(lastDeposit.getTime())) ? dhakaDateStr(lastDeposit) : '',
      Number(p.AccumulatedSavings || 0), Number(p.TargetAmount)
    ];
  });
  return {
    slug: 'at_risk_plans',
    headers: ['গ্রাহক', 'মোবাইল', 'শাখা', 'লক্ষ্য', 'অবস্থা', 'কিস্তি (৳)', 'ফ্রিকোয়েন্সি', 'মিস হয়েছে (বার)',
              'শেষ জমার তারিখ', 'জমা হয়েছে (৳)', 'লক্ষ্য (৳)'],
    rows: rows
  };
}

/**
 * Admin-only. reportType is "monthly", "topSavers" or "atRisk". The browser
 * turns the returned text into a downloadable .csv file.
 */
/** Turns a report type + options into a {slug, headers, rows} object, shared by CSV/PDF/Excel export. */
function buildReportByType(token, reportType, options) {
  options = options || {};
  if (reportType === 'monthly') return buildMonthlyCollectionReport();
  if (reportType === 'topSavers') return buildTopSaversReport(options.limit);
  if (reportType === 'atRisk') return buildAtRiskReport();

  if (reportType === 'branchComparison') {
    var res1 = getBranchComparisonStats(token);
    var rows1 = (res1.ok ? res1.data : []).map(function (b) {
      return [b.branch, b.activeCustomers, b.totalSaved, b.avgSavedPerCustomer, b.completedGoals, b.atRiskCount];
    });
    return {
      slug: 'branch_comparison',
      headers: ['শাখা', 'সক্রিয় গ্রাহক', 'মোট জমা (৳)', 'গড়/গ্রাহক (৳)', 'সম্পন্ন লক্ষ্য', 'ঝুঁকিপূর্ণ'],
      rows: rows1
    };
  }

  if (reportType === 'managerScorecard') {
    var res2 = getManagerScorecard(token);
    var rows2 = (res2.ok ? res2.data : []).map(function (m) {
      return [m.name, m.branch, m.achieved, m.target,
              m.achievementPercent === null ? '' : m.achievementPercent + '%',
              m.retentionPercent === null ? '' : m.retentionPercent + '%', m.avgDiscrepancy];
    });
    return {
      slug: 'manager_scorecard',
      headers: ['ম্যানেজার', 'শাখা', 'অর্জিত (৳)', 'টার্গেট (৳)', 'অর্জনের হার', 'ধরে রাখার হার', 'গড় গরমিল (৳)'],
      rows: rows2
    };
  }

  if (reportType === 'cohort') {
    var res3 = getCohortAnalysis(token);
    var rows3 = (res3.ok ? res3.data : []).map(function (c) {
      return [c.month, c.joined, c.active, c.retentionPercent === null ? '' : c.retentionPercent + '%'];
    });
    return { slug: 'cohort_retention', headers: ['মাস', 'যোগ দিয়েছেন', 'এখনো সক্রিয়', 'ধরে রাখার হার'], rows: rows3 };
  }

  if (reportType === 'auditLog') {
    var res4 = queryAuditLogs_(options.filters || {}, AUDIT_EXPORT_MAX_ROWS, 0);
    var rows4 = res4.rows.map(function (l) {
      return [Utilities.formatDate(new Date(l.timestamp), CONFIG.TIMEZONE, 'dd/MM/yyyy hh:mm a'), l.userName, l.userRole, l.category, l.action, l.details];
    });
    if (res4.total > AUDIT_EXPORT_MAX_ROWS) {
      rows4.push(['', '', '', '', 'সতর্কতা', 'মোট ' + res4.total + 'টি মিলেছে, শুধু সর্বশেষ ' + AUDIT_EXPORT_MAX_ROWS + 'টি রপ্তানি হয়েছে — তারিখের পরিসর ছোট করুন']);
    }
    return { slug: 'audit_log', headers: ['সময়', 'ব্যবহারকারী', 'ভূমিকা', 'ধরন', 'অ্যাকশন', 'বিস্তারিত'], rows: rows4 };
  }

  return null;
}

function exportReportCsv(token, reportType, options) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var report = buildReportByType(token, reportType, options);
    if (!report) return fail('রিপোর্টের ধরন সঠিক নয়।');

    var csv = buildCsv(report.headers, report.rows);
    var filename = 'amarsonchoy_' + report.slug + '_' + dhakaDateStr(new Date()) + '.csv';
    logAudit(session.UserID, 'REPORT_EXPORTED', report.slug + ' — ' + report.rows.length + ' সারি');
    return ok({ filename: filename, csv: csv, rowCount: report.rows.length });
  } catch (err) {
    Logger.log('Error in exportReportCsv: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Minimal HTML-escaping for the small amount of HTML built server-side (PDF reports). */
function escHtml(value) {
  return String(value === undefined || value === null ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Builds a clean, printable HTML table for a report — this is what gets converted to PDF. */
function buildReportHtml(title, report) {
  var headerHtml = report.headers.map(function (h) {
    return '<th style="border:1px solid #999;padding:5px 7px;background:#e8f5ef;text-align:left;">' + escHtml(h) + '</th>';
  }).join('');
  var rowsHtml = report.rows.map(function (r) {
    return '<tr>' + r.map(function (c) {
      return '<td style="border:1px solid #ccc;padding:4px 7px;">' + escHtml(c === null || c === undefined ? '' : c) + '</td>';
    }).join('') + '</tr>';
  }).join('') || '<tr><td colspan="' + report.headers.length + '" style="padding:10px;text-align:center;color:#999;">কোনো ডেটা নেই</td></tr>';

  return '<html><head><meta charset="UTF-8"><style>' +
    'body{font-family:"Noto Sans Bengali","Hind Siliguri","Arial",sans-serif;font-size:12px;color:#222;}' +
    'table{border-collapse:collapse;width:100%;margin-top:8px;}' +
    'h1{font-size:16px;margin-bottom:2px;} .meta{color:#666;font-size:11px;margin-bottom:10px;}' +
    '</style></head><body>' +
    '<h1>' + escHtml(CONFIG.APP_NAME) + ' — ' + escHtml(title) + '</h1>' +
    '<div class="meta">তৈরি হয়েছে: ' + Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'dd MMMM yyyy, hh:mm a') + ' | মোট সারি: ' + report.rows.length + '</div>' +
    '<table><thead><tr>' + headerHtml + '</tr></thead><tbody>' + rowsHtml + '</tbody></table>' +
    '</body></html>';
}

var REPORT_TITLES_BN = {
  monthly: 'মাসিক কালেকশন রিপোর্ট', topSavers: 'সেরা সঞ্চয়কারী রিপোর্ট', atRisk: 'ঝুঁকিপূর্ণ প্ল্যান রিপোর্ট',
  branchComparison: 'শাখা তুলনা রিপোর্ট', managerScorecard: 'ম্যানেজার স্কোরকার্ড', cohort: 'কোহোর্ট রিটেনশন রিপোর্ট',
  auditLog: 'অডিট লগ রিপোর্ট'
};

/** Same reports as CSV, but as a formatted, printable PDF. */
function exportReportPdf(token, reportType, options) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var report = buildReportByType(token, reportType, options);
    if (!report) return fail('রিপোর্টের ধরন সঠিক নয়।');

    var html = buildReportHtml(REPORT_TITLES_BN[reportType] || 'রিপোর্ট', report);
    var blob = HtmlService.createHtmlOutput(html).getBlob().getAs('application/pdf');
    var base64 = Utilities.base64Encode(blob.getBytes());
    var filename = 'amarsonchoy_' + report.slug + '_' + dhakaDateStr(new Date()) + '.pdf';
    logAudit(session.UserID, 'REPORT_EXPORTED_PDF', report.slug + ' — ' + report.rows.length + ' সারি');
    return ok({ filename: filename, base64: base64, rowCount: report.rows.length });
  } catch (err) {
    Logger.log('Error in exportReportPdf: ' + err);
    return fail('PDF তৈরি করতে সমস্যা হয়েছে: ' + err.message);
  }
}

/**
 * Same reports as CSV, but as a real .xlsx file: writes into a temporary
 * sheet, exports it through Google's own Sheets-export URL, then deletes the
 * temporary sheet again. Falls back to a friendly error (use CSV instead) if
 * the export URL isn't reachable for any reason — it never breaks the data.
 */
function exportReportXlsx(token, reportType, options) {
  var tempSheet = null;
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var report = buildReportByType(token, reportType, options);
    if (!report) return fail('রিপোর্টের ধরন সঠিক নয়।');

    var ss = getSS();
    tempSheet = ss.insertSheet('TEMP_EXPORT_' + new Date().getTime());
    var data = [report.headers].concat(report.rows.map(function (r) {
      return r.map(function (c) { return (c === null || c === undefined) ? '' : c; });
    }));
    tempSheet.getRange(1, 1, data.length, report.headers.length).setValues(data);
    tempSheet.getRange(1, 1, 1, report.headers.length).setFontWeight('bold').setBackground('#e8f5ef');
    tempSheet.setFrozenRows(1);
    SpreadsheetApp.flush();

    var url = 'https://docs.google.com/spreadsheets/d/' + CONFIG.SPREADSHEET_ID + '/export?format=xlsx&gid=' + tempSheet.getSheetId();
    var response = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
    ss.deleteSheet(tempSheet);
    tempSheet = null;

    if (response.getResponseCode() !== 200) {
      return fail('Excel ফাইল তৈরি করা যায়নি, এই মুহূর্তে CSV ব্যবহার করুন।');
    }
    var base64 = Utilities.base64Encode(response.getBlob().getBytes());
    var filename = 'amarsonchoy_' + report.slug + '_' + dhakaDateStr(new Date()) + '.xlsx';
    logAudit(session.UserID, 'REPORT_EXPORTED_XLSX', report.slug + ' — ' + report.rows.length + ' সারি');
    return ok({ filename: filename, base64: base64, rowCount: report.rows.length });
  } catch (err) {
    Logger.log('Error in exportReportXlsx: ' + err);
    try { if (tempSheet) getSS().deleteSheet(tempSheet); } catch (e2) { /* best-effort cleanup */ }
    return fail('Excel ফাইল তৈরি করতে সমস্যা হয়েছে, এই মুহূর্তে CSV ব্যবহার করুন।');
  }
}

// ---------------------------------------------------------------------------
// 25. AUTOMATIC GOOGLE DRIVE BACKUP — Upgrade 13
// ---------------------------------------------------------------------------

function getOrCreateBackupFolder() {
  var props = PropertiesService.getScriptProperties();
  var savedId = props.getProperty('BACKUP_FOLDER_ID');
  if (savedId) {
    try {
      var existing = DriveApp.getFolderById(savedId);
      if (!existing.isTrashed()) return existing;
    } catch (e) { /* folder was deleted — a fresh one is created below */ }
  }
  var folder = DriveApp.createFolder(CONFIG.BACKUP_FOLDER_NAME);
  props.setProperty('BACKUP_FOLDER_ID', folder.getId());
  return folder;
}

/** Backup copies inside the folder, newest first. Only files named like our backups are touched. */
function listBackupFiles(folder) {
  var files = [];
  var iterator = folder.getFiles();
  while (iterator.hasNext()) {
    var f = iterator.next();
    if (f.getName().indexOf(CONFIG.BACKUP_FILE_PREFIX) === 0) {
      files.push({ file: f, created: f.getDateCreated().getTime() });
    }
  }
  files.sort(function (a, b) { return b.created - a.created; });
  return files;
}

/**
 * Copies the whole spreadsheet into the backup folder, then moves any copy
 * beyond the newest CONFIG.BACKUP_KEEP_COPIES to the Drive trash.
 */
function performBackup(source) {
  var folder = getOrCreateBackupFolder();
  var stamp = Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd_HHmm');
  var fileName = CONFIG.BACKUP_FILE_PREFIX + stamp;
  DriveApp.getFileById(CONFIG.SPREADSHEET_ID).makeCopy(fileName, folder);

  var files = listBackupFiles(folder);
  var pruned = 0;
  for (var i = CONFIG.BACKUP_KEEP_COPIES; i < files.length; i++) {
    files[i].file.setTrashed(true);
    pruned++;
  }

  var props = PropertiesService.getScriptProperties();
  props.setProperty('LAST_BACKUP_AT', new Date().toISOString());
  props.setProperty('LAST_BACKUP_STATUS', 'OK');
  props.setProperty('LAST_BACKUP_ERROR', '');
  logAudit('', source === 'manual' ? 'BACKUP_MANUAL' : 'BACKUP_DAILY',
    fileName + ' — পুরনো ' + pruned + 'টি কপি সরানো হয়েছে');
  return { fileName: fileName, pruned: pruned, kept: Math.min(files.length, CONFIG.BACKUP_KEEP_COPIES) };
}

function recordBackupFailure(err) {
  var msg = String(err && err.message ? err.message : err).substring(0, 300);
  var props = PropertiesService.getScriptProperties();
  props.setProperty('LAST_BACKUP_STATUS', 'FAILED');
  props.setProperty('LAST_BACKUP_ERROR', msg);
  props.setProperty('LAST_BACKUP_ATTEMPT_AT', new Date().toISOString());
  logAudit('', 'BACKUP_FAILED', msg);
}

/** Time-driven trigger target (installed by setupBackupTrigger). */
function runDailyBackup() {
  var lock = LockService.getScriptLock();
  try {
    try { waitLockFresh(lock, 30000); } catch (lockErr) { /* proceed best-effort */ }
    performBackup('auto');
  } catch (err) {
    Logger.log('Error in runDailyBackup: ' + err);
    recordBackupFailure(err);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

function isTriggerInstalled(handlerName) {
  try {
    return ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === handlerName; });
  } catch (e) {
    return false;
  }
}

function getBackupStatus(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var props = PropertiesService.getScriptProperties();
    var copies = 0;
    var folderUrl = '';
    var folderId = props.getProperty('BACKUP_FOLDER_ID');
    if (folderId) {
      try {
        var folder = DriveApp.getFolderById(folderId);
        copies = listBackupFiles(folder).length;
        folderUrl = folder.getUrl();
      } catch (e) { /* folder not reachable — leave the counters at zero */ }
    }
    return ok({
      lastBackupAt: props.getProperty('LAST_BACKUP_AT') || '',
      lastStatus: props.getProperty('LAST_BACKUP_STATUS') || 'NEVER',
      lastError: props.getProperty('LAST_BACKUP_ERROR') || '',
      copies: copies,
      keep: CONFIG.BACKUP_KEEP_COPIES,
      folderName: CONFIG.BACKUP_FOLDER_NAME,
      folderUrl: folderUrl,
      triggerInstalled: isTriggerInstalled('runDailyBackup'),
      monthlyTriggerInstalled: isTriggerInstalled('runMonthlyReport'),
      monthlyLastYm: props.getProperty('LAST_MONTHLY_REPORT_YM') || '',
      monthlyLastAt: props.getProperty('LAST_MONTHLY_REPORT_AT') || '',
      monthlyLastTo: props.getProperty('LAST_MONTHLY_REPORT_TO') || '',
      monthlyLastError: props.getProperty('LAST_MONTHLY_REPORT_ERROR') || '',
      monthlyRecipient: getReportRecipient_()
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin taps "এখনই ব্যাকআপ নিন". */
function runBackupNow(token) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    var result = performBackup('manual');
    logAudit(session.UserID, 'BACKUP_REQUESTED', result.fileName);
    return ok({ fileName: result.fileName, pruned: result.pruned });
  } catch (err) {
    Logger.log('Error in runBackupNow: ' + err);
    if (String(err.message).indexOf('AUTH:') !== 0) recordBackupFailure(err);
    return fail(String(err.message).indexOf('AUTH:') === 0
      ? err.message.replace('AUTH: ', '')
      : 'ব্যাকআপ নেওয়া যায়নি: ' + err.message);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// BULK CUSTOMER IMPORT — from an Excel/CSV file or pasted notebook list
// ---------------------------------------------------------------------------
var IMPORT_MAX_ROWS_PER_CALL = 200;

/** "০১৭১২-৩৪৫৬৭৮", "+8801712345678", "1712345678" → "01712345678" (anything else is returned cleaned, for validation to reject). */
function normalizeImportPhone_(raw) {
  var bn = '০১২৩৪৫৬৭৮৯';
  var s = String(raw === null || raw === undefined ? '' : raw).replace(/[০-৯]/g, function (c) { return String(bn.indexOf(c)); });
  s = s.replace(/[^0-9]/g, '');
  if (s.indexOf('880') === 0 && s.length === 13) s = s.substring(2);
  if (s.length === 10 && s.charAt(0) === '1') s = '0' + s;
  return s;
}

function normalizeImportPin_(raw) {
  var bn = '০১২৩৪৫৬৭৮৯';
  var s = String(raw === null || raw === undefined ? '' : raw).replace(/[০-৯]/g, function (c) { return String(bn.indexOf(c)); }).replace(/[^0-9]/g, '');
  if (s.length > 0 && s.length < 4) s = ('0000' + s).slice(-4); // Excel drops leading zeros (0123 → 123)
  return s;
}

/**
 * Validates (dryRun = true) or actually creates (dryRun = false) a batch of
 * customers. rows: [{name, phone, pin, branch, area, address, shop}].
 * - Missing PIN → a random temporary PIN is generated and the customer must
 *   change it at first login; those PINs are returned ONCE so the manager can
 *   hand them over.
 * - Phones that already exist (or repeat inside the batch) are skipped, never overwritten.
 * Customers are added to the manager's own branch unless the row names a valid branch.
 */
function importCustomers(token, rows, termsAccepted, dryRun) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    if (!rows || !rows.length) return fail('ইম্পোর্ট করার মতো কোনো সারি নেই।');
    if (rows.length > IMPORT_MAX_ROWS_PER_CALL) return fail('একবারে সর্বোচ্চ ' + IMPORT_MAX_ROWS_PER_CALL + 'টি সারি পাঠানো যাবে।');
    if (!dryRun && !isTermsAccepted(termsAccepted)) return fail('গ্রাহকদের শর্তাবলীতে সম্মতির ঘরে টিক দিন।');

    if (!dryRun) waitLockFresh(lock, 30000);

    var creator = findOneBy('Users', 'UserID', session.UserID);
    var defaultBranch = normalizeBranch((creator && creator.Branch) || '') || getDefaultBranchName_();

    var allUsers = readSheet('Users');
    var phones = {}, refCodes = {};
    allUsers.forEach(function (u) { phones[String(u.Phone)] = true; if (u.ReferralCode) refCodes[u.ReferralCode] = true; });

    var results = [], newUsers = [], newProfiles = [], now = new Date().toISOString();
    var usedIds = {};
    var okCount = 0, errorCount = 0;

    rows.forEach(function (row, i) {
      var name = cleanText(row.name);
      var phone = normalizeImportPhone_(row.phone);
      var pinGiven = normalizeImportPin_(row.pin);
      var res = { index: i, name: name, phone: phone, status: 'ok', message: '', pin: '', generatedPin: false };
      var err = '';
      var branch = defaultBranch;

      if (!name) err = 'নাম নেই';
      else if (!/^01[0-9]{9}$/.test(phone)) err = 'মোবাইল নম্বর সঠিক নয়';
      else if (phones[phone]) err = 'এই নম্বরে আগে থেকেই অ্যাকাউন্ট আছে (বা ফাইলে দুবার আছে)';
      else if (pinGiven && !/^[0-9]{4}$/.test(pinGiven)) err = 'PIN ৪ ডিজিটের হতে হবে';
      else if (cleanText(row.branch)) {
        var nb = normalizeBranch(row.branch);
        if (nb === null) err = 'শাখা সঠিক নয়: ' + cleanText(row.branch);
        else if (session.Role === ROLES.MANAGER && nb !== defaultBranch) err = 'আপনি শুধু নিজের শাখার (' + defaultBranch + ') গ্রাহক যোগ করতে পারেন';   // v81
        else branch = nb;
      }

      if (err) { res.status = 'error'; res.message = err; errorCount++; results.push(res); return; }

      phones[phone] = true; // later rows with the same number are duplicates
      okCount++;
      if (!dryRun) {
        var pin = pinGiven, generated = false;
        if (!pin) { pin = generateTempPin_(); generated = true; }
        var id;
        do { id = generateId('USR'); } while (usedIds[id]);
        usedIds[id] = true;
        var code, tries = 0;
        do { code = generateReferralCode(phone); tries++; } while (tries < 8 && refCodes[code]);
        refCodes[code] = true;
        newUsers.push({
          UserID: id, Name: name, Phone: phone, PIN: pin, Role: ROLES.CUSTOMER, Status: 'Active',
          FailedLoginAttempts: 0, LockedUntil: '', CreatedAt: now, Badge: '', StreakCount: 0,
          ReferralCode: code, ReferredByUserID: '', ReferralBonusAwarded: 'No', Branch: branch,
          TermsAcceptedAt: now, MustChangePIN: generated ? 'Yes' : ''
        });
        var area = cleanText(row.area), address = cleanText(row.address), shop = cleanText(row.shop);
        if (area || address || shop) {
          newProfiles.push({ UserID: id, Address: address, ShopName: shop, Area: area, UpdatedAt: now });
        }
        res.pin = generated ? pin : '';
        res.generatedPin = generated;
        res.message = 'যোগ হয়েছে';
      } else {
        res.message = 'ঠিক আছে';
      }
      results.push(res);
    });

    if (!dryRun && newUsers.length) {
      appendRows('Users', newUsers);
      appendRows('CustomerProfiles', newProfiles);
      logAudit(session.UserID, 'CUSTOMERS_IMPORTED', newUsers.length + ' জন গ্রাহক ইম্পোর্ট (বাদ ' + errorCount + 'টি সারি)');
      syncCustomersSheet();
    }
    return ok({ results: results, okCount: okCount, errorCount: errorCount, dryRun: !!dryRun });
  } catch (err) {
    Logger.log('Error in importCustomers: ' + err);
    var msg = String(err.message || err);
    return fail(msg.indexOf('AUTH:') === 0 ? msg.replace('AUTH: ', '') : 'ইম্পোর্ট করা যায়নি: ' + msg);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// MONTHLY REPORT E-MAIL — PDF + Excel on the 1st of every month
// ---------------------------------------------------------------------------

function getReportRecipient_() {
  var to = cleanText(CONFIG.REPORT_EMAIL);
  if (to) return to;
  try { return Session.getEffectiveUser().getEmail() || ''; } catch (e) { return ''; }
}

/** Everything the report shows for one month (ym = 'yyyy-MM'). */
function buildMonthlyReportData_(ym) {
  var prevYm = ymAdd(ym, -1);
  var users = readSheet('Users');
  var usersById = {};
  users.forEach(function (u) { usersById[u.UserID] = u; });

  var inMonth = [];
  var prevDeposits = 0;
  readSheet('Transactions').forEach(function (t) {
    var d = new Date(t.Timestamp);
    if (isNaN(d.getTime())) return;
    var m = profitYm(d);
    if (m === ym) inMonth.push(t);
    else if (m === prevYm && t.TxnType === 'Deposit') prevDeposits += Number(t.Amount) || 0;
  });
  inMonth.sort(function (a, b) { return new Date(a.Timestamp) - new Date(b.Timestamp); });

  var r = {
    ym: ym, label: profitMonthLabel(ym),
    depositTotal: 0, depositCount: 0, withdrawalTotal: 0, withdrawalCount: 0, refundTotal: 0, refundCount: 0,
    prevDepositTotal: prevDeposits,
    byMethod: {}, byManager: {}, byBranch: {}, byDay: {}, txRows: []
  };
  var plansById = {};
  readSheet('Plans').forEach(function (p) { plansById[p.PlanID] = p; });

  inMonth.forEach(function (t) {
    var amt = Number(t.Amount) || 0;
    var customer = usersById[t.CustomerID];
    var mgr = usersById[t.VerifiedByManagerID];
    if (t.TxnType === 'Deposit') {
      r.depositTotal += amt; r.depositCount++;
      r.byMethod[t.PaymentMethod || 'Cash'] = (r.byMethod[t.PaymentMethod || 'Cash'] || 0) + amt;
      var mName = mgr ? mgr.Name : '(অনলাইন/অজানা)';
      var mo = r.byManager[mName] || (r.byManager[mName] = { total: 0, count: 0 });
      mo.total += amt; mo.count++;
      var br = customer ? (normalizeBranch(customer.Branch) || getDefaultBranchName_()) : '—';
      var bo = r.byBranch[br] || (r.byBranch[br] = { total: 0, count: 0 });
      bo.total += amt; bo.count++;
      var day = profitDay(new Date(t.Timestamp));
      r.byDay[day] = (r.byDay[day] || 0) + amt;
    } else if (t.TxnType === 'Withdrawal') { r.withdrawalTotal += amt; r.withdrawalCount++; }
    else if (t.TxnType === 'Refund') { r.refundTotal += amt; r.refundCount++; }
    var plan = plansById[t.PlanID];
    r.txRows.push([
      profitDay(new Date(t.Timestamp)), Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'HH:mm'),
      customer ? customer.Name : '', customer ? customer.Phone : '', plan ? plan.ItemOrGoalName : '',
      t.TxnType, t.PaymentMethod || '', amt, mgr ? mgr.Name : '', t.TxnID
    ]);
  });

  r.newCustomers = users.filter(function (u) {
    if (u.Role !== ROLES.CUSTOMER || !u.CreatedAt) return false;
    var d = new Date(u.CreatedAt);
    return !isNaN(d.getTime()) && profitYm(d) === ym;
  }).length;

  // Snapshot of plans as of when the report is built
  var plans = readSheet('Plans');
  r.planCounts = {};
  r.totalSaved = 0;
  plans.forEach(function (p) {
    r.planCounts[p.Status] = (r.planCounts[p.Status] || 0) + 1;
    r.totalSaved += Number(p.AccumulatedSavings) || 0;
  });
  r.planTotal = plans.length;

  var sets = readSheet('ManagerCashSettlements').filter(function (x) { return String(x.SettlementDate).substring(0, 7) === ym && x.Status !== 'Rejected'; });
  r.settlementCount = sets.length;
  r.settlementDiscrepancy = sets.reduce(function (sum, x) { return sum + Math.abs(Number(x.Discrepancy) || 0); }, 0);
  r.settlementPending = sets.filter(function (x) { return x.Status === 'Pending'; }).length;
  return r;
}

var REPORT_METHOD_LABEL_ = { Cash: 'নগদ (হাতে)', bKash: 'বিকাশ', Nagad: 'নগদ (Nagad)' };
var REPORT_PLAN_LABEL_ = { Active: 'চলমান', Completed: 'সম্পন্ন', Paused: 'বিরতিতে', Refunded: 'ফেরত', RefundRequested: 'ফেরতের আবেদন', PauseRequested: 'বিরতির আবেদন', AtRisk: 'ঝুঁকিতে' };

/** Writes the report into a temporary Google Sheet; returns the Spreadsheet. */
function buildReportSpreadsheet_(r) {
  var ss = SpreadsheetApp.create(CONFIG.APP_NAME + ' মাসিক রিপোর্ট ' + r.ym);
  var growth = r.prevDepositTotal > 0 ? Math.round((r.depositTotal - r.prevDepositTotal) / r.prevDepositTotal * 100) + '%' : '—';
  var rows = [
    [CONFIG.APP_NAME + ' — মাসিক রিপোর্ট', ''],
    [r.label, ''],
    ['', ''],
    ['মোট জমা (টাকা)', r.depositTotal],
    ['জমার সংখ্যা', r.depositCount],
    ['আগের মাসের জমা', r.prevDepositTotal],
    ['আগের মাসের তুলনায় পরিবর্তন', growth],
    ['মোট উত্তোলন (টাকা)', r.withdrawalTotal],
    ['উত্তোলনের সংখ্যা', r.withdrawalCount],
    ['ফেরত (টাকা)', r.refundTotal],
    ['নিট জমা (জমা − উত্তোলন − ফেরত)', r.depositTotal - r.withdrawalTotal - r.refundTotal],
    ['নতুন গ্রাহক', r.newCustomers],
    ['', ''],
    ['মাধ্যম অনুযায়ী জমা', '']
  ];
  Object.keys(r.byMethod).forEach(function (m) { rows.push(['  ' + (REPORT_METHOD_LABEL_[m] || m), r.byMethod[m]]); });
  rows.push(['', ''], ['শাখা অনুযায়ী জমা', '']);
  Object.keys(r.byBranch).forEach(function (b) { rows.push(['  ' + b + ' (' + r.byBranch[b].count + 'টি)', r.byBranch[b].total]); });
  rows.push(['', ''], ['ম্যানেজার অনুযায়ী জমা', '']);
  Object.keys(r.byManager).sort(function (a, b) { return r.byManager[b].total - r.byManager[a].total; })
    .forEach(function (n) { rows.push(['  ' + n + ' (' + r.byManager[n].count + 'টি)', r.byManager[n].total]); });
  rows.push(['', ''], ['ক্যাশ হিসাব (ম্যানেজার)', ''],
    ['  জমা দেওয়া হিসাব', r.settlementCount],
    ['  অপেক্ষমাণ', r.settlementPending],
    ['  মোট গরমিল (টাকা)', r.settlementDiscrepancy]);
  rows.push(['', ''], ['প্ল্যানের অবস্থা (রিপোর্ট তৈরির সময়ে)', ''], ['  মোট প্ল্যান', r.planTotal]);
  Object.keys(r.planCounts).forEach(function (st) { rows.push(['  ' + (REPORT_PLAN_LABEL_[st] || st), r.planCounts[st]]); });
  rows.push(['  সব প্ল্যানের মোট সঞ্চয় (টাকা)', r.totalSaved]);

  var sum = ss.getSheets()[0];
  sum.setName('সারসংক্ষেপ');
  sum.getRange(1, 1, rows.length, 2).setValues(rows);
  sum.getRange(1, 1).setFontSize(16).setFontWeight('bold').setFontColor('#0e7c5f');
  sum.getRange(2, 1).setFontSize(12).setFontColor('#555555');
  rows.forEach(function (row, i) {
    if (row[1] === '' && row[0] && row[0].charAt(0) !== ' ' && i > 2) sum.getRange(i + 1, 1, 1, 2).setFontWeight('bold').setBackground('#e8f4f0');
  });
  sum.getRange(4, 2, rows.length - 3, 1).setHorizontalAlignment('right').setNumberFormat('#,##0');
  sum.setColumnWidth(1, 330); sum.setColumnWidth(2, 130);

  var daily = ss.insertSheet('দৈনিক জমা');
  var days = Object.keys(r.byDay).sort().map(function (d) { return [d, r.byDay[d]]; });
  daily.getRange(1, 1, 1, 2).setValues([['তারিখ', 'জমা (টাকা)']]).setFontWeight('bold').setBackground('#e8f4f0');
  if (days.length) daily.getRange(2, 1, days.length, 2).setValues(days);
  daily.getRange(2, 2, Math.max(days.length, 1), 1).setNumberFormat('#,##0');
  daily.setColumnWidth(1, 120); daily.setColumnWidth(2, 130);

  var tx = ss.insertSheet('লেনদেন');
  var head = ['তারিখ', 'সময়', 'গ্রাহক', 'মোবাইল', 'প্ল্যান', 'ধরন', 'মাধ্যম', 'টাকা', 'ম্যানেজার', 'লেনদেন আইডি'];
  tx.getRange(1, 1, 1, head.length).setValues([head]).setFontWeight('bold').setBackground('#e8f4f0');
  if (r.txRows.length) {
    tx.getRange(2, 1, r.txRows.length, head.length).setNumberFormat('@').setValues(r.txRows);
    tx.getRange(2, 8, r.txRows.length, 1).setNumberFormat('#,##0');
  }
  tx.setFrozenRows(1);
  SpreadsheetApp.flush();
  return ss;
}

function exportSpreadsheetBlob_(ssId, query, filename) {
  var url = 'https://docs.google.com/spreadsheets/d/' + ssId + '/export?' + query;
  var res = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() }, muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw new Error('এক্সপোর্ট ব্যর্থ (' + res.getResponseCode() + ')');
  return res.getBlob().setName(filename);
}

/** Builds the report for `ym` and e-mails it (PDF summary + Excel with every transaction). */
function sendMonthlyReport_(ym, to) {
  if (!to) throw new Error('ইমেইল ঠিকানা পাওয়া যায়নি — CONFIG.REPORT_EMAIL-এ ঠিকানা দিন।');
  var r = buildMonthlyReportData_(ym);
  var ss = buildReportSpreadsheet_(r);
  var base = 'AmarSonchoy_Monthly_' + ym;
  try {
    var summaryGid = ss.getSheetByName('সারসংক্ষেপ').getSheetId();
    var xlsx = exportSpreadsheetBlob_(ss.getId(), 'format=xlsx', base + '.xlsx');
    var pdf = exportSpreadsheetBlob_(ss.getId(),
      'format=pdf&gid=' + summaryGid + '&size=A4&portrait=true&fitw=true&gridlines=false&printtitle=false&sheetnames=false&pagenum=UNDEFINED',
      base + '.pdf');
    var growth = r.prevDepositTotal > 0 ? Math.round((r.depositTotal - r.prevDepositTotal) / r.prevDepositTotal * 100) : null;
    var fmt = function (n) { return '৳' + Number(n || 0).toLocaleString('en-US'); };
    var html = '<div style="font-family:Arial,sans-serif;max-width:520px;">' +
      '<h2 style="color:#0e7c5f;margin:0 0 4px;">' + CONFIG.APP_NAME + ' — ' + r.label + '</h2>' +
      '<p style="color:#666;margin:0 0 14px;">মাসিক রিপোর্ট</p>' +
      '<table style="width:100%;border-collapse:collapse;font-size:15px;">' +
      '<tr><td style="padding:6px 0;">মোট জমা</td><td style="text-align:right;font-weight:bold;color:#0e7c5f;">' + fmt(r.depositTotal) + ' (' + r.depositCount + 'টি)</td></tr>' +
      (growth !== null ? '<tr><td style="padding:6px 0;">আগের মাসের তুলনায়</td><td style="text-align:right;">' + (growth >= 0 ? '+' : '') + growth + '%</td></tr>' : '') +
      '<tr><td style="padding:6px 0;">উত্তোলন</td><td style="text-align:right;">' + fmt(r.withdrawalTotal) + '</td></tr>' +
      '<tr><td style="padding:6px 0;">নিট জমা</td><td style="text-align:right;font-weight:bold;">' + fmt(r.depositTotal - r.withdrawalTotal - r.refundTotal) + '</td></tr>' +
      '<tr><td style="padding:6px 0;">নতুন গ্রাহক</td><td style="text-align:right;">' + r.newCustomers + ' জন</td></tr>' +
      '<tr><td style="padding:6px 0;">ক্যাশ গরমিল</td><td style="text-align:right;">' + fmt(r.settlementDiscrepancy) + '</td></tr>' +
      '</table>' +
      '<p style="color:#666;font-size:13px;margin-top:16px;">সংযুক্ত: PDF (সারসংক্ষেপ) ও Excel (সারসংক্ষেপ, দৈনিক জমা, প্রতিটি লেনদেন)।</p>' +
      '</div>';
    MailApp.sendEmail({
      to: to,
      subject: CONFIG.APP_NAME + ' মাসিক রিপোর্ট — ' + r.label,
      htmlBody: html,
      body: CONFIG.APP_NAME + ' মাসিক রিপোর্ট — ' + r.label + '\nমোট জমা: ' + fmt(r.depositTotal) + ' (' + r.depositCount + 'টি)\nউত্তোলন: ' + fmt(r.withdrawalTotal),
      attachments: [pdf, xlsx],
      name: CONFIG.APP_NAME
    });
  } finally {
    try { DriveApp.getFileById(ss.getId()).setTrashed(true); } catch (e) { /* temp file already gone */ }
  }
  var props = PropertiesService.getScriptProperties();
  props.setProperty('LAST_MONTHLY_REPORT_YM', ym);
  props.setProperty('LAST_MONTHLY_REPORT_AT', new Date().toISOString());
  props.setProperty('LAST_MONTHLY_REPORT_TO', to);
  props.deleteProperty('LAST_MONTHLY_REPORT_ERROR');
  return { ym: ym, label: r.label, to: to, depositTotal: r.depositTotal, depositCount: r.depositCount };
}

/** Time-driven (setupMonthlyReportTrigger): sends LAST month's report once. */
function runMonthlyReport() {
  var lock = LockService.getScriptLock();
  try {
    waitLockFresh(lock, 30000);
    var ym = ymAdd(profitYm(new Date()), -1);
    if (PropertiesService.getScriptProperties().getProperty('LAST_MONTHLY_REPORT_YM') === ym) return; // already sent
    sendMonthlyReport_(ym, getReportRecipient_());
  } catch (err) {
    Logger.log('runMonthlyReport failed: ' + err);
    PropertiesService.getScriptProperties().setProperty('LAST_MONTHLY_REPORT_ERROR', String(err.message || err));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Admin taps "গত মাসের রিপোর্ট এখনই পাঠান" (which = 'last') or "চলতি মাস (এ পর্যন্ত)" (which = 'current'). */
function sendMonthlyReportNow(token, which) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    waitLockFresh(lock, 30000);
    var thisYm = profitYm(new Date());
    var ym = which === 'current' ? thisYm : ymAdd(thisYm, -1);
    var result = sendMonthlyReport_(ym, getReportRecipient_());
    logAudit(session.UserID, 'MONTHLY_REPORT_SENT', ym + ' → ' + result.to);
    return ok(result);
  } catch (err) {
    Logger.log('Error in sendMonthlyReportNow: ' + err);
    var msg = String(err.message || err);
    if (msg.indexOf('AUTH:') === 0) return fail(msg.replace('AUTH: ', ''));
    PropertiesService.getScriptProperties().setProperty('LAST_MONTHLY_REPORT_ERROR', msg);
    return fail('রিপোর্ট পাঠানো যায়নি: ' + msg);
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// 26. MANAGER PERFORMANCE LEADERBOARD — Upgrade 13
// ---------------------------------------------------------------------------

/**
 * Ranks every active Manager by the money they collected in the chosen period
 * ("week" = last 7 days, "month" = this calendar month, "all"). Refunds and
 * deposits the customer disputed do not count. Managers and Admin can both
 * see it; only the Admin also sees the cash-settlement accuracy column.
 */
function getManagerLeaderboard(token, period) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    if (['week', 'month', 'all'].indexOf(period) === -1) period = 'month';

    var now = new Date();
    var monthKey = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yyyy-MM');
    var weekStartMs = now.getTime() - 7 * DAY_MS;

    var managers = findAll('Users', function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; });
    var stats = {};
    managers.forEach(function (m) { stats[m.UserID] = { amount: 0, count: 0, customers: {} }; });

    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var s = stats[t.VerifiedByManagerID];
      if (!s) return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      if (period === 'month' && Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM') !== monthKey) return;
      if (period === 'week' && d.getTime() < weekStartMs) return;
      s.amount += Number(t.Amount || 0);
      s.count += 1;
      s.customers[t.CustomerID] = true;
    });

    var accuracy = {};
    if (session.Role === ROLES.ADMIN) {
      readSheet('ManagerCashSettlements').forEach(function (s) {
        if (s.Status !== 'Approved') return;
        if (!accuracy[s.ManagerID]) accuracy[s.ManagerID] = { total: 0, exact: 0 };
        accuracy[s.ManagerID].total += 1;
        if (Number(s.Discrepancy) === 0) accuracy[s.ManagerID].exact += 1;
      });
    }

    var rows = managers.map(function (m) {
      var s = stats[m.UserID];
      var a = accuracy[m.UserID];
      return {
        managerId: m.UserID,
        name: m.Name,
        branch: m.Branch || '',
        collectedAmount: s.amount,
        depositCount: s.count,
        customersServed: Object.keys(s.customers).length,
        settlementAccuracyPercent: (session.Role === ROLES.ADMIN && a && a.total > 0)
          ? Math.round((a.exact / a.total) * 100) : null,
        isYou: m.UserID === session.UserID
      };
    });
    rows.sort(function (x, y) {
      if (y.collectedAmount !== x.collectedAmount) return y.collectedAmount - x.collectedAmount;
      return y.depositCount - x.depositCount;
    });
    rows.forEach(function (r, i) { r.rank = i + 1; });

    return ok({ period: period, rows: rows });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 27. ARCHIVING OLD PLANS & BRANCH MANAGEMENT — Upgrade 14
// ---------------------------------------------------------------------------

/** A closed plan's "age" is counted from its last deposit (or its start date if it never had one). */
function planClosedReferenceMs(plan) {
  var ms = new Date(plan.LastDepositDate || plan.StartDate).getTime();
  return isNaN(ms) ? 0 : ms;
}

function isArchivableStatus(status) {
  return status === PLAN_STATUS.COMPLETED || status === PLAN_STATUS.REFUNDED;
}

function findArchivablePlans(days) {
  var cutoff = new Date().getTime() - days * DAY_MS;
  return findAll('Plans', function (p) {
    if (p.ArchivedAt) return false;
    if (!isArchivableStatus(p.Status)) return false;
    var ref = planClosedReferenceMs(p);
    return ref > 0 && ref <= cutoff;
  });
}

/**
 * Customer hides one of their own finished plans (Completed/Refunded) from the
 * main list, or brings it back. Nothing is deleted — the money history and the
 * printable passbook stay available.
 */
function archivePlan(token, planId, archive) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var plan = findOne('Plans', function (p) { return p.PlanID === planId && p.CustomerID === session.UserID; });
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');

    if (archive) {
      if (!isArchivableStatus(plan.Status)) return fail('শুধুমাত্র সম্পন্ন বা ফেরত দেওয়া প্ল্যান আর্কাইভ করা যায়।');
      if (plan.ArchivedAt) return fail('প্ল্যানটি আগেই আর্কাইভ করা আছে।');
      updateRow('Plans', plan._row, { ArchivedAt: new Date().toISOString() });
      logAudit(session.UserID, 'PLAN_ARCHIVED', planId);
      return ok('প্ল্যান আর্কাইভ করা হয়েছে।');
    }

    if (!plan.ArchivedAt) return fail('প্ল্যানটি আর্কাইভে নেই।');
    updateRow('Plans', plan._row, { ArchivedAt: '' });
    logAudit(session.UserID, 'PLAN_UNARCHIVED', planId);
    return ok('প্ল্যান আর্কাইভ থেকে ফিরিয়ে আনা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Admin archives every finished plan older than the given number of days in one go. */
function archiveOldCompletedPlans(token, days) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    days = Math.round(Number(days));
    if (isNaN(days) || days < 1) days = CONFIG.ARCHIVE_AFTER_DAYS;
    waitLockFresh(lock, 30000);

    var plans = findArchivablePlans(days);
    var nowIso = new Date().toISOString();
    plans.forEach(function (p) { updateRow('Plans', p._row, { ArchivedAt: nowIso }); });
    logAudit(session.UserID, 'PLANS_ARCHIVED_BULK', plans.length + 'টি প্ল্যান (' + days + ' দিনের পুরনো)');
    invalidateAdminReportCache();
    return ok({ archived: plans.length });
  } catch (err) {
    Logger.log('Error in archiveOldCompletedPlans: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Admin moves a customer or manager to another branch. */
function updateUserBranch(token, userId, branch) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var normalized = normalizeBranch(branch, true);
    if (normalized === null) return fail('শাখা সঠিক নয়।');
    var user = findOneBy('Users', 'UserID', userId);
    if (!user) return fail('ইউজার খুঁজে পাওয়া যায়নি।');
    updateRow('Users', user._row, { Branch: normalized });
    logAudit(session.UserID, 'USER_BRANCH_CHANGED', userId + ' → ' + normalized);
    if (user.Role === ROLES.CUSTOMER) syncCustomersSheet();
    return ok('শাখা আপডেট হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 28. PAYMENT SETTINGS (bKash / Nagad merchant number) — Upgrade 15
//     Stored in PropertiesService (not CONFIG) so the Admin can change them
//     from inside the app without ever opening the code.
// ---------------------------------------------------------------------------

var PAYMENT_TYPES = ['Personal', 'Agent', 'Merchant'];

var MAX_BKASH_ACCOUNTS = 6;

/**
 * bKash can now have several receiving numbers (for example two Merchant
 * numbers plus a Personal one). They are stored as one JSON list in
 * BKASH_ACCOUNTS. The first account is also mirrored into the old single
 * BKASH_NUMBER / BKASH_TYPE / BKASH_QR_URL properties so nothing that still
 * reads those keeps breaking, and a deployment that only has the old keys
 * simply shows them as account #1.
 */
function readBkashAccounts_(props) {
  var list = [];
  var raw = props.getProperty('BKASH_ACCOUNTS');
  if (raw) {
    try {
      var parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        list = parsed.filter(function (a) { return a && a.number; }).map(function (a) {
          return { label: String(a.label || ''), number: String(a.number), type: String(a.type || ''), qrUrl: String(a.qrUrl || '') };
        });
      }
    } catch (e) { list = []; }
  } else if (props.getProperty('BKASH_NUMBER')) {
    list = [{
      label: '',
      number: props.getProperty('BKASH_NUMBER'),
      type: props.getProperty('BKASH_TYPE') || '',
      qrUrl: props.getProperty('BKASH_QR_URL') || ''
    }];
  }
  return list.slice(0, MAX_BKASH_ACCOUNTS);
}

function getPaymentSettingsInternal() {
  var props = PropertiesService.getScriptProperties();
  var bkash = readBkashAccounts_(props);
  var first = bkash[0] || { number: '', type: '', qrUrl: '' };
  return {
    bkashAccounts: bkash,
    bkashNumber: first.number,
    bkashType: first.type,
    bkashQrUrl: first.qrUrl,
    nagadNumber: props.getProperty('NAGAD_NUMBER') || '',
    nagadType: props.getProperty('NAGAD_TYPE') || '',
    nagadQrUrl: props.getProperty('NAGAD_QR_URL') || ''
  };
}

/** Drive folder (link-shared view only) that holds the uploaded bKash/Nagad QR pictures. */
function getOrCreatePaymentQrFolder() {
  var props = PropertiesService.getScriptProperties();
  var savedId = props.getProperty('PAYMENT_QR_FOLDER_ID');
  if (savedId) {
    try { return DriveApp.getFolderById(savedId); } catch (e) { /* folder was deleted, make a new one below */ }
  }
  var folder = DriveApp.createFolder(CONFIG.APP_NAME + ' - পেমেন্ট QR');
  props.setProperty('PAYMENT_QR_FOLDER_ID', folder.getId());
  return folder;
}

/**
 * Admin uploads the real bKash/Nagad QR picture straight from the phone/computer.
 * The picture is stored in Drive and its public view link is returned; the link is
 * only attached to a payment number when the Admin presses "সংরক্ষণ করুন".
 * This app never generates a QR itself — it only keeps the picture you give it.
 */
function uploadPaymentQr(token, base64Data, mimeType) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    if (!base64Data) return fail('কোনো ছবি পাওয়া যায়নি।');
    if (base64Data.length > 7000000) return fail('ছবির সাইজ অনেক বড়, একটু ছোট করে আবার চেষ্টা করুন।');
    var mime = String(mimeType || 'image/png');
    if (mime.indexOf('image/') !== 0) return fail('শুধু ছবি (JPG/PNG) আপলোড করা যাবে।');
    var ext = mime === 'image/png' ? 'png' : (mime === 'image/webp' ? 'webp' : 'jpg');
    var blob = Utilities.newBlob(Utilities.base64Decode(base64Data), mime, 'payment-qr-' + Date.now() + '.' + ext);
    var file = getOrCreatePaymentQrFolder().createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    logAudit(session.UserID, 'PAYMENT_QR_UPLOADED', file.getId());
    return ok({ url: 'https://drive.google.com/uc?export=view&id=' + file.getId() });
  } catch (err) {
    Logger.log('Error in uploadPaymentQr: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin sets the bKash/Nagad number customers should send money to before
 * reporting a payment in the app. Leaving a number blank simply hides that
 * payment method's "অনলাইনে জমা দিন" option for customers until it is filled
 * in. qrUrl is optional and is NEVER generated by this app — it is the link of
 * the picture the Admin uploaded with uploadPaymentQr (the official QR bKash/Nagad
 * gave the business).
 */
function updatePaymentSettings(token, data) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    data = data || {};

    function checkNumber(n) {
      n = String(n || '').trim();
      if (!n) return { ok: true, value: '' };
      return { ok: /^01[0-9]{9}$/.test(n), value: n };
    }
    function checkType(t) {
      t = String(t || '').trim();
      if (!t) return { ok: true, value: '' };
      return { ok: PAYMENT_TYPES.indexOf(t) !== -1, value: t };
    }
    function checkUrl(u) {
      u = String(u || '').trim();
      if (!u) return { ok: true, value: '' };
      return { ok: /^https:\/\//.test(u), value: u };
    }

    // bKash: a list of accounts. An older client that still sends the single
    // bkashNumber/bkashType/bkashQrUrl fields is treated as a list of one.
    var rawList = Array.isArray(data.bkashAccounts) ? data.bkashAccounts : [{
      label: '', number: data.bkashNumber, type: data.bkashType, qrUrl: data.bkashQrUrl
    }];
    var bkashAccounts = [];
    var seenNumbers = {};
    for (var i = 0; i < rawList.length; i++) {
      var row = rawList[i] || {};
      var num = checkNumber(row.number);
      var typ = checkType(row.type);
      var qr = checkUrl(row.qrUrl);
      var label = String(row.label || '').trim().substring(0, 30);
      if (!num.value && !label && !typ.value && !qr.value) continue; // completely empty row — ignore
      if (!num.ok) return fail('বিকাশ #' + (i + 1) + ': সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (01 দিয়ে শুরু)।');
      if (!num.value) return fail('বিকাশ #' + (i + 1) + ': নম্বর দিন, অথবা লাইনটি মুছে ফেলুন।');
      if (!typ.ok) return fail('বিকাশ #' + (i + 1) + ': পেমেন্টের ধরন সঠিক নয়।');
      if (!typ.value) return fail('বিকাশ #' + (i + 1) + ': নম্বরের ধরন (পার্সোনাল/এজেন্ট/মার্চেন্ট) বেছে নিন।');
      if (!qr.ok) return fail('বিকাশ #' + (i + 1) + ': QR ছবির লিংক অবশ্যই https:// দিয়ে শুরু হতে হবে।');
      if (seenNumbers[num.value]) return fail('বিকাশ নম্বর ' + num.value + ' দুইবার দেওয়া হয়েছে।');
      seenNumbers[num.value] = true;
      bkashAccounts.push({ label: label, number: num.value, type: typ.value, qrUrl: qr.value });
    }
    if (bkashAccounts.length > MAX_BKASH_ACCOUNTS) return fail('সর্বোচ্চ ' + MAX_BKASH_ACCOUNTS + 'টি বিকাশ নম্বর দেওয়া যাবে।');

    var nagadNumber = checkNumber(data.nagadNumber);
    var nagadType = checkType(data.nagadType);
    var nagadQrUrl = checkUrl(data.nagadQrUrl);

    if (!nagadNumber.ok) return fail('নগদ: সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (01 দিয়ে শুরু)।');
    if (!nagadType.ok) return fail('পেমেন্টের ধরন সঠিক নয়।');
    if (!nagadQrUrl.ok) return fail('QR ছবির লিংক অবশ্যই https:// দিয়ে শুরু হতে হবে।');
    if (nagadNumber.value && !nagadType.value) return fail('নগদ নম্বরের ধরন বেছে নিন।');

    var props = PropertiesService.getScriptProperties();
    props.setProperty('BKASH_ACCOUNTS', JSON.stringify(bkashAccounts));
    // keep the old single-number keys in step with account #1
    var firstAcc = bkashAccounts[0] || { number: '', type: '', qrUrl: '' };
    props.setProperty('BKASH_NUMBER', firstAcc.number);
    props.setProperty('BKASH_TYPE', firstAcc.type);
    props.setProperty('BKASH_QR_URL', firstAcc.qrUrl);
    props.setProperty('NAGAD_NUMBER', nagadNumber.value);
    props.setProperty('NAGAD_TYPE', nagadType.value);
    props.setProperty('NAGAD_QR_URL', nagadQrUrl.value);

    logAudit(session.UserID, 'PAYMENT_SETTINGS_UPDATED',
      'বিকাশ: ' + (bkashAccounts.map(function (a) { return a.number + ' (' + a.type + (a.label ? ', ' + a.label : '') + ')'; }).join('; ') || 'নেই') +
      ' · নগদ: ' + (nagadNumber.value || 'নেই') + (nagadType.value ? ' (' + nagadType.value + ')' : ''));
    return ok('পেমেন্ট সেটিংস সংরক্ষণ করা হয়েছে।');
  } catch (err) {
    Logger.log('Error in updatePaymentSettings: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 29. ONLINE PAYMENT CLAIMS (customer self-reported bKash/Nagad deposits) — Upgrade 15
//     The customer sends money themselves, then reports the transaction ID
//     here. Nothing is added to the plan until a Manager/Admin checks their
//     real bKash/Nagad statement and approves it — this app has no bKash/
//     Nagad API access and cannot verify a transaction ID by itself.
// ---------------------------------------------------------------------------

/**
 * v82. One TrxID = one deposit, ever.
 * The ID is cleaned before it is compared or stored: spaces/invisible characters removed, Bengali digits turned
 * into English digits, capital letters. So "8n7a b2cd9x", "8N7AB2CD9X" and " ৮N7AB2CD9X " are the SAME ID.
 * Returns { ok:true, id } or { ok:false, message }.
 */
function normalizeTrxId_(raw) {
  var s = String(raw == null ? '' : raw).replace(/[\s\u200b\u200c\u200d\u2060\ufeff]/g, '');
  var bn = '০১২৩৪৫৬৭৮৯';
  s = s.replace(/[০-৯]/g, function (d) { return String(bn.indexOf(d)); });
  if (!/^[A-Za-z0-9]{6,20}$/.test(s)) {
    return { ok: false, message: 'ট্রানজেকশন আইডি (TrxID) সঠিক নয় — SMS-এর আইডিটি হুবহু লিখুন (শুধু ইংরেজি অক্ষর ও সংখ্যা, ৬–২০ ঘর)।' };
  }
  return { ok: true, id: s.toUpperCase() };
}

/**
 * The earlier entry that already uses this TrxID, or null. A claim the SAME customer made earlier and that was
 * rejected/cancelled does not block them from sending it again (e.g. they fixed a wrong amount); everything else does.
 */
function findTrxIdConflict_(normId, customerId, excludeTxnId) {
  var hit = null;
  findAll('Transactions', function (t) {
    if (!t.TrxID_Receipt || t.TxnID === excludeTxnId) return false;
    var other = normalizeTrxId_(t.TrxID_Receipt);
    return other.ok && other.id === normId;
  }).forEach(function (t) {
    if (t.ClaimStatus === 'Rejected' && customerId && t.CustomerID === customerId) return;
    if (!hit || t.ClaimStatus === 'Approved' || !t.ClaimStatus) hit = t;
  });
  return hit;
}

function trxConflictMessage_(t) {
  var when = '';
  try { when = Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'dd/MM/yyyy'); } catch (e) { when = ''; }
  if (t.ClaimStatus === 'PendingVerification') return 'এই ট্রানজেকশন আইডি দিয়ে একটি জমার দাবি ইতিমধ্যে যাচাইয়ের অপেক্ষায় আছে।';
  if (t.ClaimStatus === 'Rejected') return 'এই ট্রানজেকশন আইডি আগেই ব্যবহার করা হয়েছিল — আবার ব্যবহার করা যাবে না।';
  return 'এই ট্রানজেকশন আইডি দিয়ে ইতিমধ্যে জমা নেওয়া হয়েছে' + (when ? ' (' + when + ')' : '') + ' — একই আইডি দুইবার ব্যবহার করা যায় না।';
}

/** Checks + logs. Returns a fail() envelope when blocked, otherwise null. Call it INSIDE the script lock, right before saving. */
function blockDuplicateTrxId_(session, normId, customerId, excludeTxnId) {
  var hit = findTrxIdConflict_(normId, customerId, excludeTxnId);
  if (!hit) return null;
  var holder = findOneBy('Users', 'UserID', hit.CustomerID);
  logAudit(session.UserID, 'DUPLICATE_TRXID_BLOCKED',
    'TrxID ' + normId + ' আগেই ব্যবহৃত (লেনদেন ' + hit.TxnID + ', গ্রাহক: ' + (holder ? holder.Name : hit.CustomerID) + ', অবস্থা: ' + (hit.ClaimStatus || 'নিশ্চিত জমা') + ')');
  return fail(trxConflictMessage_(hit));
}

function trxIdAlreadyUsed(trxId) {
  var n = normalizeTrxId_(trxId);
  return n.ok ? !!findTrxIdConflict_(n.id, '', '') : false;
}

/** Deposits that count as real, settled money — not a still-pending or rejected online claim. */
function countConfirmedDeposits(customerId, excludeTxnId) {
  return findAll('Transactions', function (t) {
    if (t.CustomerID !== customerId || t.TxnType !== 'Deposit') return false;
    if (excludeTxnId && t.TxnID === excludeTxnId) return false;
    return t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected';
  });
}

/**
 * Everything that happens to a Plan (and the customer's badge/streak/referral
 * bonus) once a deposit is treated as real money received. Shared by
 * logPayment (a Manager logging a deposit immediately) and
 * verifyOnlinePaymentClaim (an Admin/Manager approving a customer's online
 * payment claim later) so both follow the exact same rules. Does NOT touch
 * the Transaction row itself — the caller does that, since one case creates a
 * new row and the other updates an existing one.
 */
function applyDepositEffects(plan, amount, effectiveTimestampIso, isFirstDepositEver) {
  var newTotal = Math.round(Number(plan.AccumulatedSavings || 0)) + amount;
  var bonusSoFar = Number(plan.AccruedSavingsBonus || 0);
  var wasAtRisk = plan.Status === PLAN_STATUS.AT_RISK;
  var missedAtDepositTime = Number(plan.MissedIntervalCount || 0);

  var prevLastDepositMs = plan.LastDepositDate ? new Date(plan.LastDepositDate).getTime() : 0;
  if (isNaN(prevLastDepositMs)) prevLastDepositMs = 0;
  var planUpdates = {
    AccumulatedSavings: newTotal,
    LastDepositDate: new Date(effectiveTimestampIso).getTime() > prevLastDepositMs ? effectiveTimestampIso : plan.LastDepositDate,
    MissedIntervalCount: 0
  };
  if (wasAtRisk) planUpdates.Status = PLAN_STATUS.ACTIVE;

  var customer = findOneBy('Users', 'UserID', plan.CustomerID);
  var milestoneMsg = '';
  var referralMsg = '';
  var extraBonus = 0;

  if (customer) {
    var prevStreak = Number(customer.StreakCount || 0);
    var newStreak = missedAtDepositTime > 0 ? 1 : prevStreak + 1;
    var userUpdates = { StreakCount: newStreak };
    STREAK_MILESTONES.forEach(function (m) {
      if (newStreak === m.count) {
        extraBonus += m.bonus;
        userUpdates.Badge = m.badge;
        milestoneMsg = ' অভিনন্দন! টানা ' + m.count + ' বার নিয়মিত জমার জন্য আপনি "' + m.badge +
          '" ব্যাজ ও ৳' + m.bonus + ' বোনাস পেয়েছেন।';
      }
    });
    updateRow('Users', customer._row, userUpdates);
  }

  if (isFirstDepositEver && customer && customer.ReferredByUserID && customer.ReferralBonusAwarded !== 'Yes') {
    var referrer = findOneBy('Users', 'UserID', customer.ReferredByUserID);
    if (referrer) {
      extraBonus += CONFIG.REFERRAL_BONUS_AMOUNT;
      referralMsg = ' রেফারেল বোনাস ৳' + CONFIG.REFERRAL_BONUS_AMOUNT + ' যোগ হয়েছে।';
      var referrerPlan = findOne('Plans', function (p) {
        return p.CustomerID === referrer.UserID &&
          (p.Status === PLAN_STATUS.ACTIVE || p.Status === PLAN_STATUS.AT_RISK);
      });
      if (referrerPlan) {
        updateRow('Plans', referrerPlan._row, {
          AccruedSavingsBonus: Number(referrerPlan.AccruedSavingsBonus || 0) + CONFIG.REFERRAL_BONUS_AMOUNT
        });
      }
      logSms(referrer.Phone, 'AmarSonchoy: আপনার রেফারেল কোডে যোগ দেওয়া গ্রাহক প্রথম জমা দিয়েছেন। আপনি ৳' +
        CONFIG.REFERRAL_BONUS_AMOUNT + ' বোনাস পেয়েছেন।');
      updateRow('Users', customer._row, { ReferralBonusAwarded: 'Yes' });
    }
  }

  if (extraBonus > 0) {
    bonusSoFar = bonusSoFar + extraBonus;
    planUpdates.AccruedSavingsBonus = bonusSoFar;
  }

  var justCompleted = false;
  if ((newTotal + bonusSoFar) >= Number(plan.TargetAmount)) {
    planUpdates.Status = PLAN_STATUS.COMPLETED;
    justCompleted = true;
  }
  updateRow('Plans', plan._row, planUpdates);

  var progressPercent = Math.min(100, Math.round(((newTotal + bonusSoFar) / Number(plan.TargetAmount)) * 100));

  if (customer) {
    var msg = 'AmarSonchoy: আপনার "' + plan.ItemOrGoalName + '" প্ল্যানে ' + amount +
      ' টাকা জমা হয়েছে। বর্তমান ব্যালেন্স ' + newTotal + ' টাকা (+ ' + bonusSoFar +
      ' টাকা বোনাস), অগ্রগতি ' + progressPercent + '%।' + milestoneMsg + referralMsg;
    if (justCompleted) msg += ' অভিনন্দন, আপনার লক্ষ্য পূরণ হয়েছে!';
    logSms(customer.Phone, msg);
  }

  return { newTotal: newTotal, bonusSoFar: bonusSoFar, progressPercent: progressPercent, justCompleted: justCompleted };
}

/**
 * Customer reports a bKash/Nagad payment they already sent to the number in
 * Payment Settings. The amount is NOT added to the plan yet — it only moves
 * once a Manager or Admin checks the real bKash/Nagad statement and approves
 * it (verifyOnlinePaymentClaim).
 */
function submitOnlinePaymentClaim(token, planId, paymentMethod, amount, trxIdReceipt, paidToNumber) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    if (paymentMethod !== 'bKash' && paymentMethod !== 'Nagad') return fail('পেমেন্টের ধরন সঠিক নয়।');
    amount = Math.round(Number(amount));
    if (!amount || amount <= 0) return fail('সঠিক পরিমাণ দিন।');
    trxIdReceipt = cleanText(trxIdReceipt);
    if (!trxIdReceipt) return fail('ট্রানজেকশন আইডি (TrxID) দিন — এটি ' + paymentMethod + '-এর SMS-এ পাবেন।');
    var trxNorm = normalizeTrxId_(trxIdReceipt);   // v82
    if (!trxNorm.ok) return fail(trxNorm.message);
    trxIdReceipt = trxNorm.id;

    // Which of the Admin's receiving numbers the customer sent money to (bKash can have several).
    paidToNumber = String(paidToNumber || '').trim();
    if (paymentMethod === 'bKash') {
      var accounts = getPaymentSettingsInternal().bkashAccounts || [];
      if (accounts.length === 0) return fail('এই মুহূর্তে বিকাশ চালু নেই।');
      if (!paidToNumber) {
        paidToNumber = accounts.length === 1 ? accounts[0].number : '';
        if (!paidToNumber) return fail('কোন বিকাশ নম্বরে টাকা পাঠিয়েছেন তা বেছে নিন।');
      } else if (!accounts.some(function (a) { return a.number === paidToNumber; })) {
        return fail('এই বিকাশ নম্বরটি আর চালু নেই। তালিকা থেকে সঠিক নম্বর বেছে নিন।');
      }
    } else {
      paidToNumber = '';
    }

    waitLockFresh(lock, 30000);

    var plan = findOne('Plans', function (p) { return p.PlanID === planId && p.CustomerID === session.UserID; });
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (plan.Status !== PLAN_STATUS.ACTIVE && plan.Status !== PLAN_STATUS.AT_RISK) {
      return fail('এই প্ল্যানটি সক্রিয় নেই।');
    }
    var trxBlock = blockDuplicateTrxId_(session, trxIdReceipt, session.UserID, '');   // v82
    if (trxBlock) return trxBlock;

    var nowIso = new Date().toISOString();
    var txn = {
      TxnID: generateId('TXN'),
      PlanID: planId,
      CustomerID: session.UserID,
      Amount: amount,
      PaymentMethod: paymentMethod,
      TrxID_Receipt: trxIdReceipt,
      VerifiedByManagerID: '',
      CustomerConfirmed: 'N/A',
      TxnType: 'Deposit',
      Timestamp: nowIso,
      SettledInSettlementID: '',
      ClientRefID: '',
      SyncedAt: '',
      ClaimStatus: 'PendingVerification',
      ClaimedAt: nowIso,
      VerificationNote: '',
      PaidToNumber: paidToNumber
    };
    appendRow('Transactions', txn);
    logAudit(session.UserID, 'ONLINE_PAYMENT_CLAIMED',
      amount + ' টাকা ' + paymentMethod + (paidToNumber ? ' (' + paidToNumber + ' নম্বরে)' : '') + ' দাবি জমা, প্ল্যান ' + planId + ' (TrxID: ' + trxIdReceipt + ')');

    return ok({ txnId: txn.TxnID });
  } catch (err) {
    Logger.log('Error in submitOnlinePaymentClaim: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Customer withdraws a claim they made by mistake, while it is still pending. */
function cancelOnlinePaymentClaim(token, txnId) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var txn = findOne('Transactions', function (t) {
      return t.TxnID === txnId && t.CustomerID === session.UserID && t.ClaimStatus === 'PendingVerification';
    });
    if (!txn) return fail('এই দাবিটি খুঁজে পাওয়া যায়নি বা আগেই প্রক্রিয়া হয়ে গেছে।');
    updateRow('Transactions', txn._row, { ClaimStatus: 'Rejected', VerificationNote: 'গ্রাহক নিজে বাতিল করেছেন।' });
    logAudit(session.UserID, 'ONLINE_PAYMENT_CLAIM_CANCELLED', txnId);
    return ok('দাবিটি বাতিল করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Manager/Admin's queue of self-reported online payments waiting to be checked against the real bKash/Nagad statement. */
function getPendingOnlinePaymentClaims(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    var scope = managerScope_(session);   // v81
    var users = readSheet('Users');
    var plans = readSheet('Plans');
    var bkashAccounts = getPaymentSettingsInternal().bkashAccounts || [];
    var claims = findAll('Transactions', function (t) {
      return t.ClaimStatus === 'PendingVerification' &&
        inManagerScope_(scope, users.filter(function (u) { return u.UserID === t.CustomerID; })[0]);
    })
      .map(function (t) {
        var customer = users.filter(function (u) { return u.UserID === t.CustomerID; })[0];
        var plan = plans.filter(function (p) { return p.PlanID === t.PlanID; })[0];
        var paidAcc = t.PaidToNumber ? bkashAccounts.filter(function (a) { return a.number === t.PaidToNumber; })[0] : null;
        return {
          paidToNumber: t.PaidToNumber || '',
          paidToLabel: paidAcc ? paidAcc.label : '',
          paidToType: paidAcc ? paidAcc.type : '',
          txnId: t.TxnID,
          amount: Number(t.Amount),
          paymentMethod: t.PaymentMethod,
          trxIdReceipt: t.TrxID_Receipt,
          claimedAt: t.ClaimedAt || t.Timestamp,
          customerId: customer ? customer.UserID : '',
          customerName: customer ? customer.Name : '',
          customerPhone: customer ? customer.Phone : '',
          planName: plan ? plan.ItemOrGoalName : ''
        };
      })
      .sort(function (a, b) { return new Date(a.claimedAt) - new Date(b.claimedAt); });
    return ok(claims);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Manager/Admin checks their own bKash/Nagad transaction statement for this
 * TrxID and amount, then approves (money is added to the plan, exactly like a
 * manager-logged deposit) or rejects (customer is told why by SMS, nothing changes).
 */
function verifyOnlinePaymentClaim(token, txnId, approve, note) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.MANAGER, ROLES.ADMIN]);
    waitLockFresh(lock, 30000);

    var txn = findOne('Transactions', function (t) { return t.TxnID === txnId && t.ClaimStatus === 'PendingVerification'; });
    if (!txn) return fail('এই দাবিটি খুঁজে পাওয়া যায়নি বা আগেই প্রক্রিয়া হয়ে গেছে।');
    assertManagerCanServe_(session, txn.CustomerID);   // v81
    note = cleanText(note);
    var approveTrx = normalizeTrxId_(txn.TrxID_Receipt);   // v82
    if (approve && approveTrx.ok) {
      var approveClash = findTrxIdConflict_(approveTrx.id, txn.CustomerID, txn.TxnID);
      if (approveClash && approveClash.ClaimStatus !== 'PendingVerification') {
        logAudit(session.UserID, 'DUPLICATE_TRXID_BLOCKED', 'অনুমোদনের সময়: TrxID ' + approveTrx.id + ' আগেই লেনদেন ' + approveClash.TxnID + '-এ ব্যবহৃত');
        return fail('এই TrxID আগেই অন্য একটি জমায় ব্যবহার হয়েছে — অনুমোদন করা যাবে না। "প্রত্যাখ্যান" করুন।');
      }
    }

    if (!approve) {
      updateRow('Transactions', txn._row, {
        ClaimStatus: 'Rejected',
        VerifiedByManagerID: session.UserID,
        VerificationNote: note || 'তথ্য মিলছে না।',
        DecidedAt: new Date().toISOString()
      });
      var rejCustomer = findOneBy('Users', 'UserID', txn.CustomerID);
      if (rejCustomer) {
        logSms(rejCustomer.Phone, 'AmarSonchoy: আপনার ' + Number(txn.Amount) + ' টাকার ' + txn.PaymentMethod +
          ' জমার দাবিটি নিশ্চিত করা যায়নি। কারণ: ' + (note || 'তথ্য মিলছে না') + '। ম্যানেজারের সাথে যোগাযোগ করুন।');
      }
      logAudit(session.UserID, 'ONLINE_PAYMENT_REJECTED', txnId + ' — ' + (note || 'তথ্য মিলছে না'));
      return ok('দাবিটি প্রত্যাখ্যান করা হয়েছে।');
    }

    var plan = findOneBy('Plans', 'PlanID', txn.PlanID);
    if (!plan) return fail('প্ল্যান খুঁজে পাওয়া যায়নি।');
    if (plan.Status !== PLAN_STATUS.ACTIVE && plan.Status !== PLAN_STATUS.AT_RISK) {
      return fail('এই প্ল্যানটি এখন সক্রিয় নেই, অনুমোদন করা যাবে না। প্রয়োজনে প্রত্যাখ্যান করুন।');
    }

    guardManagerDayOpen_(session, dhakaDateStr(new Date()), false);   // v83
    var amount = Number(txn.Amount);
    var isFirstDepositEver = countConfirmedDeposits(plan.CustomerID, txn.TxnID).length === 0;
    var nowIso = new Date().toISOString();
    var effects = applyDepositEffects(plan, amount, nowIso, isFirstDepositEver);

    updateRow('Transactions', txn._row, {
      ClaimStatus: 'Approved',
      VerifiedByManagerID: session.UserID,
      VerificationNote: note,
      CustomerConfirmed: 'Yes',
      Timestamp: nowIso,
      DecidedAt: nowIso
    });
    var okCustomer = findOneBy('Users', 'UserID', txn.CustomerID);
    if (okCustomer) logSms(okCustomer.Phone, 'AmarSonchoy: আপনার ' + amount + ' টাকার ' + txn.PaymentMethod + ' জমা নিশ্চিত হয়েছে। প্ল্যানে মোট জমা এখন ' + effects.newTotal + ' টাকা।');

    logAudit(session.UserID, 'ONLINE_PAYMENT_APPROVED', txnId + ' — ' + amount + ' টাকা, প্ল্যান ' + txn.PlanID);
    return ok({ newBalance: effects.newTotal, progressPercent: effects.progressPercent, completed: effects.justCompleted });
  } catch (err) {
    Logger.log('Error in verifyOnlinePaymentClaim: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// v83. DAILY CLOSING (দৈনিক ক্লোজিং)
//      The Admin sees every manager's cash, number of deposits and discrepancy for a day in one screen and
//      CLOSES (বন্ধ) it. A closed day is an Approved row in ManagerCashSettlements — the same record the older
//      "ক্যাশ হিসাব মেলানো" flow already used — so nothing new has to be added to the sheets.
//      After closing: that manager can add no new entry to the day (live entries are refused; an offline entry that
//      reaches the server late is kept so no money is lost, but is logged as LATE_ENTRY_AFTER_CLOSE), and the
//      day's cash entries are stamped as settled. Only the Admin can reopen a day, with a written reason.
// ---------------------------------------------------------------------------
function findLiveSettlement_(managerId, dateStr) {
  return findOne('ManagerCashSettlements', function (s) {
    return s.ManagerID === managerId && String(s.SettlementDate) === dateStr && s.Status !== 'Rejected';
  });
}

/** Re-counts the manager's cash for the day at THIS moment, stamps those entries as settled and marks the day closed. */
function closeDayCore_(session, settlement, note) {
  var txns = getCashDepositsForManagerDate(settlement.ManagerID, settlement.SettlementDate);
  var systemAmount = txns.reduce(function (sum, t) { return sum + Number(t.Amount); }, 0);
  var declared = Number(settlement.DeclaredCashAmount);
  txns.forEach(function (t) { updateRow('Transactions', t._row, { SettledInSettlementID: settlement.SettlementID }); });
  updateRow('ManagerCashSettlements', settlement._row, {
    Status: 'Approved', SystemLoggedCashAmount: systemAmount, Discrepancy: declared - systemAmount,
    AdminNote: note || settlement.AdminNote || ''
  });
  return { count: txns.length, systemAmount: systemAmount, discrepancy: declared - systemAmount };
}

/**
 * Guard used right before a manager's entry is saved. When that manager's day is already closed, a live entry is
 * refused; an offline-synced one (allowLate) is kept but flagged. No-op for Admin / other roles.
 */
function guardManagerDayOpen_(session, dateStr, allowLate) {
  if (!session || session.Role !== ROLES.MANAGER) return;
  var s = findLiveSettlement_(session.UserID, dateStr);
  if (!s || s.Status !== 'Approved') return;
  if (allowLate) {
    logAudit(session.UserID, 'LATE_ENTRY_AFTER_CLOSE', dateStr + ' এর হিসাব বন্ধ থাকা অবস্থায় অফলাইন এন্ট্রি সিঙ্ক হয়েছে — অ্যাডমিন যাচাই করুন');
    return;
  }
  throw new Error('AUTH: ' + dateStr + ' এর হিসাব বন্ধ হয়ে গেছে — আর নতুন এন্ট্রি দেওয়া যায় না। ভুল থাকলে অ্যাডমিনের সাথে যোগাযোগ করুন।');
}

function validDayStr_(dateStr) {
  var today = dhakaDateStr(new Date());
  var d = String(dateStr || today);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) return null;
  if (d > today) return null;
  return d;
}

/** Admin-only. Every manager's day in one table. */
function getDailyClosingOverview(token, dateStr) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var day = validDayStr_(dateStr);
    if (!day) return fail('তারিখ সঠিক নয় (ভবিষ্যতের তারিখ দেওয়া যায় না)।');
    var today = dhakaDateStr(new Date());

    var users = readSheet('Users');
    var managers = users.filter(function (u) { return u.Role === ROLES.MANAGER; });
    var by = {};
    function bucket(id) {
      return by[id] || (by[id] = { cashCount: 0, cashAmount: 0, cashUnsettled: 0, onlineCount: 0, onlineAmount: 0, outCount: 0, outAmount: 0 });
    }
    readSheet('Transactions').forEach(function (t) {
      if (!t.VerifiedByManagerID) return;
      if (t.ClaimStatus === 'Rejected' || t.ClaimStatus === 'PendingVerification') return;
      var d;
      try { d = Utilities.formatDate(new Date(t.Timestamp), CONFIG.TIMEZONE, 'yyyy-MM-dd'); } catch (e) { return; }
      if (d !== day) return;
      var b = bucket(t.VerifiedByManagerID), amt = Number(t.Amount) || 0;
      if (t.TxnType === 'Deposit') {
        if (t.PaymentMethod === 'Cash') { b.cashCount++; b.cashAmount += amt; if (!t.SettledInSettlementID) b.cashUnsettled += amt; }
        else { b.onlineCount++; b.onlineAmount += amt; }
      } else if (t.TxnType === 'Withdrawal' || t.TxnType === 'Refund') {
        b.outCount++; b.outAmount += Math.abs(amt);
      }
    });

    var rows = managers.filter(function (m) { return m.Status === 'Active' || by[m.UserID]; }).map(function (m) {
      var b = by[m.UserID] || bucket(m.UserID);
      var s = findLiveSettlement_(m.UserID, day);
      var state = !s ? 'open' : (s.Status === 'Approved' ? 'closed' : 'submitted');
      var declared = s ? Number(s.DeclaredCashAmount) : null;
      var system = state === 'closed' ? Number(s.SystemLoggedCashAmount) : b.cashUnsettled;
      var discrepancy = state === 'closed' ? Number(s.Discrepancy) : (declared !== null ? declared - system : null);
      var depositCount = b.cashCount + b.onlineCount;
      return {
        managerId: m.UserID, name: m.Name, phone: m.Phone, branch: normalizeBranch(m.Branch) || '',
        depositCount: depositCount, cashCount: b.cashCount, cashAmount: b.cashAmount,
        onlineCount: b.onlineCount, onlineAmount: b.onlineAmount, outCount: b.outCount, outAmount: b.outAmount,
        state: state, settlementId: s ? s.SettlementID : '', declared: declared, system: system, discrepancy: discrepancy,
        note: s ? (s.AdminNote || '') : '',
        lateCash: state === 'closed' ? b.cashUnsettled : 0,
        hasActivity: depositCount + b.outCount > 0
      };
    });
    var rank = { open: 0, submitted: 1, closed: 2 };
    rows.sort(function (a, b) {
      if (a.hasActivity !== b.hasActivity) return a.hasActivity ? -1 : 1;
      if (rank[a.state] !== rank[b.state]) return rank[a.state] - rank[b.state];
      return String(a.name).localeCompare(String(b.name), 'bn');
    });
    var totals = { managers: rows.length, open: 0, submitted: 0, closed: 0, deposits: 0, cash: 0, discrepancy: 0 };
    rows.forEach(function (r) {
      if (r.hasActivity || r.state !== 'open') totals[r.state]++;
      totals.deposits += r.depositCount; totals.cash += r.cashAmount;
      if (r.discrepancy !== null) totals.discrepancy += r.discrepancy;
    });
    return ok({ date: day, isToday: day === today, rows: rows, totals: totals });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * Admin-only. Closes one manager's day. If the manager already submitted their cash count it is used; if not, the
 * Admin must enter the cash they counted. A discrepancy needs a written note (so every gap has a recorded reason).
 */
function closeManagerDay(token, managerId, dateStr, countedCash, note) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var day = validDayStr_(dateStr);
    if (!day) return fail('তারিখ সঠিক নয়।');
    var mgr = findOne('Users', function (u) { return u.UserID === managerId && u.Role === ROLES.MANAGER; });
    if (!mgr) return fail('ম্যানেজার খুঁজে পাওয়া যায়নি।');
    note = cleanText(note);
    waitLockFresh(lock, 30000);

    var existing = findLiveSettlement_(managerId, day);
    if (existing && existing.Status === 'Approved') return fail('এই দিনের হিসাব আগেই বন্ধ করা হয়েছে।');

    var declared;
    if (existing) {
      declared = Number(existing.DeclaredCashAmount);
    } else {
      declared = Math.round(Number(countedCash));
      if (countedCash === '' || countedCash === null || countedCash === undefined || isNaN(declared) || declared < 0) {
        return fail('ম্যানেজারের হিসাব জমা নেই — হাতে গুনে পাওয়া নগদের পরিমাণ দিন।');
      }
    }
    var system = getCashDepositsForManagerDate(managerId, day).reduce(function (sum, t) { return sum + Number(t.Amount); }, 0);
    var gap = declared - system;
    if (gap !== 0 && note.length < 5) {
      return fail('নগদে অমিল ৳' + gap + ' আছে (ঘোষিত ৳' + declared + ', সিস্টেম ৳' + system + ') — বন্ধ করতে কারণ/মন্তব্য লিখুন (অন্তত ৫ অক্ষর)।');
    }

    var settlement = existing;
    var byAdmin = false;
    if (!settlement) {
      byAdmin = true;
      var newId = generateId('SET');
      appendRow('ManagerCashSettlements', {
        SettlementID: newId, ManagerID: managerId, SettlementDate: day, DeclaredCashAmount: declared,
        SystemLoggedCashAmount: system, Discrepancy: gap, Status: 'Pending', AdminNote: '', Timestamp: new Date().toISOString()
      });
      settlement = findOneBy('ManagerCashSettlements', 'SettlementID', newId);
    }
    var fullNote = (byAdmin ? '[অ্যাডমিন নিজে গুনে বন্ধ করেছেন] ' : '') + note;
    var res = closeDayCore_(session, settlement, fullNote.trim());
    logAudit(session.UserID, 'DAY_CLOSED', mgr.Name + ' — ' + day + ': ঘোষিত ৳' + declared + ', সিস্টেম ৳' + res.systemAmount +
      ', অমিল ৳' + res.discrepancy + ', ' + res.count + 'টি নগদ এন্ট্রি' + (note ? (' — ' + note) : ''));
    return ok({ managerId: managerId, date: day, system: res.systemAmount, discrepancy: res.discrepancy });
  } catch (err) {
    Logger.log('Error in closeManagerDay: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/** Admin-only, last resort: reopens a closed day (the manager can submit again). A written reason is compulsory and is audited. */
function reopenManagerDay(token, managerId, dateStr, reason) {
  var lock = LockService.getScriptLock();
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var day = validDayStr_(dateStr);
    if (!day) return fail('তারিখ সঠিক নয়।');
    reason = cleanText(reason);
    if (reason.length < 5) return fail('পুনরায় খোলার কারণ লিখুন (অন্তত ৫ অক্ষর)।');
    waitLockFresh(lock, 30000);

    var s = findLiveSettlement_(managerId, day);
    if (!s || s.Status !== 'Approved') return fail('এই দিনের হিসাব বন্ধ করা নেই।');
    var stamped = findAll('Transactions', function (t) { return t.SettledInSettlementID === s.SettlementID; });
    stamped.forEach(function (t) { updateRow('Transactions', t._row, { SettledInSettlementID: '' }); });
    updateRow('ManagerCashSettlements', s._row, { Status: 'Rejected', AdminNote: 'পুনরায় খোলা হয়েছে: ' + reason });
    var mgr = findOneBy('Users', 'UserID', managerId);
    logAudit(session.UserID, 'DAY_REOPENED', (mgr ? mgr.Name : managerId) + ' — ' + day + ' — কারণ: ' + reason);
    return ok({ managerId: managerId, date: day });
  } catch (err) {
    Logger.log('Error in reopenManagerDay: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

// ---------------------------------------------------------------------------
// 30. NO-CODE INITIAL ADMIN SETUP — Upgrade 16
// ---------------------------------------------------------------------------

function hasAnyAdmin() {
  return !!findOneBy('Users', 'Role', ROLES.ADMIN);
}

/** Public (no login needed) — the app uses this to decide whether to show the one-time setup screen instead of the normal home page. */
function needsInitialSetup() {
  try {
    ensureSchemaUpToDate(); // safe if already up to date; guarantees the Users sheet exists before we check it
    return ok({ needed: !hasAnyAdmin() });
  } catch (err) {
    Logger.log('Error in needsInitialSetup: ' + err);
    return ok({ needed: false });
  }
}

/**
 * Creates the very first Admin account from inside the app itself — no Apps
 * Script editor needed. Only works while there is truly no Admin account yet;
 * once one exists this always fails, so it can never be used to slip in a
 * second Admin later. An existing Admin creates Managers from the Admin panel;
 * a second Admin account still needs createFirstAdmin() run once from the
 * editor (Apps Script → select the function → Run), same as before.
 */
function setupInitialAdmin(name, phone, pin) {
  var lock = LockService.getScriptLock();
  try {
    waitLockFresh(lock, 30000);
    if (hasAnyAdmin()) return fail('অ্যাডমিন অ্যাকাউন্ট আগেই তৈরি হয়ে গেছে। লগইন করুন।');

    name = cleanText(name);
    phone = String(phone || '').trim();
    pin = String(pin || '').trim();
    if (!name) return fail('নাম লিখুন।');
    var validation = validatePhoneAndPin(phone, pin);
    if (!validation.ok) return validation;

    var existing = findOneBy('Users', 'Phone', phone);
    if (existing) return fail('এই মোবাইল নম্বর দিয়ে আগে থেকেই একটি অ্যাকাউন্ট আছে।');

    var newAdmin = {
      UserID: generateId('USR'),
      Name: name,
      Phone: phone,
      PIN: pin,
      Role: ROLES.ADMIN,
      Status: 'Active',
      FailedLoginAttempts: 0,
      LockedUntil: '',
      CreatedAt: new Date().toISOString(),
      Badge: '',
      StreakCount: 0,
      ReferralCode: generateUniqueReferralCode(phone),
      ReferredByUserID: '',
      ReferralBonusAwarded: 'No',
      Branch: getDefaultBranchName_(),
      TermsAcceptedAt: ''
    };
    appendRow('Users', newAdmin);
    logAudit(newAdmin.UserID, 'INITIAL_ADMIN_SETUP', name + ' (' + phone + ')');

    var token = createSession(newAdmin);
    return ok({ token: token, user: { UserID: newAdmin.UserID, Name: newAdmin.Name, Phone: newAdmin.Phone, Role: newAdmin.Role } });
  } catch (err) {
    Logger.log('Error in setupInitialAdmin: ' + err);
    return fail('সমস্যা হয়েছে, আবার চেষ্টা করুন।');
  } finally {
    try { lock.releaseLock(); } catch (e) { /* lock was never acquired */ }
  }
}

/**
 * Lets an Admin install every daily trigger from inside the app — no Apps
 * Script editor visit needed after the very first deploy. Safe to call again.
 */
function installAllTriggersFromApp(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    setupAllTriggers();
    return ok('সব ট্রিগার চালু হয়েছে।');
  } catch (err) {
    Logger.log('Error in installAllTriggersFromApp: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 31. PUBLIC LANDING PAGE STATS — Upgrade 17
// ---------------------------------------------------------------------------

/** Safe, aggregate-only numbers for the logged-out landing page. No names, no phone numbers, no per-manager or per-branch breakdown. */
function getPublicLandingStats() {
  try {
    var users = readSheet('Users');
    var plans = readSheet('Plans');
    var totalCustomers = users.filter(function (u) { return u.Role === ROLES.CUSTOMER && u.Status === 'Active'; }).length;
    var totalSaved = plans.reduce(function (sum, p) { return sum + Number(p.AccumulatedSavings || 0); }, 0);
    var totalBonusPaid = plans.reduce(function (sum, p) { return sum + Number(p.AccruedSavingsBonus || 0); }, 0);
    var completedGoals = plans.filter(function (p) { return p.Status === PLAN_STATUS.COMPLETED; }).length;
    // v64: total money handed back to customers = recorded partial withdrawals + approved full refunds
    // (both are stored as negative Withdrawal/Refund transactions, so the absolute value is summed).
    var totalReturned = readSheet('Transactions').reduce(function (sum, t) {
      if (t.TxnType !== 'Withdrawal' && t.TxnType !== 'Refund') return sum;
      return sum + Math.abs(Number(t.Amount || 0));
    }, 0);
    var totalTransactions = countRows('Transactions', function (t) {
      return t.TxnType === 'Deposit' && t.CustomerConfirmed !== 'No' && t.ClaimStatus !== 'PendingVerification' && t.ClaimStatus !== 'Rejected';
    });
    var activeManagers = users.filter(function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; }).length;
    return ok({
      totalCustomers: totalCustomers,
      totalSaved: totalSaved,
      completedGoals: completedGoals,
      totalReturned: totalReturned,
      branches: getActiveBranchNames_().length,
      totalBonusPaid: totalBonusPaid,
      totalTransactions: totalTransactions,
      activeManagers: activeManagers
    });
  } catch (err) {
    return ok({ totalCustomers: 0, totalSaved: 0, completedGoals: 0, totalReturned: 0, branches: getActiveBranchNames_().length, totalBonusPaid: 0, totalTransactions: 0, activeManagers: 0 });
  }
}

/** Small helper: count sheet rows matching a predicate without loading everything into named-field objects twice. */
function countRows(sheetName, predicate) {
  return readSheet(sheetName).filter(predicate).length;
}

// ---------------------------------------------------------------------------
// 32. CHARTS & CUSTOM DASHBOARDS — Upgrade 19
//     Numbers only — every chart is drawn client-side (inline SVG, no
//     external library), so these functions just return the aggregated
//     figures each dashboard needs.
// ---------------------------------------------------------------------------

/** Admin sets (or clears, with an empty amount) how much a Manager is expected to collect this month. */
function updateManagerTarget(token, managerId, amount) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    var mgr = findOne('Users', function (u) { return u.UserID === managerId && u.Role === ROLES.MANAGER; });
    if (!mgr) return fail('ম্যানেজার খুঁজে পাওয়া যায়নি।');

    var value = '';
    if (amount !== '' && amount !== null && amount !== undefined) {
      value = Math.round(Number(amount));
      if (isNaN(value) || value < 0) return fail('সঠিক পরিমাণ দিন।');
    }
    updateRow('Users', mgr._row, { MonthlyTargetAmount: value });
    logAudit(session.UserID, 'MANAGER_TARGET_UPDATED', mgr.Name + ' → ' + (value === '' ? 'নেই' : value));
    return ok('লক্ষ্য সংরক্ষণ করা হয়েছে।');
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * A Manager's own chart data: the last 7 days of their verified collections
 * (to spot a slow day early) and this month's total against the target the
 * Admin set for them.
 */
function getManagerChartData(token) {
  try {
    var session = requireRole(token, [ROLES.MANAGER]);
    var mgr = findOneBy('Users', 'UserID', session.UserID);
    var target = Number((mgr && mgr.MonthlyTargetAmount) || 0);

    var now = new Date();
    var monthKey = Utilities.formatDate(now, CONFIG.TIMEZONE, 'yyyy-MM');
    var dayKeys = [];
    for (var i = 6; i >= 0; i--) dayKeys.push(dhakaDateStr(new Date(now.getTime() - i * DAY_MS)));
    var dayTotals = {};
    dayKeys.forEach(function (k) { dayTotals[k] = 0; });

    var achieved = 0;
    readSheet('Transactions').forEach(function (t) {
      if (t.VerifiedByManagerID !== session.UserID) return;
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      var dayKey = dhakaDateStr(d);
      if (dayTotals.hasOwnProperty(dayKey)) dayTotals[dayKey] += Number(t.Amount || 0);
      if (Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM') === monthKey) achieved += Number(t.Amount || 0);
    });

    var dailyLabels = dayKeys.map(function (k) {
      return Utilities.formatDate(new Date(k + 'T12:00:00+06:00'), CONFIG.TIMEZONE, 'dd/MM');
    });
    return ok({
      dailyLabels: dailyLabels,
      dailyValues: dayKeys.map(function (k) { return dayTotals[k]; }),
      target: target,
      achieved: achieved,
      monthPercent: target > 0 ? Math.round((achieved / target) * 100) : null
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * The Admin's overview chart data: collection over the last 6 months, how
 * plans are currently distributed by status, and how each active Manager is
 * doing against the monthly target set for them.
 */
function getAdminChartDataCompute_(token) {
  try {
    requireRole(token, [ROLES.ADMIN]);
    var now = new Date();
    var monthKeys = [];
    for (var i = 5; i >= 0; i--) {
      monthKeys.push(Utilities.formatDate(new Date(now.getFullYear(), now.getMonth() - i, 1), CONFIG.TIMEZONE, 'yyyy-MM'));
    }
    var monthTotals = {};
    monthKeys.forEach(function (k) { monthTotals[k] = 0; });

    var statusCounts = {};
    var users = readSheet('Users');
    var managers = users.filter(function (u) { return u.Role === ROLES.MANAGER && u.Status === 'Active'; });

    // v77: last 30 days of collection (all villages together) for the daily-trend view.
    var dayKeys30 = [];
    for (var di = 29; di >= 0; di--) dayKeys30.push(dhakaDateStr(new Date(now.getTime() - di * DAY_MS)));
    var dayTotals30 = {};
    dayKeys30.forEach(function (k) { dayTotals30[k] = 0; });
    var achievedByManager = {};
    managers.forEach(function (m) { achievedByManager[m.UserID] = 0; });
    var monthKeyNow = monthKeys[monthKeys.length - 1];

    // Upgrade 20: branch-wise monthly totals — only meaningful once more than one branch is in use.
    var multiBranch = getBranchNames_().length > 1;
    var branchByCustomer = {};
    var branchMonthTotals = {};
    if (multiBranch) {
      users.forEach(function (u) { branchByCustomer[u.UserID] = normalizeBranch(u.Branch); });
      getBranchNames_().forEach(function (b) {
        branchMonthTotals[b] = {};
        monthKeys.forEach(function (k) { branchMonthTotals[b][k] = 0; });
      });
    }

    readSheet('Transactions').forEach(function (t) {
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      var mk = Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM');
      if (monthTotals.hasOwnProperty(mk)) monthTotals[mk] += Number(t.Amount || 0);
      var dk30 = dhakaDateStr(d);
      if (dayTotals30.hasOwnProperty(dk30)) dayTotals30[dk30] += Number(t.Amount || 0);
      if (mk === monthKeyNow && achievedByManager.hasOwnProperty(t.VerifiedByManagerID)) {
        achievedByManager[t.VerifiedByManagerID] += Number(t.Amount || 0);
      }
      if (multiBranch) {
        var branch = branchByCustomer[t.CustomerID];
        if (branch && branchMonthTotals[branch] && branchMonthTotals[branch].hasOwnProperty(mk)) {
          branchMonthTotals[branch][mk] += Number(t.Amount || 0);
        }
      }
    });

    readSheet('Plans').forEach(function (p) { statusCounts[p.Status] = (statusCounts[p.Status] || 0) + 1; });

    var managerTargets = managers.map(function (m) {
      return {
        managerId: m.UserID,
        name: m.Name,
        target: Number(m.MonthlyTargetAmount || 0),
        achieved: achievedByManager[m.UserID] || 0
      };
    });

    var customersByBranch = {};
    if (multiBranch) {
      users.forEach(function (u) {
        if (u.Role !== ROLES.CUSTOMER) return;
        var bn = branchByCustomer[u.UserID];
        if (bn) customersByBranch[bn] = (customersByBranch[bn] || 0) + 1;
      });
    }
    var byBranch = multiBranch ? getBranchNames_().map(function (b) {
      return {
        branch: b,
        monthValues: monthKeys.map(function (k) { return branchMonthTotals[b][k]; }),
        customers: customersByBranch[b] || 0
      };
    }) : [];

    return ok({
      monthLabels: monthKeys,
      monthValues: monthKeys.map(function (k) { return monthTotals[k]; }),
      dayLabels: dayKeys30,
      dayValues: dayKeys30.map(function (k) { return dayTotals30[k]; }),
      statusCounts: statusCounts,
      managerTargets: managerTargets,
      byBranch: byBranch
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * A Customer's own chart data: how much they deposited in each of the last
 * 6 months (confirmed deposits only) and their average monthly deposit —
 * answers "আমি এই মাসে গড়ে কত জমা দিচ্ছি". Upgrade 20.
 */
function getCustomerChartData(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var now = new Date();
    var monthKeys = [];
    for (var i = 5; i >= 0; i--) {
      monthKeys.push(Utilities.formatDate(new Date(now.getFullYear(), now.getMonth() - i, 1), CONFIG.TIMEZONE, 'yyyy-MM'));
    }
    var monthTotals = {};
    monthKeys.forEach(function (k) { monthTotals[k] = 0; });

    readSheet('Transactions').forEach(function (t) {
      if (t.CustomerID !== session.UserID) return;
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      var mk = Utilities.formatDate(d, CONFIG.TIMEZONE, 'yyyy-MM');
      if (monthTotals.hasOwnProperty(mk)) monthTotals[mk] += Number(t.Amount || 0);
    });

    var values = monthKeys.map(function (k) { return monthTotals[k]; });
    var activeMonths = values.filter(function (v) { return v > 0; }).length || 1;
    var average = Math.round(values.reduce(function (a, b) { return a + b; }, 0) / activeMonths);

    return ok({ monthLabels: monthKeys, monthValues: values, average: average });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/**
 * This week (last 7 days) vs the previous 7 days — "এই সপ্তাহে কত জমালাম,
 * গতবারের চেয়ে বেশি না কম" for the customer's weekend progress report.
 * Upgrade 22.
 */
function getWeeklyProgress(token) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    var now = new Date();
    var thisWeekStart = new Date(now.getTime() - 6 * DAY_MS);
    var lastWeekStart = new Date(now.getTime() - 13 * DAY_MS);
    var lastWeekEnd = new Date(now.getTime() - 7 * DAY_MS);

    var thisWeekTotal = 0, lastWeekTotal = 0;
    var activeDaysSet = {};

    readSheet('Transactions').forEach(function (t) {
      if (t.CustomerID !== session.UserID) return;
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      if (d >= thisWeekStart && d <= now) {
        thisWeekTotal += Number(t.Amount || 0);
        activeDaysSet[dhakaDateStr(d)] = true;
      } else if (d >= lastWeekStart && d <= lastWeekEnd) {
        lastWeekTotal += Number(t.Amount || 0);
      }
    });

    var diff = thisWeekTotal - lastWeekTotal;
    var percentChange = lastWeekTotal > 0 ? Math.round((diff / lastWeekTotal) * 100) : (thisWeekTotal > 0 ? 100 : 0);

    return ok({
      thisWeekTotal: thisWeekTotal,
      lastWeekTotal: lastWeekTotal,
      diff: diff,
      percentChange: percentChange,
      thisWeekDaysActive: Object.keys(activeDaysSet).length
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 33. SITE SETTINGS — Upgrade 20. Social links, per-role money quotes,
//     per-role YouTube videos, and the landing page's carousel/testimonials.
//     Stored in PropertiesService, same pattern as Payment Settings (Upgrade
//     15), so the Admin can change everything from inside the app — no code
//     edits needed.
// ---------------------------------------------------------------------------

var DEFAULT_MONEY_QUOTES = {
  Admin: 'একটি প্রতিষ্ঠানের সাফল্য নির্ভর করে প্রতিটি গ্রাহকের বিশ্বাস ও তাদের নিয়মিত সঞ্চয়ের ওপর।',
  Manager: 'ছোট ছোট জমাই একদিন গ্রাহকের বড় স্বপ্ন পূরণ করে — আজকের প্রতিটি কালেকশন তাতে অবদান রাখছে।',
  Customer: 'আজকের সামান্য সঞ্চয়ই আগামী দিনের বড় স্বাধীনতা এনে দেয়।'
};

/** Public settings needed by the client — safe to send to anyone, logged in or not. */
function getSiteSettings() {
  var props = PropertiesService.getScriptProperties();
  function getJson(key, fallback) {
    var raw = props.getProperty(key);
    if (!raw) return fallback;
    try { return JSON.parse(raw); } catch (e) { return fallback; }
  }
  return {
    social: (function () { // saved link wins; an empty one falls back to CONFIG.SOCIAL_DEFAULTS
      var saved = getJson('SOCIAL_LINKS', {}) || {}, out = {};
      ['fbPage', 'fbGroup', 'youtube', 'tiktok', 'instagram'].forEach(function (k) {
        out[k] = String(saved[k] || '').trim() || (CONFIG.SOCIAL_DEFAULTS && CONFIG.SOCIAL_DEFAULTS[k]) || '';
      });
      return out;
    })(),
    quotes: {
      Admin: props.getProperty('QUOTE_ADMIN') || DEFAULT_MONEY_QUOTES.Admin,
      Manager: props.getProperty('QUOTE_MANAGER') || DEFAULT_MONEY_QUOTES.Manager,
      Customer: props.getProperty('QUOTE_CUSTOMER') || DEFAULT_MONEY_QUOTES.Customer
    },
    videos: {
      Admin: props.getProperty('YT_ADMIN') || '',
      Manager: props.getProperty('YT_MANAGER') || '',
      Customer: props.getProperty('YT_CUSTOMER') || ''
    },
    videoRatios: {
      Admin: effectiveYoutubeRatio_(props, 'ADMIN'),
      Manager: effectiveYoutubeRatio_(props, 'MANAGER'),
      Customer: effectiveYoutubeRatio_(props, 'CUSTOMER')
    },
    videoModes: {
      Admin: props.getProperty('YT_ADMIN_RATIO') || 'auto',
      Manager: props.getProperty('YT_MANAGER_RATIO') || 'auto',
      Customer: props.getProperty('YT_CUSTOMER_RATIO') || 'auto'
    },
    carousel: getJson('CAROUSEL_IMAGES', []),
    testimonials: getJson('TESTIMONIALS', []),
    successStories: getJson('SUCCESS_STORIES', [])
  };
}

// ---- YouTube frame shape (16:9, 9:16 Shorts, 1:1 ...) ----
var YT_RATIO_MODES = ['auto', '16:9', '9:16', '1:1', '4:5', '4:3'];

/** The ratio the page should actually use for one role's video: the Admin's choice, else what was detected when saved, else 16:9. */
function effectiveYoutubeRatio_(props, key) {
  var mode = props.getProperty('YT_' + key + '_RATIO') || 'auto';
  if (mode !== 'auto') return mode;
  var id = props.getProperty('YT_' + key) || '';
  var cached = String(props.getProperty('YT_' + key + '_AUTO') || '').split('|');
  return (id && cached[0] === id && cached[1]) ? cached[1] : '16:9';
}

/** Turns a measured width/height into the nearest supported ratio. */
function snapYoutubeRatio_(w, h) {
  w = Number(w); h = Number(h);
  if (!w || !h) return '16:9';
  var r = w / h;
  if (r < 0.7) return '9:16';
  if (r < 0.9) return '4:5';
  if (r < 1.15) return '1:1';
  if (r < 1.5) return '4:3';
  return '16:9';
}

/**
 * Works out the frame shape of a video when the Admin leaves it on "অটো".
 * A /shorts/ link is always upright (9:16). For anything else YouTube's public
 * oEmbed reply is asked for the player size; if that cannot be reached the
 * safe 16:9 is kept (and the Admin can still pick a shape by hand).
 */
function detectYoutubeRatio_(rawInput, id) {
  if (/youtube\.com\/shorts\//i.test(String(rawInput || ''))) return '9:16';
  try {
    var res = UrlFetchApp.fetch('https://www.youtube.com/oembed?format=json&url=' +
      encodeURIComponent('https://www.youtube.com/watch?v=' + id), { muteHttpExceptions: true });
    if (res.getResponseCode() === 200) {
      var info = JSON.parse(res.getContentText());
      return snapYoutubeRatio_(info.width, info.height);
    }
  } catch (e) { Logger.log('detectYoutubeRatio_: ' + e); }
  return '16:9';
}

/** Saves the shape setting for one role's video (key = ADMIN / MANAGER / CUSTOMER). */
function saveYoutubeRatio_(props, key, rawInput, id, modeInput) {
  var mode = YT_RATIO_MODES.indexOf(String(modeInput || '')) !== -1 ? String(modeInput) : 'auto';
  props.setProperty('YT_' + key + '_RATIO', mode);
  if (!id) { props.setProperty('YT_' + key + '_AUTO', ''); return; }
  if (mode !== 'auto') return;
  var shorts = /youtube\.com\/shorts\//i.test(String(rawInput || ''));
  var cached = String(props.getProperty('YT_' + key + '_AUTO') || '');
  // Same video as last time and not a Shorts link: no need to ask YouTube again.
  if (!shorts && cached.indexOf(id + '|') === 0) return;
  props.setProperty('YT_' + key + '_AUTO', id + '|' + detectYoutubeRatio_(rawInput, id));
}

/**
 * Admin-only update of every site setting in one form. Free-text boxes
 * (one item per line) are split into arrays server-side so the client stays
 * simple.
 */
function updateSiteSettings(token, data) {
  try {
    var session = requireRole(token, [ROLES.ADMIN]);
    data = data || {};
    var props = PropertiesService.getScriptProperties();

    function cleanUrl(u) {
      u = String(u || '').trim();
      if (!u) return '';
      if (!/^https?:\/\//.test(u)) throw new Error('প্রতিটি লিংক অবশ্যই http:// অথবা https:// দিয়ে শুরু হতে হবে।');
      return u;
    }
    function cleanYoutubeId(v) {
      v = String(v || '').trim();
      if (!v) return '';
      var m = v.match(/(?:v=|youtu\.be\/|embed\/|shorts\/|live\/|\/v\/)([A-Za-z0-9_-]{6,})/);
      if (m) return m[1];
      return v.replace(/[^A-Za-z0-9_-]/g, '');
    }

    var social = {
      fbPage: cleanUrl(data.fbPage), fbGroup: cleanUrl(data.fbGroup),
      instagram: cleanUrl(data.instagram), tiktok: cleanUrl(data.tiktok), youtube: cleanUrl(data.youtube)
    };

    var carousel = String(data.carouselUrls || '').split('\n')
      .map(function (s) { return s.trim(); }).filter(function (s) { return s; }).map(cleanUrl);

    var testimonials = [];
    var names = String(data.testimonialNames || '').split('\n');
    var texts = String(data.testimonialTexts || '').split('\n');
    for (var i = 0; i < Math.max(names.length, texts.length); i++) {
      var n = cleanText(names[i]), t = cleanText(texts[i]);
      if (n || t) testimonials.push({ name: n || 'গ্রাহক', text: t });
    }

    // Upgrade 21: success stories (with photo) for the public landing page.
    var successStories = [];
    var sNames = String(data.storyNames || '').split('\n');
    var sTexts = String(data.storyTexts || '').split('\n');
    var sImages = String(data.storyImages || '').split('\n');
    for (var j = 0; j < Math.max(sNames.length, sTexts.length, sImages.length); j++) {
      var sn = cleanText(sNames[j]), st = cleanText(sTexts[j]), si = String(sImages[j] || '').trim();
      if (si) si = cleanUrl(si);
      if (sn || st || si) successStories.push({ name: sn || 'গ্রাহক', text: st, imageUrl: si });
    }

    props.setProperty('SOCIAL_LINKS', JSON.stringify(social));
    props.setProperty('QUOTE_ADMIN', cleanText(data.quoteAdmin) || DEFAULT_MONEY_QUOTES.Admin);
    props.setProperty('QUOTE_MANAGER', cleanText(data.quoteManager) || DEFAULT_MONEY_QUOTES.Manager);
    props.setProperty('QUOTE_CUSTOMER', cleanText(data.quoteCustomer) || DEFAULT_MONEY_QUOTES.Customer);
    var ytAdminId = cleanYoutubeId(data.ytAdmin), ytManagerId = cleanYoutubeId(data.ytManager), ytCustomerId = cleanYoutubeId(data.ytCustomer);
    props.setProperty('YT_ADMIN', ytAdminId);
    props.setProperty('YT_MANAGER', ytManagerId);
    props.setProperty('YT_CUSTOMER', ytCustomerId);
    saveYoutubeRatio_(props, 'ADMIN', data.ytAdmin, ytAdminId, data.ytAdminRatio);
    saveYoutubeRatio_(props, 'MANAGER', data.ytManager, ytManagerId, data.ytManagerRatio);
    saveYoutubeRatio_(props, 'CUSTOMER', data.ytCustomer, ytCustomerId, data.ytCustomerRatio);
    props.setProperty('CAROUSEL_IMAGES', JSON.stringify(carousel));
    props.setProperty('TESTIMONIALS', JSON.stringify(testimonials));
    props.setProperty('SUCCESS_STORIES', JSON.stringify(successStories));

    logAudit(session.UserID, 'SITE_SETTINGS_UPDATED', 'সাইট সেটিংস (সোশ্যাল লিংক, উক্তি, ভিডিও, ক্যারোসেল, সাকসেস স্টোরি) পরিবর্তন করা হয়েছে');
    return ok('সেটিংস সংরক্ষণ করা হয়েছে।');
  } catch (err) {
    Logger.log('Error in updateSiteSettings: ' + err);
    return fail(err.message.replace('AUTH: ', ''));
  }
}

// ---------------------------------------------------------------------------
// 34. SAVE NOW, BUY LATER — Upgrade 21
//     Saving-streak calendar, group savings leaderboard, and a public
//     seasonal-campaign banner for the logged-out landing page.
// ---------------------------------------------------------------------------

/**
 * A Duolingo-style calendar for the last `days` days: which days the
 * customer made at least one confirmed deposit. Used to visualize their
 * saving streak and nudge them to keep it going.
 */
function getSavingStreakCalendar(token, days) {
  try {
    var session = requireRole(token, [ROLES.CUSTOMER]);
    days = Math.max(7, Math.min(90, Number(days) || 35));

    var dateKeys = [];
    var now = new Date();
    for (var i = days - 1; i >= 0; i--) {
      dateKeys.push(dhakaDateStr(new Date(now.getTime() - i * DAY_MS)));
    }
    var depositedOn = {};
    dateKeys.forEach(function (k) { depositedOn[k] = false; });

    readSheet('Transactions').forEach(function (t) {
      if (t.CustomerID !== session.UserID) return;
      if (t.TxnType !== 'Deposit' || t.CustomerConfirmed === 'No') return;
      if (t.ClaimStatus === 'PendingVerification' || t.ClaimStatus === 'Rejected') return;
      var d = new Date(t.Timestamp);
      if (isNaN(d.getTime())) return;
      var k = dhakaDateStr(d);
      if (depositedOn.hasOwnProperty(k)) depositedOn[k] = true;
    });

    // Current streak: consecutive days up to today (or yesterday, if today's deposit hasn't happened yet) with a deposit.
    var currentStreak = 0;
    for (var idx = dateKeys.length - 1; idx >= 0; idx--) {
      var key = dateKeys[idx];
      var isToday = key === dhakaDateStr(now);
      if (depositedOn[key]) { currentStreak++; continue; }
      if (isToday) continue; // today not over yet — don't break the streak just for that
      break;
    }

    return ok({
      days: dateKeys.map(function (k) { return { date: k, deposited: depositedOn[k] }; }),
      currentStreak: currentStreak
    });
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** Top committee (group) savers, ranked by total saved — visible to any logged-in role. */
function getGroupSavingsLeaderboard(token) {
  try {
    requireRole(token, null);
    var groups = findAll('CommitteeGroups', function (g) { return g.Status === 'Active'; });
    var plans = readSheet('Plans');
    var totalsByGroup = {};
    plans.forEach(function (p) {
      if (!p.GroupID) return;
      totalsByGroup[p.GroupID] = (totalsByGroup[p.GroupID] || 0) + Number(p.AccumulatedSavings || 0) + Number(p.AccruedSavingsBonus || 0);
    });
    var rows = groups.map(function (g) {
      return {
        groupId: g.GroupID,
        groupName: g.GroupName,
        targetAmount: Number(g.TargetAmount || 0),
        totalSaved: totalsByGroup[g.GroupID] || 0
      };
    }).sort(function (a, b) { return b.totalSaved - a.totalSaved; }).slice(0, 10);
    return ok(rows);
  } catch (err) {
    return fail(err.message.replace('AUTH: ', ''));
  }
}

/** The single nearest upcoming seasonal campaign, safe to show on the logged-out landing page. */
function getPublicActiveSeasonalCampaign() {
  try {
    var all = readSheet('SeasonalCampaigns').filter(function (c) { return c.Status === 'Active'; });
    var best = null;
    all.forEach(function (c) {
      var seasonDate = new Date(c.SeasonDate);
      if (isNaN(seasonDate.getTime())) return;
      var daysLeft = daysUntil(seasonDate);
      if (daysLeft === null || daysLeft < 0 || daysLeft > 60) return;
      if (!best || daysLeft < best.daysLeft) {
        var tpl = getTemplateByKey(c.TemplateKey);
        best = { title: c.Title, daysLeft: daysLeft, suggestedAmount: Number(c.SuggestedAmount || 0), icon: tpl ? tpl.icon : 'sparkles' };
      }
    });
    return ok(best);
  } catch (err) {
    return ok(null);
  }
}
